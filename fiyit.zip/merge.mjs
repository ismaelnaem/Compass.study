import fs from 'fs';

const g9 = JSON.parse(fs.readFileSync('g9.json', 'utf8'));
const g10 = JSON.parse(fs.readFileSync('g10.json', 'utf8'));
const g11 = JSON.parse(fs.readFileSync('g11.json', 'utf8'));
const g12 = JSON.parse(fs.readFileSync('g12.json', 'utf8'));

const iconMap = {
  "Mathematics": "Calculator",
  "Physics": "Atom",
  "Chemistry": "FlaskConical",
  "Biology": "Dna",
  "English": "Languages",
  "History": "Landmark",
  "Geography": "Globe",
  "Citizenship Education": "Scale",
  "Economics": "LineChart",
  "Amharic": "MessageSquare",
  "Information Technology": "MonitorSmartphone",
  "Health and Physical Education": "Activity"
};

function formatData(data, grade) {
  return data.map(subject => ({
    id: subject.id,
    name: subject.name,
    icon: iconMap[subject.name] || "Book",
    grade: String(grade),
    ...(subject.stream ? { stream: subject.stream } : {}),
    units: subject.units.map((unit, index) => ({
      id: unit.id,
      name: unit.name.startsWith('Unit') ? unit.name : `Unit ${index + 1}: ${unit.name}`,
      subUnits: unit.subUnits
    }))
  }));
}

const allData = [
  ...formatData(g9, 9),
  ...formatData(g10, 10),
  ...formatData(g11, 11),
  ...formatData(g12, 12)
];

const fileContent = `export interface SubUnit {
  id: string;
  name: string;
}

export interface Unit {
  id: string;
  name: string;
  subUnits: SubUnit[];
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  grade: string;
  stream?: "Natural" | "Social";
  units: Unit[];
}

export const CURRICULUM_DATA: Subject[] = ${JSON.stringify(allData, null, 2)};
`;

fs.writeFileSync('src/data.ts', fileContent);
console.log('Successfully written to src/data.ts');
