const fs = require('fs');

const makeSkillSubunits = (unitId) => [
  { id: `${unitId}-s1`, name: "Listening and Speaking" },
  { id: `${unitId}-s2`, name: "Reading Comprehension" },
  { id: `${unitId}-s3`, name: "Vocabulary and Grammar" },
  { id: `${unitId}-s4`, name: "Writing" },
];

const grade10Subjects = [
    // ---------------- MATHEMATICS (verified: 7 units) ----------------
    {
      id: "g10-math",
      name: "Mathematics",
      units: [
        {
          id: "g10-math-u1",
          name: "Relations and Functions",
          subUnits: [
            { id: "g10-math-u1-s1", name: "Ordered Pairs and Mappings" },
            { id: "g10-math-u1-s2", name: "Domain and Range" },
            { id: "g10-math-u1-s3", name: "Graphing Relations and Functions" },
          ],
        },
        {
          id: "g10-math-u2",
          name: "Polynomial Functions",
          subUnits: [
            { id: "g10-math-u2-s1", name: "Introduction to Polynomial Functions" },
            { id: "g10-math-u2-s2", name: "Operations on Polynomials" },
            { id: "g10-math-u2-s3", name: "Zeros of Polynomials and Theorems" },
            { id: "g10-math-u2-s4", name: "Graphing Polynomial Functions" },
          ],
        },
        {
          id: "g10-math-u3",
          name: "Exponential and Logarithmic Functions",
          subUnits: [
            { id: "g10-math-u3-s1", name: "Rules of Exponents" },
            { id: "g10-math-u3-s2", name: "Exponential Functions and Graphs" },
            { id: "g10-math-u3-s3", name: "Logarithms and Their Properties" },
            { id: "g10-math-u3-s4", name: "Logarithmic Functions and Graphs" },
          ],
        },
        {
          id: "g10-math-u4",
          name: "Trigonometric Functions",
          subUnits: [
            { id: "g10-math-u4-s1", name: "Trigonometric Functions and Identities" },
            { id: "g10-math-u4-s2", name: "Graphs of Trigonometric Functions" },
            { id: "g10-math-u4-s3", name: "Solving Trigonometric Equations" },
          ],
        },
        {
          id: "g10-math-u5",
          name: "Circles",
          subUnits: [
            { id: "g10-math-u5-s1", name: "Properties of Circles" },
            { id: "g10-math-u5-s2", name: "Angles and Arcs" },
            { id: "g10-math-u5-s3", name: "Tangents and Chords" },
          ],
        },
        {
          id: "g10-math-u6",
          name: "Solid Figures",
          subUnits: [
            { id: "g10-math-u6-s1", name: "Types of Solid Figures" },
            { id: "g10-math-u6-s2", name: "Surface Area of Solids" },
            { id: "g10-math-u6-s3", name: "Volume of Solids" },
          ],
        },
        {
          id: "g10-math-u7",
          name: "Coordinate Geometry",
          subUnits: [
            { id: "g10-math-u7-s1", name: "Distance Between Two Points" },
            { id: "g10-math-u7-s2", name: "Division of a Line Segment" },
            { id: "g10-math-u7-s3", name: "Equations of Lines and Slopes" },
          ],
        },
      ],
    },

    // ---------------- PHYSICS (verified: 6 units) ----------------
    {
      id: "g10-phy",
      name: "Physics",
      units: [
        {
          id: "g10-phy-u1",
          name: "Vector Quantities",
          subUnits: [
            { id: "g10-phy-u1-s1", name: "Vector Representation and Addition" },
            { id: "g10-phy-u1-s2", name: "Resolution of Vectors" },
            { id: "g10-phy-u1-s3", name: "Applications of Vectors in Motion" },
          ],
        },
        {
          id: "g10-phy-u2",
          name: "Uniformly Accelerated Motion",
          subUnits: [
            { id: "g10-phy-u2-s1", name: "Motion in Two Dimensions" },
            { id: "g10-phy-u2-s2", name: "Projectile Motion" },
            { id: "g10-phy-u2-s3", name: "Circular Motion" },
          ],
        },
        {
          id: "g10-phy-u3",
          name: "Elasticity and Static Equilibrium of Rigid Body",
          subUnits: [
            { id: "g10-phy-u3-s1", name: "Elastic Properties of Materials" },
            { id: "g10-phy-u3-s2", name: "Torque and Moments" },
            { id: "g10-phy-u3-s3", name: "Conditions for Static Equilibrium" },
          ],
        },
        {
          id: "g10-phy-u4",
          name: "Static and Current Electricity",
          subUnits: [
            { id: "g10-phy-u4-s1", name: "Electric Charge and Coulomb's Law" },
            { id: "g10-phy-u4-s2", name: "Electric Fields and Potential" },
            { id: "g10-phy-u4-s3", name: "Electric Current, Resistance and Ohm's Law" },
            { id: "g10-phy-u4-s4", name: "Electric Circuits" },
          ],
        },
        {
          id: "g10-phy-u5",
          name: "Magnetism",
          subUnits: [
            { id: "g10-phy-u5-s1", name: "Magnetic Fields and Forces" },
            { id: "g10-phy-u5-s2", name: "Electromagnetism" },
            { id: "g10-phy-u5-s3", name: "Electromagnetic Induction" },
          ],
        },
        {
          id: "g10-phy-u6",
          name: "Electromagnetic Waves and Geometrical Optics",
          subUnits: [
            { id: "g10-phy-u6-s1", name: "The Electromagnetic Spectrum" },
            { id: "g10-phy-u6-s2", name: "Reflection of Light" },
            { id: "g10-phy-u6-s3", name: "Refraction and Lenses" },
          ],
        },
      ],
    },

    // ---------------- CHEMISTRY (unit count verified: 6;
    // unit order ⚠️ reconstructed from teacher's guide descriptions) ----------------
    {
      id: "g10-che",
      name: "Chemistry",
      units: [
        {
          id: "g10-che-u1",
          name: "Chemical Reactions and Stoichiometry",
          subUnits: [
            { id: "g10-che-u1-s1", name: "Chemical Equations and Types of Reactions" },
            { id: "g10-che-u1-s2", name: "Oxidation-Reduction Reactions" },
            { id: "g10-che-u1-s3", name: "The Mole Concept" },
            { id: "g10-che-u1-s4", name: "Stoichiometric Calculations" },
          ],
        },
        {
          id: "g10-che-u2",
          name: "Mixtures and Solutions",
          subUnits: [
            { id: "g10-che-u2-s1", name: "Heterogeneous and Homogeneous Mixtures" },
            { id: "g10-che-u2-s2", name: "Solubility" },
            { id: "g10-che-u2-s3", name: "Expressing Solution Concentration" },
          ],
        },
        {
          id: "g10-che-u3",
          name: "Acids, Bases and Salts",
          subUnits: [
            { id: "g10-che-u3-s1", name: "Properties of Acids and Bases" },
            { id: "g10-che-u3-s2", name: "pH and Indicators" },
            { id: "g10-che-u3-s3", name: "Formation and Uses of Salts" },
          ],
        },
        {
          id: "g10-che-u4",
          name: "Metals and Nonmetals",
          subUnits: [
            { id: "g10-che-u4-s1", name: "Classification and Properties of Metals and Nonmetals" },
            { id: "g10-che-u4-s2", name: "Extraction Methods" },
            { id: "g10-che-u4-s3", name: "Ethiopian Mineral Resources (Gold, Copper, Potash)" },
          ],
        },
        {
          id: "g10-che-u5",
          name: "Electrochemistry",
          subUnits: [
            { id: "g10-che-u5-s1", name: "Electrical Conductivity" },
            { id: "g10-che-u5-s2", name: "Electrolysis" },
            { id: "g10-che-u5-s3", name: "Galvanic (Voltaic) Cells" },
          ],
        },
        {
          id: "g10-che-u6",
          name: "Hydrocarbons and Their Sources",
          subUnits: [
            { id: "g10-che-u6-s1", name: "Alkanes" },
            { id: "g10-che-u6-s2", name: "Alkenes and Alkynes" },
            { id: "g10-che-u6-s3", name: "Aromatic Hydrocarbons" },
            { id: "g10-che-u6-s4", name: "Natural Sources of Hydrocarbons in Ethiopia" },
          ],
        },
      ],
    },

    // ---------------- BIOLOGY (verified: 6 units) ----------------
    {
      id: "g10-bio",
      name: "Biology",
      units: [
        {
          id: "g10-bio-u1",
          name: "Sub-fields of Biology",
          subUnits: [
            { id: "g10-bio-u1-s1", name: "Branches of Biology" },
            { id: "g10-bio-u1-s2", name: "Careers Related to Biology" },
            { id: "g10-bio-u1-s3", name: "Biology and Other Disciplines" },
          ],
        },
        {
          id: "g10-bio-u2",
          name: "Plants",
          subUnits: [
            { id: "g10-bio-u2-s1", name: "Plant Structure and Function" },
            { id: "g10-bio-u2-s2", name: "Photosynthesis and Respiration in Plants" },
            { id: "g10-bio-u2-s3", name: "Plant Growth and Development" },
            { id: "g10-bio-u2-s4", name: "Plant Classification" },
          ],
        },
        {
          id: "g10-bio-u3",
          name: "Biochemical Molecules",
          subUnits: [
            { id: "g10-bio-u3-s1", name: "Carbohydrates" },
            { id: "g10-bio-u3-s2", name: "Proteins" },
            { id: "g10-bio-u3-s3", name: "Lipids" },
            { id: "g10-bio-u3-s4", name: "Nucleic Acids" },
          ],
        },
        {
          id: "g10-bio-u4",
          name: "Cell Reproduction",
          subUnits: [
            { id: "g10-bio-u4-s1", name: "The Cell Cycle" },
            { id: "g10-bio-u4-s2", name: "Mitosis" },
            { id: "g10-bio-u4-s3", name: "Meiosis" },
          ],
        },
        {
          id: "g10-bio-u5",
          name: "Human Biology",
          subUnits: [
            { id: "g10-bio-u5-s1", name: "The Digestive System" },
            { id: "g10-bio-u5-s2", name: "The Circulatory System" },
            { id: "g10-bio-u5-s3", name: "The Respiratory System" },
            { id: "g10-bio-u5-s4", name: "The Nervous System" },
          ],
        },
        {
          id: "g10-bio-u6",
          name: "Ecological Interaction",
          subUnits: [
            { id: "g10-bio-u6-s1", name: "Interactions Within Ecosystems" },
            { id: "g10-bio-u6-s2", name: "Population Ecology" },
            { id: "g10-bio-u6-s3", name: "Human Impact on Ecological Balance" },
          ],
        },
      ],
    },

    // ---------------- ENGLISH (unit count verified: 10;
    // Units 1–2 ⚠️ UNVERIFIED, 3–10 grounded in teacher's guide chapter list) ----------------
    {
      id: "g10-eng",
      name: "English",
      units: [
        { id: "g10-eng-u1", name: "Unit 1 (TBD — verify against textbook)", subUnits: makeSkillSubunits("g10-eng-u1") },
        { id: "g10-eng-u2", name: "Unit 2 (TBD — verify against textbook)", subUnits: makeSkillSubunits("g10-eng-u2") },
        { id: "g10-eng-u3", name: "Punctuality", subUnits: makeSkillSubunits("g10-eng-u3") },
        { id: "g10-eng-u4", name: "Tourist Attractions", subUnits: makeSkillSubunits("g10-eng-u4") },
        { id: "g10-eng-u5", name: "Honey Production and Processing", subUnits: makeSkillSubunits("g10-eng-u5") },
        { id: "g10-eng-u6", name: "Migration", subUnits: makeSkillSubunits("g10-eng-u6") },
        { id: "g10-eng-u7", name: "Branding Ethiopia and National Identity", subUnits: makeSkillSubunits("g10-eng-u7") },
        { id: "g10-eng-u8", name: "Traditional Medicine and Moringa", subUnits: makeSkillSubunits("g10-eng-u8") },
        { id: "g10-eng-u9", name: "Multilingualism in Ethiopia", subUnits: makeSkillSubunits("g10-eng-u9") },
        { id: "g10-eng-u10", name: "Digital vs. Satellite Television", subUnits: makeSkillSubunits("g10-eng-u10") },
      ],
    },

    // ---------------- HISTORY (unit count verified: 9;
    // Units 3–6 confirmed verbatim from textbook ToC; 1,2,7,8,9 ⚠️ reconstructed) ----------------
    {
      id: "g10-his",
      name: "History",
      units: [
        {
          id: "g10-his-u1",
          name: "Capitalism and Nationalism in 19th-Century Europe",
          subUnits: [
            { id: "g10-his-u1-s1", name: "Rise of Industrial Capitalism" },
            { id: "g10-his-u1-s2", name: "Nationalism and Unification Movements" },
            { id: "g10-his-u1-s3", name: "European Political Change, 1815–1870s" },
          ],
        },
        {
          id: "g10-his-u2",
          name: "Colonialism in Africa",
          subUnits: [
            { id: "g10-his-u2-s1", name: "The Scramble for Africa" },
            { id: "g10-his-u2-s2", name: "Colonial Administration Systems" },
            { id: "g10-his-u2-s3", name: "African Resistance to Colonialism" },
          ],
        },
        {
          id: "g10-his-u3",
          name: "Social, Economic and Political Developments in Ethiopia mid-19th C. to 1941",
          subUnits: [
            { id: "g10-his-u3-s1", name: "Long-Distance Trade" },
            { id: "g10-his-u3-s2", name: "The Making of the Modern Ethiopian State" },
            { id: "g10-his-u3-s3", name: "External Aggression and Patriotic Resistance" },
          ],
        },
        {
          id: "g10-his-u4",
          name: "Society and Politics in the Age of World Wars 1914-1945",
          subUnits: [
            { id: "g10-his-u4-s1", name: "Causes and Consequences of World War I" },
            { id: "g10-his-u4-s2", name: "The Russian Revolution and the League of Nations" },
            { id: "g10-his-u4-s3", name: "The Great Depression and the Rise of Fascism" },
          ],
        },
        {
          id: "g10-his-u5",
          name: "Global and Regional Developments Since 1945",
          subUnits: [
            { id: "g10-his-u5-s1", name: "Formation and Achievements of the United Nations" },
            { id: "g10-his-u5-s2", name: "Rise of the Superpowers and Onset of the Cold War" },
            { id: "g10-his-u5-s3", name: "Cold War Dynamics in Asia" },
          ],
        },
        {
          id: "g10-his-u6",
          name: "Ethiopia: Internal Developments and External Influences from 1941 to 1991",
          subUnits: [
            { id: "g10-his-u6-s1", name: "Post-1941 Political and Economic Change" },
            { id: "g10-his-u6-s2", name: "The 1974 Revolution and the Derg Period" },
            { id: "g10-his-u6-s3", name: "External Relations, 1941–1991" },
          ],
        },
        {
          id: "g10-his-u7",
          name: "Post-1991 Ethiopia",
          subUnits: [
            { id: "g10-his-u7-s1", name: "Political Transition After 1991" },
            { id: "g10-his-u7-s2", name: "Federal Restructuring" },
            { id: "g10-his-u7-s3", name: "Recent Economic and Social Developments" },
          ],
        },
        {
          id: "g10-his-u8",
          name: "Indigenous Knowledge and Heritage in Ethiopia",
          subUnits: [
            { id: "g10-his-u8-s1", name: "Indigenous Knowledge Systems" },
            { id: "g10-his-u8-s2", name: "Cultural and Historical Heritage Sites" },
            { id: "g10-his-u8-s3", name: "Preservation and Value of Heritage" },
          ],
        },
        {
          id: "g10-his-u9",
          name: "Ethiopia and the Horn in Contemporary Times",
          subUnits: [
            { id: "g10-his-u9-s1", name: "Regional Relations in the Horn of Africa" },
            { id: "g10-his-u9-s2", name: "Contemporary Challenges and Cooperation" },
            { id: "g10-his-u9-s3", name: "Ethiopia's Role in Regional Affairs" },
          ],
        },
      ],
    },

    // ---------------- GEOGRAPHY (verified: 8 units) ----------------
    {
      id: "g10-geo",
      name: "Geography",
      units: [
        {
          id: "g10-geo-u1",
          name: "Landforms of Africa",
          subUnits: [
            { id: "g10-geo-u1-s1", name: "Major Landform Regions of Africa" },
            { id: "g10-geo-u1-s2", name: "The Atlas Mountains, Sahara and Sahel" },
            { id: "g10-geo-u1-s3", name: "The Rift Valley and Southern African Highlands" },
          ],
        },
        {
          id: "g10-geo-u2",
          name: "Climate of Africa",
          subUnits: [
            { id: "g10-geo-u2-s1", name: "Factors Affecting African Climate" },
            { id: "g10-geo-u2-s2", name: "Climate Zones of Africa" },
            { id: "g10-geo-u2-s3", name: "Climate Change Impacts on Africa" },
          ],
        },
        {
          id: "g10-geo-u3",
          name: "Drainage Systems and Natural Resources of Africa",
          subUnits: [
            { id: "g10-geo-u3-s1", name: "Major River Basins and Lakes of Africa" },
            { id: "g10-geo-u3-s2", name: "Mineral Resources of Africa" },
            { id: "g10-geo-u3-s3", name: "Ecosystems and Resource Conservation" },
          ],
        },
        {
          id: "g10-geo-u4",
          name: "Population of Africa",
          subUnits: [
            { id: "g10-geo-u4-s1", name: "Demographic Trends and Age Structure" },
            { id: "g10-geo-u4-s2", name: "Urbanization in Africa" },
            { id: "g10-geo-u4-s3", name: "Rural Life and Settlement Patterns" },
          ],
        },
        {
          id: "g10-geo-u5",
          name: "Major Economic and Cultural Activities of Africa",
          subUnits: [
            { id: "g10-geo-u5-s1", name: "Employment Structure and Unemployment" },
            { id: "g10-geo-u5-s2", name: "Agenda 2063 and the Sustainable Development Goals" },
            { id: "g10-geo-u5-s3", name: "Linguistic and Religious Diversity in Africa" },
          ],
        },
        {
          id: "g10-geo-u6",
          name: "Population Change and Human-Environment Relationships in Africa",
          subUnits: [
            { id: "g10-geo-u6-s1", name: "Global Population Change" },
            { id: "g10-geo-u6-s2", name: "Human-Environment Interaction" },
            { id: "g10-geo-u6-s3", name: "Indigenous Knowledge in Resource Conservation" },
          ],
        },
        {
          id: "g10-geo-u7",
          name: "Geographic Issues and Public Concerns in Africa",
          subUnits: [
            { id: "g10-geo-u7-s1", name: "Unplanned Urbanization" },
            { id: "g10-geo-u7-s2", name: "Migration Issues" },
            { id: "g10-geo-u7-s3", name: "Coastal Pollution" },
          ],
        },
        {
          id: "g10-geo-u8",
          name: "Geospatial Information and Data Processing",
          subUnits: [
            { id: "g10-geo-u8-s1", name: "Basic Concepts of Geospatial Information" },
            { id: "g10-geo-u8-s2", name: "Sources and Tools of Geographic Data" },
            { id: "g10-geo-u8-s3", name: "Interpreting Graphs, Charts and Maps" },
          ],
        },
      ],
    },

    // ---------------- CITIZENSHIP EDUCATION ⚠️ UNVERIFIED titles
    // (count = 8 confirmed; only broad themes — democracy, digital ethics,
    // governance, patriotism — confirmed) ----------------
    {
      id: "g10-cve",
      name: "Citizenship Education",
      units: [
        {
          id: "g10-cve-u1",
          name: "Democracy and Democratic Systems",
          subUnits: [
            { id: "g10-cve-u1-s1", name: "Principles of Democracy" },
            { id: "g10-cve-u1-s2", name: "Representative Democracy in Ethiopia" },
            { id: "g10-cve-u1-s3", name: "Challenges to Democracy" },
          ],
        },
        {
          id: "g10-cve-u2",
          name: "Digital Ethics and Citizenship",
          subUnits: [
            { id: "g10-cve-u2-s1", name: "Ethics in the Digital Age" },
            { id: "g10-cve-u2-s2", name: "Digital Rights and Responsibilities" },
            { id: "g10-cve-u2-s3", name: "Combating Misinformation" },
          ],
        },
        {
          id: "g10-cve-u3",
          name: "Governance and Public Institutions",
          subUnits: [
            { id: "g10-cve-u3-s1", name: "Structure of Government in Ethiopia" },
            { id: "g10-cve-u3-s2", name: "Transparency and Accountability" },
            { id: "g10-cve-u3-s3", name: "Federalism in Ethiopia" },
          ],
        },
        {
          id: "g10-cve-u4",
          name: "Patriotism and National Service",
          subUnits: [
            { id: "g10-cve-u4-s1", name: "Meaning of Patriotism" },
            { id: "g10-cve-u4-s2", name: "National Service and Civic Duty" },
            { id: "g10-cve-u4-s3", name: "Patriotism in Ethiopian History" },
          ],
        },
        {
          id: "g10-cve-u5",
          name: "Human Rights and Responsibilities",
          subUnits: [
            { id: "g10-cve-u5-s1", name: "Fundamental Human Rights" },
            { id: "g10-cve-u5-s2", name: "Rights and Corresponding Responsibilities" },
            { id: "g10-cve-u5-s3", name: "Protecting Vulnerable Groups" },
          ],
        },
        {
          id: "g10-cve-u6",
          name: "Rule of Law and Justice",
          subUnits: [
            { id: "g10-cve-u6-s1", name: "The Constitution and Rule of Law" },
            { id: "g10-cve-u6-s2", name: "The Justice System in Ethiopia" },
            { id: "g10-cve-u6-s3", name: "Anti-Corruption Measures" },
          ],
        },
        {
          id: "g10-cve-u7",
          name: "Civic Participation",
          subUnits: [
            { id: "g10-cve-u7-s1", name: "Forms of Civic Participation" },
            { id: "g10-cve-u7-s2", name: "Community Organizations" },
            { id: "g10-cve-u7-s3", name: "Youth Participation in Civic Life" },
          ],
        },
        {
          id: "g10-cve-u8",
          name: "Ethiopia's Role in Regional and Global Affairs",
          subUnits: [
            { id: "g10-cve-u8-s1", name: "Ethiopia's Foreign Policy Priorities" },
            { id: "g10-cve-u8-s2", name: "Regional Organizations and Cooperation" },
            { id: "g10-cve-u8-s3", name: "Ethiopia in International Institutions" },
          ],
        },
      ],
    },

    // ---------------- ECONOMICS (verified: 8 units; U1–U4 and U8
    // confirmed verbatim, U5–U7 ⚠️ reconstructed) ----------------
    {
      id: "g10-eco",
      name: "Economics",
      units: [
        {
          id: "g10-eco-u1",
          name: "Theory of Consumer Behaviour",
          subUnits: [
            { id: "g10-eco-u1-s1", name: "The Concept of Utility" },
            { id: "g10-eco-u1-s2", name: "The Cardinal Utility Theory" },
            { id: "g10-eco-u1-s3", name: "The Consumer Maximization Problem" },
            { id: "g10-eco-u1-s4", name: "Introduction to the Ordinal Utility Theory" },
          ],
        },
        {
          id: "g10-eco-u2",
          name: "Theories of Demand and Supply",
          subUnits: [
            { id: "g10-eco-u2-s1", name: "Theory of Demand" },
            { id: "g10-eco-u2-s2", name: "Theory of Supply" },
            { id: "g10-eco-u2-s3", name: "Market Equilibrium" },
            { id: "g10-eco-u2-s4", name: "Elasticities of Demand and Supply" },
          ],
        },
        {
          id: "g10-eco-u3",
          name: "Theories of Production and Cost",
          subUnits: [
            { id: "g10-eco-u3-s1", name: "Theory of Production" },
            { id: "g10-eco-u3-s2", name: "Short-Run and Long-Run Costs" },
            { id: "g10-eco-u3-s3", name: "Cost Minimization" },
          ],
        },
        {
          id: "g10-eco-u4",
          name: "Market Structure",
          subUnits: [
            { id: "g10-eco-u4-s1", name: "Perfectly Competitive Markets" },
            { id: "g10-eco-u4-s2", name: "Pure Monopoly Market" },
            { id: "g10-eco-u4-s3", name: "Monopolistically Competitive Market" },
            { id: "g10-eco-u4-s4", name: "Oligopoly Market" },
          ],
        },
        {
          id: "g10-eco-u5",
          name: "National Income Accounting",
          subUnits: [
            { id: "g10-eco-u5-s1", name: "Measuring GDP and GNP" },
            { id: "g10-eco-u5-s2", name: "Approaches to National Income Measurement" },
            { id: "g10-eco-u5-s3", name: "Limitations of National Income Statistics" },
          ],
        },
        {
          id: "g10-eco-u6",
          name: "Money, Banking and Public Finance",
          subUnits: [
            { id: "g10-eco-u6-s1", name: "Functions and Types of Money" },
            { id: "g10-eco-u6-s2", name: "The Banking System" },
            { id: "g10-eco-u6-s3", name: "Government Revenue and Expenditure" },
          ],
        },
        {
          id: "g10-eco-u7",
          name: "The Ethiopian Economy: Sectors and Development",
          subUnits: [
            { id: "g10-eco-u7-s1", name: "Agricultural Sector" },
            { id: "g10-eco-u7-s2", name: "Industrial Sector" },
            { id: "g10-eco-u7-s3", name: "Service Sector and Development Strategy" },
          ],
        },
        {
          id: "g10-eco-u8",
          name: "Business Startups and Innovation",
          subUnits: [
            { id: "g10-eco-u8-s1", name: "Innovation and Entrepreneurship" },
            { id: "g10-eco-u8-s2", name: "Types of Business Organizations" },
            { id: "g10-eco-u8-s3", name: "Feasibility Analysis for Startups" },
          ],
        },
      ],
    },

    // ---------------- AMHARIC ⚠️ MOSTLY UNVERIFIED
    // (9 units confirmed; only 3 themes confirmed — Language & Society,
    // Marriage Traditions, Women in Development — placed at u1, u5, u6;
    // remaining 6 are generic placeholders) ----------------
    {
      id: "g10-amh",
      name: "Amharic",
      units: [
        { id: "g10-amh-u1", name: "Language and Society", subUnits: makeSkillSubunits("g10-amh-u1") },
        { id: "g10-amh-u2", name: "Unit 2 (TBD — verify against textbook)", subUnits: makeSkillSubunits("g10-amh-u2") },
        { id: "g10-amh-u3", name: "Unit 3 (TBD — verify against textbook)", subUnits: makeSkillSubunits("g10-amh-u3") },
        { id: "g10-amh-u4", name: "Unit 4 (TBD — verify against textbook)", subUnits: makeSkillSubunits("g10-amh-u4") },
        { id: "g10-amh-u5", name: "Marriage Traditions in Ethiopia", subUnits: makeSkillSubunits("g10-amh-u5") },
        { id: "g10-amh-u6", name: "Women in Development", subUnits: makeSkillSubunits("g10-amh-u6") },
        { id: "g10-amh-u7", name: "Unit 7 (TBD — verify against textbook)", subUnits: makeSkillSubunits("g10-amh-u7") },
        { id: "g10-amh-u8", name: "Unit 8 (TBD — verify against textbook)", subUnits: makeSkillSubunits("g10-amh-u8") },
        { id: "g10-amh-u9", name: "Unit 9 (TBD — verify against textbook)", subUnits: makeSkillSubunits("g10-amh-u9") },
      ],
    },

    // ---------------- ICT (verified: 6 units — same structure as Grade 9) ----------------
    {
      id: "g10-ict",
      name: "Information Technology",
      units: [
        {
          id: "g10-ict-u1",
          name: "Organization of Files",
          subUnits: [
            { id: "g10-ict-u1-s1", name: "Advanced File and Folder Management" },
            { id: "g10-ict-u1-s2", name: "File Systems and Storage Devices" },
            { id: "g10-ict-u1-s3", name: "Backup Strategies" },
          ],
        },
        {
          id: "g10-ict-u2",
          name: "Computer Network",
          subUnits: [
            { id: "g10-ict-u2-s1", name: "Network Architecture and Protocols" },
            { id: "g10-ict-u2-s2", name: "Wired and Wireless Networking" },
            { id: "g10-ict-u2-s3", name: "Network Troubleshooting Basics" },
          ],
        },
        {
          id: "g10-ict-u3",
          name: "Application Software",
          subUnits: [
            { id: "g10-ict-u3-s1", name: "Advanced Word Processing" },
            { id: "g10-ict-u3-s2", name: "Advanced Spreadsheet Functions" },
            { id: "g10-ict-u3-s3", name: "Database Management Systems" },
          ],
        },
        {
          id: "g10-ict-u4",
          name: "Image Processing and Multimedia",
          subUnits: [
            { id: "g10-ict-u4-s1", name: "Image File Formats and Editing" },
            { id: "g10-ict-u4-s2", name: "Audio and Video Editing Basics" },
            { id: "g10-ict-u4-s3", name: "Multimedia Project Production" },
          ],
        },
        {
          id: "g10-ict-u5",
          name: "Information and Computer Security",
          subUnits: [
            { id: "g10-ict-u5-s1", name: "Types of Cyber Threats" },
            { id: "g10-ict-u5-s2", name: "Data Encryption and Protection" },
            { id: "g10-ict-u5-s3", name: "Digital Ethics and Legal Issues" },
          ],
        },
        {
          id: "g10-ict-u6",
          name: "Fundamentals of Programming",
          subUnits: [
            { id: "g10-ict-u6-s1", name: "Variables, Data Types and Operators" },
            { id: "g10-ict-u6-s2", name: "Control Structures" },
            { id: "g10-ict-u6-s3", name: "Writing and Debugging Simple Programs" },
          ],
        },
      ],
    },

    // ---------------- HEALTH AND PHYSICAL EDUCATION
    // (verified: 8 units, same structure as Grade 9 at a more advanced level) ----------------
    {
      id: "g10-hpe",
      name: "Health and Physical Education",
      units: [
        {
          id: "g10-hpe-u1",
          name: "Sport and Society",
          subUnits: [
            { id: "g10-hpe-u1-s1", name: "Sport, Media and Politics" },
            { id: "g10-hpe-u1-s2", name: "Sport and Religion" },
            { id: "g10-hpe-u1-s3", name: "Sport for Humanitarian and Peace Development" },
          ],
        },
        {
          id: "g10-hpe-u2",
          name: "Health and Physical Fitness",
          subUnits: [
            { id: "g10-hpe-u2-s1", name: "Advanced Components of Fitness" },
            { id: "g10-hpe-u2-s2", name: "Fitness Testing and Evaluation" },
            { id: "g10-hpe-u2-s3", name: "Designing a Personal Fitness Program" },
          ],
        },
        {
          id: "g10-hpe-u3",
          name: "Athletics",
          subUnits: [
            { id: "g10-hpe-u3-s1", name: "Advanced Track Techniques" },
            { id: "g10-hpe-u3-s2", name: "Advanced Field Techniques" },
            { id: "g10-hpe-u3-s3", name: "Competition Rules and Officiating" },
          ],
        },
        {
          id: "g10-hpe-u4",
          name: "Football",
          subUnits: [
            { id: "g10-hpe-u4-s1", name: "Advanced Techniques and Tactics" },
            { id: "g10-hpe-u4-s2", name: "Team Strategy and Positioning" },
            { id: "g10-hpe-u4-s3", name: "Officiating and Safety" },
          ],
        },
        {
          id: "g10-hpe-u5",
          name: "Volleyball",
          subUnits: [
            { id: "g10-hpe-u5-s1", name: "Advanced Techniques and Tactics" },
            { id: "g10-hpe-u5-s2", name: "Team Strategy and Positioning" },
            { id: "g10-hpe-u5-s3", name: "Officiating and Safety" },
          ],
        },
        {
          id: "g10-hpe-u6",
          name: "Basketball",
          subUnits: [
            { id: "g10-hpe-u6-s1", name: "Advanced Techniques and Tactics" },
            { id: "g10-hpe-u6-s2", name: "Team Strategy and Positioning" },
            { id: "g10-hpe-u6-s3", name: "Officiating and Safety" },
          ],
        },
        {
          id: "g10-hpe-u7",
          name: "Handball",
          subUnits: [
            { id: "g10-hpe-u7-s1", name: "Advanced Techniques and Tactics" },
            { id: "g10-hpe-u7-s2", name: "Team Strategy and Positioning" },
            { id: "g10-hpe-u7-s3", name: "Officiating and Safety" },
          ],
        },
        {
          id: "g10-hpe-u8",
          name: "Self-Defense and Sport Ethics",
          subUnits: [
            { id: "g10-hpe-u8-s1", name: "Intermediate Self-Defense Techniques" },
            { id: "g10-hpe-u8-s2", name: "Doping and Its Consequences" },
            { id: "g10-hpe-u8-s3", name: "Ethics, Fair Play and Injury Prevention" },
          ],
        },
      ],
    },
];

fs.writeFileSync("grade10.json", JSON.stringify(grade10Subjects));
