import { initializeApp, getApp, getApps } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithRedirect, signInWithPopup, getRedirectResult, signOut, onAuthStateChanged } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// Read from env with fallback to firebase-applet-config.json
const metaEnv = (import.meta as any).env || {};

const firebaseConfig = {
  apiKey: metaEnv.VITE_FIREBASE_API_KEY || "AIzaSyBw1Hyf7F_HWZU8nJQ9q2P2yfY2-dPk050",
  authDomain: metaEnv.VITE_FIREBASE_AUTH_DOMAIN || "lively-pipe-jd2jw.firebaseapp.com",
  projectId: metaEnv.VITE_FIREBASE_PROJECT_ID || "lively-pipe-jd2jw",
  storageBucket: metaEnv.VITE_FIREBASE_STORAGE_BUCKET || "lively-pipe-jd2jw.firebasestorage.app",
  messagingSenderId: metaEnv.VITE_FIREBASE_MESSAGING_SENDER_ID || "637000654202",
  appId: metaEnv.VITE_FIREBASE_APP_ID || "1:637000654202:web:172fb12339effed98c8ac3"
};

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const auth = getAuth(app);

// Connect to the specific database instance: "ai-studio-3f374b50-9b5a-4609-b07b-a9eeca5546e3"
const databaseId = "ai-studio-3f374b50-9b5a-4609-b07b-a9eeca5546e3";
const db = getFirestore(app, databaseId);

const googleProvider = new GoogleAuthProvider();
// Set default parameters for Google sign in if desired
googleProvider.setCustomParameters({
  prompt: "select_account"
});

export { app, auth, db, googleProvider, signInWithRedirect, signInWithPopup, getRedirectResult, signOut, onAuthStateChanged };
