export interface SubUnit {
  id: string;
  name: string;
}

export interface Unit {
  id: string;
  name: string;
  subUnits: SubUnit[];
}

export interface Subject {
  id: string;
  name: string;
  icon: string;
  grade: string;
  stream?: "Natural" | "Social";
  units: Unit[];
}

export const CURRICULUM_DATA: Subject[] = [
  {
    id: "g9-math",
    name: "Mathematics",
    icon: "Calculator",
    grade: "9",
    units: [
      {
        id: "g9-math-u1",
        name: "Unit 1: Further on Sets",
        subUnits: [
          {
            id: "g9-math-u1-s1",
            name: "Ideas of Sets",
          },
          {
            id: "g9-math-u1-s2",
            name: "Operations on Sets",
          },
          {
            id: "g9-math-u1-s3",
            name: "Venn Diagrams",
          },
          {
            id: "g9-math-u1-s4",
            name: "Applications of Sets",
          },
        ],
      },
      {
        id: "g9-math-u2",
        name: "Unit 2: The Number System",
        subUnits: [
          {
            id: "g9-math-u2-s1",
            name: "Revision on Rational Numbers",
          },
          {
            id: "g9-math-u2-s2",
            name: "Irrational Numbers",
          },
          {
            id: "g9-math-u2-s3",
            name: "The Real Number System",
          },
          {
            id: "g9-math-u2-s4",
            name: "Significant Figures and Rounding",
          },
        ],
      },
      {
        id: "g9-math-u3",
        name: "Unit 3: Solving Equations",
        subUnits: [
          {
            id: "g9-math-u3-s1",
            name: "Equations Involving Exponents and Radicals",
          },
          {
            id: "g9-math-u3-s2",
            name: "Systems of Linear Equations",
          },
          {
            id: "g9-math-u3-s3",
            name: "Equations Involving Absolute Value",
          },
          {
            id: "g9-math-u3-s4",
            name: "Quadratic Equations",
          },
        ],
      },
      {
        id: "g9-math-u4",
        name: "Unit 4: Solving Inequalities",
        subUnits: [
          {
            id: "g9-math-u4-s1",
            name: "Linear Inequalities",
          },
          {
            id: "g9-math-u4-s2",
            name: "Systems of Linear Inequalities",
          },
          {
            id: "g9-math-u4-s3",
            name: "Inequalities Involving Absolute Value",
          },
          {
            id: "g9-math-u4-s4",
            name: "Quadratic Inequalities",
          },
        ],
      },
      {
        id: "g9-math-u5",
        name: "Unit 5: Introduction to Trigonometry",
        subUnits: [
          {
            id: "g9-math-u5-s1",
            name: "Basic Trigonometric Ratios",
          },
          {
            id: "g9-math-u5-s2",
            name: "Trigonometric Values of Special Angles",
          },
          {
            id: "g9-math-u5-s3",
            name: "Solving Right-Angled Triangles",
          },
          {
            id: "g9-math-u5-s4",
            name: "Applications of Trigonometry",
          },
        ],
      },
      {
        id: "g9-math-u6",
        name: "Unit 6: Regular Polygons",
        subUnits: [
          {
            id: "g9-math-u6-s1",
            name: "Properties of Regular Polygons",
          },
          {
            id: "g9-math-u6-s2",
            name: "Interior and Exterior Angles",
          },
          {
            id: "g9-math-u6-s3",
            name: "Perimeter and Area of Regular Polygons",
          },
        ],
      },
      {
        id: "g9-math-u7",
        name: "Unit 7: Congruency and Similarity",
        subUnits: [
          {
            id: "g9-math-u7-s1",
            name: "Congruency of Triangles",
          },
          {
            id: "g9-math-u7-s2",
            name: "Similarity of Triangles",
          },
          {
            id: "g9-math-u7-s3",
            name: "Theorems on Similar Figures",
          },
          {
            id: "g9-math-u7-s4",
            name: "Applications of Similarity",
          },
        ],
      },
      {
        id: "g9-math-u8",
        name: "Unit 8: Vectors in Two Dimensions",
        subUnits: [
          {
            id: "g9-math-u8-s1",
            name: "Scalar and Vector Quantities",
          },
          {
            id: "g9-math-u8-s2",
            name: "Representation of Vectors",
          },
          {
            id: "g9-math-u8-s3",
            name: "Operations on Vectors",
          },
          {
            id: "g9-math-u8-s4",
            name: "Position Vectors",
          },
        ],
      },
      {
        id: "g9-math-u9",
        name: "Unit 9: Statistics and Probability",
        subUnits: [
          {
            id: "g9-math-u9-s1",
            name: "Collection and Presentation of Data",
          },
          {
            id: "g9-math-u9-s2",
            name: "Measures of Central Tendency and Dispersion",
          },
          {
            id: "g9-math-u9-s3",
            name: "Basic Probability Concepts",
          },
          {
            id: "g9-math-u9-s4",
            name: "Probability of Events",
          },
        ],
      },
    ],
  },
  {
    id: "g9-phy",
    name: "Physics",
    icon: "Atom",
    grade: "9",
    units: [
      {
        id: "g9-phy-u1",
        name: "Unit 1: Introduction to Physics",
        subUnits: [
          {
            id: "g9-phy-u1-s1",
            name: "Definition and Nature of Physics",
          },
          {
            id: "g9-phy-u1-s2",
            name: "Branches of Physics",
          },
          {
            id: "g9-phy-u1-s3",
            name: "Relationship with Other Sciences",
          },
        ],
      },
      {
        id: "g9-phy-u2",
        name: "Unit 2: Physical Quantities and Measurement",
        subUnits: [
          {
            id: "g9-phy-u2-s1",
            name: "Fundamental and Derived Quantities",
          },
          {
            id: "g9-phy-u2-s2",
            name: "SI Units and Unit Conversion",
          },
          {
            id: "g9-phy-u2-s3",
            name: "Measurement and Uncertainty",
          },
        ],
      },
      {
        id: "g9-phy-u3",
        name: "Unit 3: Motion, Force, Work, Energy and Power",
        subUnits: [
          {
            id: "g9-phy-u3-s1",
            name: "Motion in a Straight Line",
          },
          {
            id: "g9-phy-u3-s2",
            name: "Newton's Laws of Motion",
          },
          {
            id: "g9-phy-u3-s3",
            name: "Work, Energy and Power",
          },
        ],
      },
      {
        id: "g9-phy-u4",
        name: "Unit 4: Simple Machines",
        subUnits: [
          {
            id: "g9-phy-u4-s1",
            name: "Purpose and Types of Simple Machines",
          },
          {
            id: "g9-phy-u4-s2",
            name: "Mechanical Advantage and Efficiency",
          },
          {
            id: "g9-phy-u4-s3",
            name: "Levers, Inclined Planes and Pulleys",
          },
        ],
      },
      {
        id: "g9-phy-u5",
        name: "Unit 5: Fluid Statics",
        subUnits: [
          {
            id: "g9-phy-u5-s1",
            name: "Air Pressure",
          },
          {
            id: "g9-phy-u5-s2",
            name: "Fluid Pressure",
          },
          {
            id: "g9-phy-u5-s3",
            name: "Applications of Fluid Statics",
          },
        ],
      },
      {
        id: "g9-phy-u6",
        name: "Unit 6: Heat and Temperature",
        subUnits: [
          {
            id: "g9-phy-u6-s1",
            name: "Temperature and Heat Energy",
          },
          {
            id: "g9-phy-u6-s2",
            name: "Thermal Expansion",
          },
          {
            id: "g9-phy-u6-s3",
            name: "Specific Heat Capacity and Change of State",
          },
        ],
      },
      {
        id: "g9-phy-u7",
        name: "Unit 7: Wave Motion and Sound",
        subUnits: [
          {
            id: "g9-phy-u7-s1",
            name: "Wave Propagation",
          },
          {
            id: "g9-phy-u7-s2",
            name: "Properties of Mechanical Waves",
          },
          {
            id: "g9-phy-u7-s3",
            name: "Sound Waves",
          },
        ],
      },
    ],
  },
  {
    id: "g9-che",
    name: "Chemistry",
    icon: "FlaskConical",
    grade: "9",
    units: [
      {
        id: "g9-che-u1",
        name: "Unit 1: Chemistry and Its Importance",
        subUnits: [
          {
            id: "g9-che-u1-s1",
            name: "Definition and Scope of Chemistry",
          },
          {
            id: "g9-che-u1-s2",
            name: "Relationship Between Chemistry and Other Natural Sciences",
          },
          {
            id: "g9-che-u1-s3",
            name: "Role of Chemistry in Production and Society",
          },
          {
            id: "g9-che-u1-s4",
            name: "Common Chemical Industries in Ethiopia",
          },
        ],
      },
      {
        id: "g9-che-u2",
        name: "Unit 2: Measurements and Scientific Methods",
        subUnits: [
          {
            id: "g9-che-u2-s1",
            name: "Measurements and Units in Chemistry",
          },
          {
            id: "g9-che-u2-s2",
            name: "Chemistry as Experimental Science",
          },
        ],
      },
      {
        id: "g9-che-u3",
        name: "Unit 3: Structure of the Atom",
        subUnits: [
          {
            id: "g9-che-u3-s1",
            name: "Historical Development of Atomic Theories",
          },
          {
            id: "g9-che-u3-s2",
            name: "Fundamental Laws of Chemical Reactions",
          },
          {
            id: "g9-che-u3-s3",
            name: "Atomic Theory",
          },
          {
            id: "g9-che-u3-s4",
            name: "Discovery of Subatomic Particles and the Nucleus",
          },
          {
            id: "g9-che-u3-s5",
            name: "Composition of an Atom and Isotopes",
          },
        ],
      },
      {
        id: "g9-che-u4",
        name: "Unit 4: Periodic Classification of Elements",
        subUnits: [
          {
            id: "g9-che-u4-s1",
            name: "Historical Development of Periodic Classification",
          },
          {
            id: "g9-che-u4-s2",
            name: "Mendeleev's Classification",
          },
          {
            id: "g9-che-u4-s3",
            name: "The Modern Periodic Table",
          },
          {
            id: "g9-che-u4-s4",
            name: "Periodic Trends and Properties",
          },
        ],
      },
      {
        id: "g9-che-u5",
        name: "Unit 5: Chemical Bonding",
        subUnits: [
          {
            id: "g9-che-u5-s1",
            name: "Ionic Bonding",
          },
          {
            id: "g9-che-u5-s2",
            name: "Covalent Bonding",
          },
          {
            id: "g9-che-u5-s3",
            name: "Metallic Bonding",
          },
          {
            id: "g9-che-u5-s4",
            name: "Bond Polarity and Molecular Shape",
          },
        ],
      },
    ],
  },
  {
    id: "g9-bio",
    name: "Biology",
    icon: "Dna",
    grade: "9",
    units: [
      {
        id: "g9-bio-u1",
        name: "Unit 1: Introduction to Biology",
        subUnits: [
          {
            id: "g9-bio-u1-s1",
            name: "Definition, Scope and Branches of Biology",
          },
          {
            id: "g9-bio-u1-s2",
            name: "Importance of Biology",
          },
          {
            id: "g9-bio-u1-s3",
            name: "Scientific Methods in Biology",
          },
        ],
      },
      {
        id: "g9-bio-u2",
        name: "Unit 2: Characteristics and Classification of Organisms",
        subUnits: [
          {
            id: "g9-bio-u2-s1",
            name: "Characteristics of Living Things",
          },
          {
            id: "g9-bio-u2-s2",
            name: "Classification Systems",
          },
          {
            id: "g9-bio-u2-s3",
            name: "Kingdom Classification",
          },
          {
            id: "g9-bio-u2-s4",
            name: "Binomial Nomenclature",
          },
        ],
      },
      {
        id: "g9-bio-u3",
        name: "Unit 3: Cells",
        subUnits: [
          {
            id: "g9-bio-u3-s1",
            name: "Cell Theory",
          },
          {
            id: "g9-bio-u3-s2",
            name: "Prokaryotic and Eukaryotic Cells",
          },
          {
            id: "g9-bio-u3-s3",
            name: "Cell Organelles and Functions",
          },
          {
            id: "g9-bio-u3-s4",
            name: "Cell Division",
          },
        ],
      },
      {
        id: "g9-bio-u4",
        name: "Unit 4: Reproduction",
        subUnits: [
          {
            id: "g9-bio-u4-s1",
            name: "Asexual Reproduction",
          },
          {
            id: "g9-bio-u4-s2",
            name: "Sexual Reproduction",
          },
          {
            id: "g9-bio-u4-s3",
            name: "Reproduction in Plants",
          },
          {
            id: "g9-bio-u4-s4",
            name: "Reproduction in Animals",
          },
        ],
      },
      {
        id: "g9-bio-u5",
        name: "Unit 5: Human Health, Nutrition, and Disease",
        subUnits: [
          {
            id: "g9-bio-u5-s1",
            name: "Nutrition and Balanced Diet",
          },
          {
            id: "g9-bio-u5-s2",
            name: "Human Health and Hygiene",
          },
          {
            id: "g9-bio-u5-s3",
            name: "Communicable and Non-Communicable Diseases",
          },
          {
            id: "g9-bio-u5-s4",
            name: "HIV/AIDS and Other STIs",
          },
        ],
      },
      {
        id: "g9-bio-u6",
        name: "Unit 6: Ecology",
        subUnits: [
          {
            id: "g9-bio-u6-s1",
            name: "Ecosystem Concepts",
          },
          {
            id: "g9-bio-u6-s2",
            name: "Energy Flow and Food Chains",
          },
          {
            id: "g9-bio-u6-s3",
            name: "Biogeochemical Cycles",
          },
          {
            id: "g9-bio-u6-s4",
            name: "Human Impact on the Environment",
          },
        ],
      },
    ],
  },
  {
    id: "g9-eng",
    name: "English",
    icon: "Languages",
    grade: "9",
    units: [
      {
        id: "g9-eng-u1",
        name: "Unit 1: Living in Urban Areas",
        subUnits: [
          {
            id: "g9-eng-u1-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-eng-u1-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-eng-u1-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g9-eng-u1-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-eng-u2",
        name: "Unit 2: Study Skills",
        subUnits: [
          {
            id: "g9-eng-u2-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-eng-u2-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-eng-u2-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g9-eng-u2-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-eng-u3",
        name: "Unit 3: Traffic Accident",
        subUnits: [
          {
            id: "g9-eng-u3-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-eng-u3-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-eng-u3-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g9-eng-u3-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-eng-u4",
        name: "Unit 4: National Parks",
        subUnits: [
          {
            id: "g9-eng-u4-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-eng-u4-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-eng-u4-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g9-eng-u4-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-eng-u5",
        name: "Unit 5: Horticulture",
        subUnits: [
          {
            id: "g9-eng-u5-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-eng-u5-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-eng-u5-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g9-eng-u5-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-eng-u6",
        name: "Unit 6: Poverty in Ethiopia",
        subUnits: [
          {
            id: "g9-eng-u6-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-eng-u6-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-eng-u6-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g9-eng-u6-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-eng-u7",
        name: "Unit 7: Community Services",
        subUnits: [
          {
            id: "g9-eng-u7-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-eng-u7-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-eng-u7-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g9-eng-u7-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-eng-u8",
        name: "Unit 8: Communicable Diseases",
        subUnits: [
          {
            id: "g9-eng-u8-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-eng-u8-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-eng-u8-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g9-eng-u8-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-eng-u9",
        name: "Unit 9: Fairness and Equity",
        subUnits: [
          {
            id: "g9-eng-u9-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-eng-u9-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-eng-u9-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g9-eng-u9-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-eng-u10",
        name: "Unit 10: The Internet",
        subUnits: [
          {
            id: "g9-eng-u10-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-eng-u10-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-eng-u10-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g9-eng-u10-s4",
            name: "Writing",
          },
        ],
      },
    ],
  },
  {
    id: "g9-his",
    name: "History",
    icon: "Landmark",
    grade: "9",
    units: [
      {
        id: "g9-his-u1",
        name: "Unit 1: History, Historiography and Human Evolution",
        subUnits: [
          {
            id: "g9-his-u1-s1",
            name: "Meaning and Importance of History",
          },
          {
            id: "g9-his-u1-s2",
            name: "Sources and Methods of History",
          },
          {
            id: "g9-his-u1-s3",
            name: "Origins and Evolution of Humankind",
          },
        ],
      },
      {
        id: "g9-his-u2",
        name: "Unit 2: Ancient Civilizations of the World",
        subUnits: [
          {
            id: "g9-his-u2-s1",
            name: "Civilizations of the Near East",
          },
          {
            id: "g9-his-u2-s2",
            name: "Civilizations of Asia",
          },
          {
            id: "g9-his-u2-s3",
            name: "Civilizations of the Mediterranean",
          },
        ],
      },
      {
        id: "g9-his-u3",
        name: "Unit 3: Peoples and States of Ancient Ethiopia and the Horn",
        subUnits: [
          {
            id: "g9-his-u3-s1",
            name: "Early Peoples and Settlements",
          },
          {
            id: "g9-his-u3-s2",
            name: "Ancient States of the Region",
          },
          {
            id: "g9-his-u3-s3",
            name: "Cultural and Economic Foundations",
          },
        ],
      },
      {
        id: "g9-his-u4",
        name: "Unit 4: Peoples and States of Africa",
        subUnits: [
          {
            id: "g9-his-u4-s1",
            name: "Early African Societies",
          },
          {
            id: "g9-his-u4-s2",
            name: "Ancient and Medieval African States",
          },
          {
            id: "g9-his-u4-s3",
            name: "Trade and Exchange in Africa",
          },
        ],
      },
      {
        id: "g9-his-u5",
        name: "Unit 5: Africa and the Outside World",
        subUnits: [
          {
            id: "g9-his-u5-s1",
            name: "Early Contacts with the Outside World",
          },
          {
            id: "g9-his-u5-s2",
            name: "Trade Relations",
          },
          {
            id: "g9-his-u5-s3",
            name: "Cultural Exchanges",
          },
        ],
      },
      {
        id: "g9-his-u6",
        name: "Unit 6: The Middle Ages",
        subUnits: [
          {
            id: "g9-his-u6-s1",
            name: "Political Developments in the Middle Ages",
          },
          {
            id: "g9-his-u6-s2",
            name: "Society and Economy",
          },
          {
            id: "g9-his-u6-s3",
            name: "Religion and Culture",
          },
        ],
      },
      {
        id: "g9-his-u7",
        name: "Unit 7: States, Principalities and Population Movements in Ethiopia",
        subUnits: [
          {
            id: "g9-his-u7-s1",
            name: "Political Fragmentation",
          },
          {
            id: "g9-his-u7-s2",
            name: "Population Movements",
          },
          {
            id: "g9-his-u7-s3",
            name: "Regional States and Principalities",
          },
        ],
      },
      {
        id: "g9-his-u8",
        name: "Unit 8: The Early Modern World",
        subUnits: [
          {
            id: "g9-his-u8-s1",
            name: "Exploration and Globalization",
          },
          {
            id: "g9-his-u8-s2",
            name: "Renaissance and Reformation",
          },
          {
            id: "g9-his-u8-s3",
            name: "Rise of Early Modern States",
          },
        ],
      },
      {
        id: "g9-his-u9",
        name: "Unit 9: The Age of Revolutions",
        subUnits: [
          {
            id: "g9-his-u9-s1",
            name: "The Industrial Revolution",
          },
          {
            id: "g9-his-u9-s2",
            name: "Political Revolutions",
          },
          {
            id: "g9-his-u9-s3",
            name: "Impacts of the Age of Revolutions",
          },
        ],
      },
    ],
  },
  {
    id: "g9-geo",
    name: "Geography",
    icon: "Globe",
    grade: "9",
    units: [
      {
        id: "g9-geo-u1",
        name: "Unit 1: Introduction to Geography and Location of Ethiopia",
        subUnits: [
          {
            id: "g9-geo-u1-s1",
            name: "Meaning, Scope and Branches of Geography",
          },
          {
            id: "g9-geo-u1-s2",
            name: "Location, Size and Shape of Ethiopia",
          },
          {
            id: "g9-geo-u1-s3",
            name: "Effects of Location and Size on Ethiopia",
          },
        ],
      },
      {
        id: "g9-geo-u2",
        name: "Unit 2: Geological History and Landforms of Ethiopia",
        subUnits: [
          {
            id: "g9-geo-u2-s1",
            name: "Geological History of Ethiopia",
          },
          {
            id: "g9-geo-u2-s2",
            name: "Major Landform Regions",
          },
          {
            id: "g9-geo-u2-s3",
            name: "Factors Shaping Ethiopian Landforms",
          },
        ],
      },
      {
        id: "g9-geo-u3",
        name: "Unit 3: Drainage Systems of Ethiopia",
        subUnits: [
          {
            id: "g9-geo-u3-s1",
            name: "Major River Basins of Ethiopia",
          },
          {
            id: "g9-geo-u3-s2",
            name: "Lakes of Ethiopia",
          },
          {
            id: "g9-geo-u3-s3",
            name: "Importance of Drainage Systems",
          },
        ],
      },
      {
        id: "g9-geo-u4",
        name: "Unit 4: Climate of Ethiopia",
        subUnits: [
          {
            id: "g9-geo-u4-s1",
            name: "Factors Affecting Ethiopian Climate",
          },
          {
            id: "g9-geo-u4-s2",
            name: "Climate Classification of Ethiopia",
          },
          {
            id: "g9-geo-u4-s3",
            name: "Seasons and Rainfall Patterns",
          },
        ],
      },
      {
        id: "g9-geo-u5",
        name: "Unit 5: Natural Vegetation and Wildlife of Ethiopia",
        subUnits: [
          {
            id: "g9-geo-u5-s1",
            name: "Vegetation Zones of Ethiopia",
          },
          {
            id: "g9-geo-u5-s2",
            name: "Wildlife and Biodiversity",
          },
          {
            id: "g9-geo-u5-s3",
            name: "Conservation of Natural Resources",
          },
        ],
      },
      {
        id: "g9-geo-u6",
        name: "Unit 6: Soil and Mineral Resources of Ethiopia",
        subUnits: [
          {
            id: "g9-geo-u6-s1",
            name: "Major Soil Types of Ethiopia",
          },
          {
            id: "g9-geo-u6-s2",
            name: "Mineral Resources and Their Distribution",
          },
          {
            id: "g9-geo-u6-s3",
            name: "Resource Management Challenges",
          },
        ],
      },
      {
        id: "g9-geo-u7",
        name: "Unit 7: Population of Ethiopia",
        subUnits: [
          {
            id: "g9-geo-u7-s1",
            name: "Population Size, Growth and Distribution",
          },
          {
            id: "g9-geo-u7-s2",
            name: "Population Composition",
          },
          {
            id: "g9-geo-u7-s3",
            name: "Population Policy in Ethiopia",
          },
        ],
      },
      {
        id: "g9-geo-u8",
        name: "Unit 8: Economic Activities of Ethiopia",
        subUnits: [
          {
            id: "g9-geo-u8-s1",
            name: "Agriculture in Ethiopia",
          },
          {
            id: "g9-geo-u8-s2",
            name: "Industry and Manufacturing",
          },
          {
            id: "g9-geo-u8-s3",
            name: "Trade, Tourism and Services",
          },
        ],
      },
    ],
  },
  {
    id: "g9-cve",
    name: "Citizenship Education",
    icon: "Scale",
    grade: "9",
    units: [
      {
        id: "g9-cve-u1",
        name: "Unit 1: Ethical Values",
        subUnits: [
          {
            id: "g9-cve-u1-s1",
            name: "Meaning and Importance of Ethics",
          },
          {
            id: "g9-cve-u1-s2",
            name: "Major Ethical Values",
          },
          {
            id: "g9-cve-u1-s3",
            name: "Ethical Values in the Ethiopian Context",
          },
        ],
      },
      {
        id: "g9-cve-u2",
        name: "Unit 2: Culture of Using Digital Technology",
        subUnits: [
          {
            id: "g9-cve-u2-s1",
            name: "Digital Citizenship",
          },
          {
            id: "g9-cve-u2-s2",
            name: "Benefits and Risks of Technology",
          },
          {
            id: "g9-cve-u2-s3",
            name: "Responsible Online Behavior",
          },
        ],
      },
      {
        id: "g9-cve-u3",
        name: "Unit 3: Constitution and Constitutionalism",
        subUnits: [
          {
            id: "g9-cve-u3-s1",
            name: "Meaning of Constitution",
          },
          {
            id: "g9-cve-u3-s2",
            name: "Principles of Constitutionalism",
          },
          {
            id: "g9-cve-u3-s3",
            name: "The Ethiopian Constitution",
          },
        ],
      },
      {
        id: "g9-cve-u4",
        name: "Unit 4: Indigenous Knowledge",
        subUnits: [
          {
            id: "g9-cve-u4-s1",
            name: "Meaning and Sources of Indigenous Knowledge",
          },
          {
            id: "g9-cve-u4-s2",
            name: "Indigenous Knowledge Systems in Ethiopia",
          },
          {
            id: "g9-cve-u4-s3",
            name: "Preserving Indigenous Knowledge",
          },
        ],
      },
      {
        id: "g9-cve-u5",
        name: "Unit 5: Multiculturalism",
        subUnits: [
          {
            id: "g9-cve-u5-s1",
            name: "Meaning of Multiculturalism",
          },
          {
            id: "g9-cve-u5-s2",
            name: "Benefits of Cultural Diversity",
          },
          {
            id: "g9-cve-u5-s3",
            name: "Challenges of Multiculturalism",
          },
        ],
      },
      {
        id: "g9-cve-u6",
        name: "Unit 6: National Unity through Diversity",
        subUnits: [
          {
            id: "g9-cve-u6-s1",
            name: "Unity in Diversity",
          },
          {
            id: "g9-cve-u6-s2",
            name: "Factors that Promote National Unity",
          },
          {
            id: "g9-cve-u6-s3",
            name: "Threats to National Unity",
          },
        ],
      },
      {
        id: "g9-cve-u7",
        name: "Unit 7: Problem Solving Skills",
        subUnits: [
          {
            id: "g9-cve-u7-s1",
            name: "Steps in Problem Solving",
          },
          {
            id: "g9-cve-u7-s2",
            name: "Critical and Creative Thinking",
          },
          {
            id: "g9-cve-u7-s3",
            name: "Decision-Making Skills",
          },
        ],
      },
      {
        id: "g9-cve-u8",
        name: "Unit 8: Ethiopia's Foreign Relations in East Africa",
        subUnits: [
          {
            id: "g9-cve-u8-s1",
            name: "Ethiopia's Foreign Policy",
          },
          {
            id: "g9-cve-u8-s2",
            name: "Regional Cooperation in East Africa",
          },
          {
            id: "g9-cve-u8-s3",
            name: "Ethiopia's Role in Regional Organizations",
          },
        ],
      },
    ],
  },
  {
    id: "g9-eco",
    name: "Economics",
    icon: "LineChart",
    grade: "9",
    units: [
      {
        id: "g9-eco-u1",
        name: "Unit 1: Introduction to Economics",
        subUnits: [
          {
            id: "g9-eco-u1-s1",
            name: "Definition and Branches of Economics",
          },
          {
            id: "g9-eco-u1-s2",
            name: "Methods of Economic Analysis",
          },
          {
            id: "g9-eco-u1-s3",
            name: "Basic Economic Concepts",
          },
        ],
      },
      {
        id: "g9-eco-u2",
        name: "Unit 2: Basic Economic Problems and Systems",
        subUnits: [
          {
            id: "g9-eco-u2-s1",
            name: "Scarcity, Choice and Opportunity Cost",
          },
          {
            id: "g9-eco-u2-s2",
            name: "Central Economic Problems",
          },
          {
            id: "g9-eco-u2-s3",
            name: "Types of Economic Systems",
          },
        ],
      },
      {
        id: "g9-eco-u3",
        name: "Unit 3: Economic Resources and Markets",
        subUnits: [
          {
            id: "g9-eco-u3-s1",
            name: "Classification of Economic Resources",
          },
          {
            id: "g9-eco-u3-s2",
            name: "Factor Payments",
          },
          {
            id: "g9-eco-u3-s3",
            name: "Circular Flow of Economic Activity",
          },
        ],
      },
      {
        id: "g9-eco-u4",
        name: "Unit 4: Demand, Supply and Market Equilibrium",
        subUnits: [
          {
            id: "g9-eco-u4-s1",
            name: "The Law of Demand and Supply",
          },
          {
            id: "g9-eco-u4-s2",
            name: "Factors Affecting Demand and Supply",
          },
          {
            id: "g9-eco-u4-s3",
            name: "Market Equilibrium",
          },
        ],
      },
      {
        id: "g9-eco-u5",
        name: "Unit 5: Theory of Production and Cost",
        subUnits: [
          {
            id: "g9-eco-u5-s1",
            name: "Production, Inputs and Outputs",
          },
          {
            id: "g9-eco-u5-s2",
            name: "Short-Run and Long-Run Production",
          },
          {
            id: "g9-eco-u5-s3",
            name: "Types of Production Costs",
          },
        ],
      },
      {
        id: "g9-eco-u6",
        name: "Unit 6: Money and Banking",
        subUnits: [
          {
            id: "g9-eco-u6-s1",
            name: "Evolution and Functions of Money",
          },
          {
            id: "g9-eco-u6-s2",
            name: "Banking System in Ethiopia",
          },
          {
            id: "g9-eco-u6-s3",
            name: "Role of the Central Bank",
          },
        ],
      },
      {
        id: "g9-eco-u7",
        name: "Unit 7: Macroeconomic Concepts and National Income",
        subUnits: [
          {
            id: "g9-eco-u7-s1",
            name: "National Economic Goals",
          },
          {
            id: "g9-eco-u7-s2",
            name: "Measuring GDP and National Income",
          },
          {
            id: "g9-eco-u7-s3",
            name: "Inflation and Unemployment",
          },
        ],
      },
      {
        id: "g9-eco-u8",
        name: "Unit 8: Entrepreneurship and Business Opportunities",
        subUnits: [
          {
            id: "g9-eco-u8-s1",
            name: "Meaning of Entrepreneurship",
          },
          {
            id: "g9-eco-u8-s2",
            name: "Identifying Business Opportunities",
          },
          {
            id: "g9-eco-u8-s3",
            name: "Business Planning Basics",
          },
        ],
      },
    ],
  },
  {
    id: "g9-amh",
    name: "Amharic",
    icon: "MessageSquare",
    grade: "9",
    units: [
      {
        id: "g9-amh-u1",
        name: "Unit 1 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g9-amh-u1-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-amh-u1-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-amh-u1-s3",
            name: "Grammar and Vocabulary",
          },
          {
            id: "g9-amh-u1-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-amh-u2",
        name: "Unit 2 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g9-amh-u2-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-amh-u2-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-amh-u2-s3",
            name: "Grammar and Vocabulary",
          },
          {
            id: "g9-amh-u2-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-amh-u3",
        name: "Unit 3 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g9-amh-u3-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-amh-u3-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-amh-u3-s3",
            name: "Grammar and Vocabulary",
          },
          {
            id: "g9-amh-u3-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-amh-u4",
        name: "Unit 4 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g9-amh-u4-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-amh-u4-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-amh-u4-s3",
            name: "Grammar and Vocabulary",
          },
          {
            id: "g9-amh-u4-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-amh-u5",
        name: "Unit 5 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g9-amh-u5-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-amh-u5-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-amh-u5-s3",
            name: "Grammar and Vocabulary",
          },
          {
            id: "g9-amh-u5-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-amh-u6",
        name: "Unit 6 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g9-amh-u6-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-amh-u6-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-amh-u6-s3",
            name: "Grammar and Vocabulary",
          },
          {
            id: "g9-amh-u6-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-amh-u7",
        name: "Unit 7 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g9-amh-u7-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-amh-u7-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-amh-u7-s3",
            name: "Grammar and Vocabulary",
          },
          {
            id: "g9-amh-u7-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-amh-u8",
        name: "Unit 8 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g9-amh-u8-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-amh-u8-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-amh-u8-s3",
            name: "Grammar and Vocabulary",
          },
          {
            id: "g9-amh-u8-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g9-amh-u9",
        name: "Unit 9 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g9-amh-u9-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g9-amh-u9-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g9-amh-u9-s3",
            name: "Grammar and Vocabulary",
          },
          {
            id: "g9-amh-u9-s4",
            name: "Writing",
          },
        ],
      },
    ],
  },
  {
    id: "g9-ict",
    name: "Information Technology",
    icon: "MonitorSmartphone",
    grade: "9",
    units: [
      {
        id: "g9-ict-u1",
        name: "Unit 1: Organization of Files",
        subUnits: [
          {
            id: "g9-ict-u1-s1",
            name: "File and Folder Management",
          },
          {
            id: "g9-ict-u1-s2",
            name: "File Naming Conventions",
          },
          {
            id: "g9-ict-u1-s3",
            name: "Backup and Storage",
          },
          {
            id: "g9-ict-u1-s4",
            name: "File Compression",
          },
        ],
      },
      {
        id: "g9-ict-u2",
        name: "Unit 2: Computer Network",
        subUnits: [
          {
            id: "g9-ict-u2-s1",
            name: "Network Basics and Types",
          },
          {
            id: "g9-ict-u2-s2",
            name: "Network Devices and Topologies",
          },
          {
            id: "g9-ict-u2-s3",
            name: "Internet and Connectivity",
          },
          {
            id: "g9-ict-u2-s4",
            name: "Network Security Basics",
          },
        ],
      },
      {
        id: "g9-ict-u3",
        name: "Unit 3: Application Software",
        subUnits: [
          {
            id: "g9-ict-u3-s1",
            name: "Word Processing",
          },
          {
            id: "g9-ict-u3-s2",
            name: "Spreadsheet Applications",
          },
          {
            id: "g9-ict-u3-s3",
            name: "Presentation Software",
          },
          {
            id: "g9-ict-u3-s4",
            name: "Database Basics",
          },
        ],
      },
      {
        id: "g9-ict-u4",
        name: "Unit 4: Image Processing and Multimedia",
        subUnits: [
          {
            id: "g9-ict-u4-s1",
            name: "Digital Image Basics",
          },
          {
            id: "g9-ict-u4-s2",
            name: "Image Editing Tools",
          },
          {
            id: "g9-ict-u4-s3",
            name: "Multimedia Components",
          },
          {
            id: "g9-ict-u4-s4",
            name: "Multimedia Applications",
          },
        ],
      },
      {
        id: "g9-ict-u5",
        name: "Unit 5: Information and Computer Security",
        subUnits: [
          {
            id: "g9-ict-u5-s1",
            name: "Computer Threats and Viruses",
          },
          {
            id: "g9-ict-u5-s2",
            name: "Data Protection Methods",
          },
          {
            id: "g9-ict-u5-s3",
            name: "Ethical Use of ICT",
          },
          {
            id: "g9-ict-u5-s4",
            name: "Cyber Safety Practices",
          },
        ],
      },
      {
        id: "g9-ict-u6",
        name: "Unit 6: Fundamentals of Programming",
        subUnits: [
          {
            id: "g9-ict-u6-s1",
            name: "Introduction to Programming Concepts",
          },
          {
            id: "g9-ict-u6-s2",
            name: "Algorithms and Flowcharts",
          },
          {
            id: "g9-ict-u6-s3",
            name: "Basic Programming Constructs",
          },
          {
            id: "g9-ict-u6-s4",
            name: "Simple Program Writing",
          },
        ],
      },
    ],
  },
  {
    id: "g9-hpe",
    name: "Health and Physical Education",
    icon: "Activity",
    grade: "9",
    units: [
      {
        id: "g9-hpe-u1",
        name: "Unit 1: Sport and Society",
        subUnits: [
          {
            id: "g9-hpe-u1-s1",
            name: "Definition and Importance of Sport",
          },
          {
            id: "g9-hpe-u1-s2",
            name: "Sport and National Development",
          },
          {
            id: "g9-hpe-u1-s3",
            name: "Ethics in Sport",
          },
        ],
      },
      {
        id: "g9-hpe-u2",
        name: "Unit 2: Health and Physical Fitness",
        subUnits: [
          {
            id: "g9-hpe-u2-s1",
            name: "Components of Fitness",
          },
          {
            id: "g9-hpe-u2-s2",
            name: "Health-Related Fitness Activities",
          },
          {
            id: "g9-hpe-u2-s3",
            name: "Principles of Training",
          },
        ],
      },
      {
        id: "g9-hpe-u3",
        name: "Unit 3: Athletics",
        subUnits: [
          {
            id: "g9-hpe-u3-s1",
            name: "Track Events",
          },
          {
            id: "g9-hpe-u3-s2",
            name: "Field Events",
          },
          {
            id: "g9-hpe-u3-s3",
            name: "Athletics Training Principles",
          },
        ],
      },
      {
        id: "g9-hpe-u4",
        name: "Unit 4: Football",
        subUnits: [
          {
            id: "g9-hpe-u4-s1",
            name: "History and Rules",
          },
          {
            id: "g9-hpe-u4-s2",
            name: "Basic Skills and Techniques",
          },
          {
            id: "g9-hpe-u4-s3",
            name: "Tactics and Safety",
          },
        ],
      },
      {
        id: "g9-hpe-u5",
        name: "Unit 5: Volleyball",
        subUnits: [
          {
            id: "g9-hpe-u5-s1",
            name: "History and Rules",
          },
          {
            id: "g9-hpe-u5-s2",
            name: "Basic Skills and Techniques",
          },
          {
            id: "g9-hpe-u5-s3",
            name: "Tactics and Safety",
          },
        ],
      },
      {
        id: "g9-hpe-u6",
        name: "Unit 6: Basketball",
        subUnits: [
          {
            id: "g9-hpe-u6-s1",
            name: "History and Rules",
          },
          {
            id: "g9-hpe-u6-s2",
            name: "Basic Skills and Techniques",
          },
          {
            id: "g9-hpe-u6-s3",
            name: "Tactics and Safety",
          },
        ],
      },
      {
        id: "g9-hpe-u7",
        name: "Unit 7: Handball",
        subUnits: [
          {
            id: "g9-hpe-u7-s1",
            name: "History and Rules",
          },
          {
            id: "g9-hpe-u7-s2",
            name: "Basic Skills and Techniques",
          },
          {
            id: "g9-hpe-u7-s3",
            name: "Tactics and Safety",
          },
        ],
      },
      {
        id: "g9-hpe-u8",
        name: "Unit 8: Self-Defense and Sport Ethics",
        subUnits: [
          {
            id: "g9-hpe-u8-s1",
            name: "Basic Self-Defense Techniques",
          },
          {
            id: "g9-hpe-u8-s2",
            name: "Sportsmanship and Fair Play",
          },
          {
            id: "g9-hpe-u8-s3",
            name: "Sport-Related Injuries and Safety",
          },
        ],
      },
    ],
  },
  {
    id: "g10-math",
    name: "Mathematics",
    icon: "Calculator",
    grade: "10",
    units: [
      {
        id: "g10-math-u1",
        name: "Unit 1: Relations and Functions",
        subUnits: [
          {
            id: "g10-math-u1-s1",
            name: "Ordered Pairs and Mappings",
          },
          {
            id: "g10-math-u1-s2",
            name: "Domain and Range",
          },
          {
            id: "g10-math-u1-s3",
            name: "Graphing Relations and Functions",
          },
        ],
      },
      {
        id: "g10-math-u2",
        name: "Unit 2: Polynomial Functions",
        subUnits: [
          {
            id: "g10-math-u2-s1",
            name: "Introduction to Polynomial Functions",
          },
          {
            id: "g10-math-u2-s2",
            name: "Operations on Polynomials",
          },
          {
            id: "g10-math-u2-s3",
            name: "Zeros of Polynomials and Theorems",
          },
          {
            id: "g10-math-u2-s4",
            name: "Graphing Polynomial Functions",
          },
        ],
      },
      {
        id: "g10-math-u3",
        name: "Unit 3: Exponential and Logarithmic Functions",
        subUnits: [
          {
            id: "g10-math-u3-s1",
            name: "Rules of Exponents",
          },
          {
            id: "g10-math-u3-s2",
            name: "Exponential Functions and Graphs",
          },
          {
            id: "g10-math-u3-s3",
            name: "Logarithms and Their Properties",
          },
          {
            id: "g10-math-u3-s4",
            name: "Logarithmic Functions and Graphs",
          },
        ],
      },
      {
        id: "g10-math-u4",
        name: "Unit 4: Trigonometric Functions",
        subUnits: [
          {
            id: "g10-math-u4-s1",
            name: "Trigonometric Functions and Identities",
          },
          {
            id: "g10-math-u4-s2",
            name: "Graphs of Trigonometric Functions",
          },
          {
            id: "g10-math-u4-s3",
            name: "Solving Trigonometric Equations",
          },
        ],
      },
      {
        id: "g10-math-u5",
        name: "Unit 5: Circles",
        subUnits: [
          {
            id: "g10-math-u5-s1",
            name: "Properties of Circles",
          },
          {
            id: "g10-math-u5-s2",
            name: "Angles and Arcs",
          },
          {
            id: "g10-math-u5-s3",
            name: "Tangents and Chords",
          },
        ],
      },
      {
        id: "g10-math-u6",
        name: "Unit 6: Solid Figures",
        subUnits: [
          {
            id: "g10-math-u6-s1",
            name: "Types of Solid Figures",
          },
          {
            id: "g10-math-u6-s2",
            name: "Surface Area of Solids",
          },
          {
            id: "g10-math-u6-s3",
            name: "Volume of Solids",
          },
        ],
      },
      {
        id: "g10-math-u7",
        name: "Unit 7: Coordinate Geometry",
        subUnits: [
          {
            id: "g10-math-u7-s1",
            name: "Distance Between Two Points",
          },
          {
            id: "g10-math-u7-s2",
            name: "Division of a Line Segment",
          },
          {
            id: "g10-math-u7-s3",
            name: "Equations of Lines and Slopes",
          },
        ],
      },
    ],
  },
  {
    id: "g10-phy",
    name: "Physics",
    icon: "Atom",
    grade: "10",
    units: [
      {
        id: "g10-phy-u1",
        name: "Unit 1: Vector Quantities",
        subUnits: [
          {
            id: "g10-phy-u1-s1",
            name: "Vector Representation and Addition",
          },
          {
            id: "g10-phy-u1-s2",
            name: "Resolution of Vectors",
          },
          {
            id: "g10-phy-u1-s3",
            name: "Applications of Vectors in Motion",
          },
        ],
      },
      {
        id: "g10-phy-u2",
        name: "Unit 2: Uniformly Accelerated Motion",
        subUnits: [
          {
            id: "g10-phy-u2-s1",
            name: "Motion in Two Dimensions",
          },
          {
            id: "g10-phy-u2-s2",
            name: "Projectile Motion",
          },
          {
            id: "g10-phy-u2-s3",
            name: "Circular Motion",
          },
        ],
      },
      {
        id: "g10-phy-u3",
        name: "Unit 3: Elasticity and Static Equilibrium of Rigid Body",
        subUnits: [
          {
            id: "g10-phy-u3-s1",
            name: "Elastic Properties of Materials",
          },
          {
            id: "g10-phy-u3-s2",
            name: "Torque and Moments",
          },
          {
            id: "g10-phy-u3-s3",
            name: "Conditions for Static Equilibrium",
          },
        ],
      },
      {
        id: "g10-phy-u4",
        name: "Unit 4: Static and Current Electricity",
        subUnits: [
          {
            id: "g10-phy-u4-s1",
            name: "Electric Charge and Coulomb's Law",
          },
          {
            id: "g10-phy-u4-s2",
            name: "Electric Fields and Potential",
          },
          {
            id: "g10-phy-u4-s3",
            name: "Electric Current, Resistance and Ohm's Law",
          },
          {
            id: "g10-phy-u4-s4",
            name: "Electric Circuits",
          },
        ],
      },
      {
        id: "g10-phy-u5",
        name: "Unit 5: Magnetism",
        subUnits: [
          {
            id: "g10-phy-u5-s1",
            name: "Magnetic Fields and Forces",
          },
          {
            id: "g10-phy-u5-s2",
            name: "Electromagnetism",
          },
          {
            id: "g10-phy-u5-s3",
            name: "Electromagnetic Induction",
          },
        ],
      },
      {
        id: "g10-phy-u6",
        name: "Unit 6: Electromagnetic Waves and Geometrical Optics",
        subUnits: [
          {
            id: "g10-phy-u6-s1",
            name: "The Electromagnetic Spectrum",
          },
          {
            id: "g10-phy-u6-s2",
            name: "Reflection of Light",
          },
          {
            id: "g10-phy-u6-s3",
            name: "Refraction and Lenses",
          },
        ],
      },
    ],
  },
  {
    id: "g10-che",
    name: "Chemistry",
    icon: "FlaskConical",
    grade: "10",
    units: [
      {
        id: "g10-che-u1",
        name: "Unit 1: Chemical Reactions and Stoichiometry",
        subUnits: [
          {
            id: "g10-che-u1-s1",
            name: "Chemical Equations and Types of Reactions",
          },
          {
            id: "g10-che-u1-s2",
            name: "Oxidation-Reduction Reactions",
          },
          {
            id: "g10-che-u1-s3",
            name: "The Mole Concept",
          },
          {
            id: "g10-che-u1-s4",
            name: "Stoichiometric Calculations",
          },
        ],
      },
      {
        id: "g10-che-u2",
        name: "Unit 2: Mixtures and Solutions",
        subUnits: [
          {
            id: "g10-che-u2-s1",
            name: "Heterogeneous and Homogeneous Mixtures",
          },
          {
            id: "g10-che-u2-s2",
            name: "Solubility",
          },
          {
            id: "g10-che-u2-s3",
            name: "Expressing Solution Concentration",
          },
        ],
      },
      {
        id: "g10-che-u3",
        name: "Unit 3: Acids, Bases and Salts",
        subUnits: [
          {
            id: "g10-che-u3-s1",
            name: "Properties of Acids and Bases",
          },
          {
            id: "g10-che-u3-s2",
            name: "pH and Indicators",
          },
          {
            id: "g10-che-u3-s3",
            name: "Formation and Uses of Salts",
          },
        ],
      },
      {
        id: "g10-che-u4",
        name: "Unit 4: Metals and Nonmetals",
        subUnits: [
          {
            id: "g10-che-u4-s1",
            name: "Classification and Properties of Metals and Nonmetals",
          },
          {
            id: "g10-che-u4-s2",
            name: "Extraction Methods",
          },
          {
            id: "g10-che-u4-s3",
            name: "Ethiopian Mineral Resources (Gold, Copper, Potash)",
          },
        ],
      },
      {
        id: "g10-che-u5",
        name: "Unit 5: Electrochemistry",
        subUnits: [
          {
            id: "g10-che-u5-s1",
            name: "Electrical Conductivity",
          },
          {
            id: "g10-che-u5-s2",
            name: "Electrolysis",
          },
          {
            id: "g10-che-u5-s3",
            name: "Galvanic (Voltaic) Cells",
          },
        ],
      },
      {
        id: "g10-che-u6",
        name: "Unit 6: Hydrocarbons and Their Sources",
        subUnits: [
          {
            id: "g10-che-u6-s1",
            name: "Alkanes",
          },
          {
            id: "g10-che-u6-s2",
            name: "Alkenes and Alkynes",
          },
          {
            id: "g10-che-u6-s3",
            name: "Aromatic Hydrocarbons",
          },
          {
            id: "g10-che-u6-s4",
            name: "Natural Sources of Hydrocarbons in Ethiopia",
          },
        ],
      },
    ],
  },
  {
    id: "g10-bio",
    name: "Biology",
    icon: "Dna",
    grade: "10",
    units: [
      {
        id: "g10-bio-u1",
        name: "Unit 1: Sub-fields of Biology",
        subUnits: [
          {
            id: "g10-bio-u1-s1",
            name: "Branches of Biology",
          },
          {
            id: "g10-bio-u1-s2",
            name: "Careers Related to Biology",
          },
          {
            id: "g10-bio-u1-s3",
            name: "Biology and Other Disciplines",
          },
        ],
      },
      {
        id: "g10-bio-u2",
        name: "Unit 2: Plants",
        subUnits: [
          {
            id: "g10-bio-u2-s1",
            name: "Plant Structure and Function",
          },
          {
            id: "g10-bio-u2-s2",
            name: "Photosynthesis and Respiration in Plants",
          },
          {
            id: "g10-bio-u2-s3",
            name: "Plant Growth and Development",
          },
          {
            id: "g10-bio-u2-s4",
            name: "Plant Classification",
          },
        ],
      },
      {
        id: "g10-bio-u3",
        name: "Unit 3: Biochemical Molecules",
        subUnits: [
          {
            id: "g10-bio-u3-s1",
            name: "Carbohydrates",
          },
          {
            id: "g10-bio-u3-s2",
            name: "Proteins",
          },
          {
            id: "g10-bio-u3-s3",
            name: "Lipids",
          },
          {
            id: "g10-bio-u3-s4",
            name: "Nucleic Acids",
          },
        ],
      },
      {
        id: "g10-bio-u4",
        name: "Unit 4: Cell Reproduction",
        subUnits: [
          {
            id: "g10-bio-u4-s1",
            name: "The Cell Cycle",
          },
          {
            id: "g10-bio-u4-s2",
            name: "Mitosis",
          },
          {
            id: "g10-bio-u4-s3",
            name: "Meiosis",
          },
        ],
      },
      {
        id: "g10-bio-u5",
        name: "Unit 5: Human Biology",
        subUnits: [
          {
            id: "g10-bio-u5-s1",
            name: "The Digestive System",
          },
          {
            id: "g10-bio-u5-s2",
            name: "The Circulatory System",
          },
          {
            id: "g10-bio-u5-s3",
            name: "The Respiratory System",
          },
          {
            id: "g10-bio-u5-s4",
            name: "The Nervous System",
          },
        ],
      },
      {
        id: "g10-bio-u6",
        name: "Unit 6: Ecological Interaction",
        subUnits: [
          {
            id: "g10-bio-u6-s1",
            name: "Interactions Within Ecosystems",
          },
          {
            id: "g10-bio-u6-s2",
            name: "Population Ecology",
          },
          {
            id: "g10-bio-u6-s3",
            name: "Human Impact on Ecological Balance",
          },
        ],
      },
    ],
  },
  {
    id: "g10-eng",
    name: "English",
    icon: "Languages",
    grade: "10",
    units: [
      {
        id: "g10-eng-u1",
        name: "Unit 1 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g10-eng-u1-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-eng-u1-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-eng-u1-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-eng-u1-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-eng-u2",
        name: "Unit 2 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g10-eng-u2-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-eng-u2-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-eng-u2-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-eng-u2-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-eng-u3",
        name: "Unit 3: Punctuality",
        subUnits: [
          {
            id: "g10-eng-u3-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-eng-u3-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-eng-u3-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-eng-u3-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-eng-u4",
        name: "Unit 4: Tourist Attractions",
        subUnits: [
          {
            id: "g10-eng-u4-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-eng-u4-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-eng-u4-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-eng-u4-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-eng-u5",
        name: "Unit 5: Honey Production and Processing",
        subUnits: [
          {
            id: "g10-eng-u5-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-eng-u5-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-eng-u5-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-eng-u5-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-eng-u6",
        name: "Unit 6: Migration",
        subUnits: [
          {
            id: "g10-eng-u6-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-eng-u6-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-eng-u6-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-eng-u6-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-eng-u7",
        name: "Unit 7: Branding Ethiopia and National Identity",
        subUnits: [
          {
            id: "g10-eng-u7-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-eng-u7-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-eng-u7-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-eng-u7-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-eng-u8",
        name: "Unit 8: Traditional Medicine and Moringa",
        subUnits: [
          {
            id: "g10-eng-u8-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-eng-u8-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-eng-u8-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-eng-u8-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-eng-u9",
        name: "Unit 9: Multilingualism in Ethiopia",
        subUnits: [
          {
            id: "g10-eng-u9-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-eng-u9-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-eng-u9-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-eng-u9-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-eng-u10",
        name: "Unit 10: Digital vs. Satellite Television",
        subUnits: [
          {
            id: "g10-eng-u10-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-eng-u10-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-eng-u10-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-eng-u10-s4",
            name: "Writing",
          },
        ],
      },
    ],
  },
  {
    id: "g10-his",
    name: "History",
    icon: "Landmark",
    grade: "10",
    units: [
      {
        id: "g10-his-u1",
        name: "Unit 1: Capitalism and Nationalism in 19th-Century Europe",
        subUnits: [
          {
            id: "g10-his-u1-s1",
            name: "Rise of Industrial Capitalism",
          },
          {
            id: "g10-his-u1-s2",
            name: "Nationalism and Unification Movements",
          },
          {
            id: "g10-his-u1-s3",
            name: "European Political Change, 1815–1870s",
          },
        ],
      },
      {
        id: "g10-his-u2",
        name: "Unit 2: Colonialism in Africa",
        subUnits: [
          {
            id: "g10-his-u2-s1",
            name: "The Scramble for Africa",
          },
          {
            id: "g10-his-u2-s2",
            name: "Colonial Administration Systems",
          },
          {
            id: "g10-his-u2-s3",
            name: "African Resistance to Colonialism",
          },
        ],
      },
      {
        id: "g10-his-u3",
        name: "Unit 3: Social, Economic and Political Developments in Ethiopia mid-19th C. to 1941",
        subUnits: [
          {
            id: "g10-his-u3-s1",
            name: "Long-Distance Trade",
          },
          {
            id: "g10-his-u3-s2",
            name: "The Making of the Modern Ethiopian State",
          },
          {
            id: "g10-his-u3-s3",
            name: "External Aggression and Patriotic Resistance",
          },
        ],
      },
      {
        id: "g10-his-u4",
        name: "Unit 4: Society and Politics in the Age of World Wars 1914-1945",
        subUnits: [
          {
            id: "g10-his-u4-s1",
            name: "Causes and Consequences of World War I",
          },
          {
            id: "g10-his-u4-s2",
            name: "The Russian Revolution and the League of Nations",
          },
          {
            id: "g10-his-u4-s3",
            name: "The Great Depression and the Rise of Fascism",
          },
        ],
      },
      {
        id: "g10-his-u5",
        name: "Unit 5: Global and Regional Developments Since 1945",
        subUnits: [
          {
            id: "g10-his-u5-s1",
            name: "Formation and Achievements of the United Nations",
          },
          {
            id: "g10-his-u5-s2",
            name: "Rise of the Superpowers and Onset of the Cold War",
          },
          {
            id: "g10-his-u5-s3",
            name: "Cold War Dynamics in Asia",
          },
        ],
      },
      {
        id: "g10-his-u6",
        name: "Unit 6: Ethiopia: Internal Developments and External Influences from 1941 to 1991",
        subUnits: [
          {
            id: "g10-his-u6-s1",
            name: "Post-1941 Political and Economic Change",
          },
          {
            id: "g10-his-u6-s2",
            name: "The 1974 Revolution and the Derg Period",
          },
          {
            id: "g10-his-u6-s3",
            name: "External Relations, 1941–1991",
          },
        ],
      },
      {
        id: "g10-his-u7",
        name: "Unit 7: Post-1991 Ethiopia",
        subUnits: [
          {
            id: "g10-his-u7-s1",
            name: "Political Transition After 1991",
          },
          {
            id: "g10-his-u7-s2",
            name: "Federal Restructuring",
          },
          {
            id: "g10-his-u7-s3",
            name: "Recent Economic and Social Developments",
          },
        ],
      },
      {
        id: "g10-his-u8",
        name: "Unit 8: Indigenous Knowledge and Heritage in Ethiopia",
        subUnits: [
          {
            id: "g10-his-u8-s1",
            name: "Indigenous Knowledge Systems",
          },
          {
            id: "g10-his-u8-s2",
            name: "Cultural and Historical Heritage Sites",
          },
          {
            id: "g10-his-u8-s3",
            name: "Preservation and Value of Heritage",
          },
        ],
      },
      {
        id: "g10-his-u9",
        name: "Unit 9: Ethiopia and the Horn in Contemporary Times",
        subUnits: [
          {
            id: "g10-his-u9-s1",
            name: "Regional Relations in the Horn of Africa",
          },
          {
            id: "g10-his-u9-s2",
            name: "Contemporary Challenges and Cooperation",
          },
          {
            id: "g10-his-u9-s3",
            name: "Ethiopia's Role in Regional Affairs",
          },
        ],
      },
    ],
  },
  {
    id: "g10-geo",
    name: "Geography",
    icon: "Globe",
    grade: "10",
    units: [
      {
        id: "g10-geo-u1",
        name: "Unit 1: Landforms of Africa",
        subUnits: [
          {
            id: "g10-geo-u1-s1",
            name: "Major Landform Regions of Africa",
          },
          {
            id: "g10-geo-u1-s2",
            name: "The Atlas Mountains, Sahara and Sahel",
          },
          {
            id: "g10-geo-u1-s3",
            name: "The Rift Valley and Southern African Highlands",
          },
        ],
      },
      {
        id: "g10-geo-u2",
        name: "Unit 2: Climate of Africa",
        subUnits: [
          {
            id: "g10-geo-u2-s1",
            name: "Factors Affecting African Climate",
          },
          {
            id: "g10-geo-u2-s2",
            name: "Climate Zones of Africa",
          },
          {
            id: "g10-geo-u2-s3",
            name: "Climate Change Impacts on Africa",
          },
        ],
      },
      {
        id: "g10-geo-u3",
        name: "Unit 3: Drainage Systems and Natural Resources of Africa",
        subUnits: [
          {
            id: "g10-geo-u3-s1",
            name: "Major River Basins and Lakes of Africa",
          },
          {
            id: "g10-geo-u3-s2",
            name: "Mineral Resources of Africa",
          },
          {
            id: "g10-geo-u3-s3",
            name: "Ecosystems and Resource Conservation",
          },
        ],
      },
      {
        id: "g10-geo-u4",
        name: "Unit 4: Population of Africa",
        subUnits: [
          {
            id: "g10-geo-u4-s1",
            name: "Demographic Trends and Age Structure",
          },
          {
            id: "g10-geo-u4-s2",
            name: "Urbanization in Africa",
          },
          {
            id: "g10-geo-u4-s3",
            name: "Rural Life and Settlement Patterns",
          },
        ],
      },
      {
        id: "g10-geo-u5",
        name: "Unit 5: Major Economic and Cultural Activities of Africa",
        subUnits: [
          {
            id: "g10-geo-u5-s1",
            name: "Employment Structure and Unemployment",
          },
          {
            id: "g10-geo-u5-s2",
            name: "Agenda 2063 and the Sustainable Development Goals",
          },
          {
            id: "g10-geo-u5-s3",
            name: "Linguistic and Religious Diversity in Africa",
          },
        ],
      },
      {
        id: "g10-geo-u6",
        name: "Unit 6: Population Change and Human-Environment Relationships in Africa",
        subUnits: [
          {
            id: "g10-geo-u6-s1",
            name: "Global Population Change",
          },
          {
            id: "g10-geo-u6-s2",
            name: "Human-Environment Interaction",
          },
          {
            id: "g10-geo-u6-s3",
            name: "Indigenous Knowledge in Resource Conservation",
          },
        ],
      },
      {
        id: "g10-geo-u7",
        name: "Unit 7: Geographic Issues and Public Concerns in Africa",
        subUnits: [
          {
            id: "g10-geo-u7-s1",
            name: "Unplanned Urbanization",
          },
          {
            id: "g10-geo-u7-s2",
            name: "Migration Issues",
          },
          {
            id: "g10-geo-u7-s3",
            name: "Coastal Pollution",
          },
        ],
      },
      {
        id: "g10-geo-u8",
        name: "Unit 8: Geospatial Information and Data Processing",
        subUnits: [
          {
            id: "g10-geo-u8-s1",
            name: "Basic Concepts of Geospatial Information",
          },
          {
            id: "g10-geo-u8-s2",
            name: "Sources and Tools of Geographic Data",
          },
          {
            id: "g10-geo-u8-s3",
            name: "Interpreting Graphs, Charts and Maps",
          },
        ],
      },
    ],
  },
  {
    id: "g10-cve",
    name: "Citizenship Education",
    icon: "Scale",
    grade: "10",
    units: [
      {
        id: "g10-cve-u1",
        name: "Unit 1: Democracy and Democratic Systems",
        subUnits: [
          {
            id: "g10-cve-u1-s1",
            name: "Principles of Democracy",
          },
          {
            id: "g10-cve-u1-s2",
            name: "Representative Democracy in Ethiopia",
          },
          {
            id: "g10-cve-u1-s3",
            name: "Challenges to Democracy",
          },
        ],
      },
      {
        id: "g10-cve-u2",
        name: "Unit 2: Digital Ethics and Citizenship",
        subUnits: [
          {
            id: "g10-cve-u2-s1",
            name: "Ethics in the Digital Age",
          },
          {
            id: "g10-cve-u2-s2",
            name: "Digital Rights and Responsibilities",
          },
          {
            id: "g10-cve-u2-s3",
            name: "Combating Misinformation",
          },
        ],
      },
      {
        id: "g10-cve-u3",
        name: "Unit 3: Governance and Public Institutions",
        subUnits: [
          {
            id: "g10-cve-u3-s1",
            name: "Structure of Government in Ethiopia",
          },
          {
            id: "g10-cve-u3-s2",
            name: "Transparency and Accountability",
          },
          {
            id: "g10-cve-u3-s3",
            name: "Federalism in Ethiopia",
          },
        ],
      },
      {
        id: "g10-cve-u4",
        name: "Unit 4: Patriotism and National Service",
        subUnits: [
          {
            id: "g10-cve-u4-s1",
            name: "Meaning of Patriotism",
          },
          {
            id: "g10-cve-u4-s2",
            name: "National Service and Civic Duty",
          },
          {
            id: "g10-cve-u4-s3",
            name: "Patriotism in Ethiopian History",
          },
        ],
      },
      {
        id: "g10-cve-u5",
        name: "Unit 5: Human Rights and Responsibilities",
        subUnits: [
          {
            id: "g10-cve-u5-s1",
            name: "Fundamental Human Rights",
          },
          {
            id: "g10-cve-u5-s2",
            name: "Rights and Corresponding Responsibilities",
          },
          {
            id: "g10-cve-u5-s3",
            name: "Protecting Vulnerable Groups",
          },
        ],
      },
      {
        id: "g10-cve-u6",
        name: "Unit 6: Rule of Law and Justice",
        subUnits: [
          {
            id: "g10-cve-u6-s1",
            name: "The Constitution and Rule of Law",
          },
          {
            id: "g10-cve-u6-s2",
            name: "The Justice System in Ethiopia",
          },
          {
            id: "g10-cve-u6-s3",
            name: "Anti-Corruption Measures",
          },
        ],
      },
      {
        id: "g10-cve-u7",
        name: "Unit 7: Civic Participation",
        subUnits: [
          {
            id: "g10-cve-u7-s1",
            name: "Forms of Civic Participation",
          },
          {
            id: "g10-cve-u7-s2",
            name: "Community Organizations",
          },
          {
            id: "g10-cve-u7-s3",
            name: "Youth Participation in Civic Life",
          },
        ],
      },
      {
        id: "g10-cve-u8",
        name: "Unit 8: Ethiopia's Role in Regional and Global Affairs",
        subUnits: [
          {
            id: "g10-cve-u8-s1",
            name: "Ethiopia's Foreign Policy Priorities",
          },
          {
            id: "g10-cve-u8-s2",
            name: "Regional Organizations and Cooperation",
          },
          {
            id: "g10-cve-u8-s3",
            name: "Ethiopia in International Institutions",
          },
        ],
      },
    ],
  },
  {
    id: "g10-eco",
    name: "Economics",
    icon: "LineChart",
    grade: "10",
    units: [
      {
        id: "g10-eco-u1",
        name: "Unit 1: Theory of Consumer Behaviour",
        subUnits: [
          {
            id: "g10-eco-u1-s1",
            name: "The Concept of Utility",
          },
          {
            id: "g10-eco-u1-s2",
            name: "The Cardinal Utility Theory",
          },
          {
            id: "g10-eco-u1-s3",
            name: "The Consumer Maximization Problem",
          },
          {
            id: "g10-eco-u1-s4",
            name: "Introduction to the Ordinal Utility Theory",
          },
        ],
      },
      {
        id: "g10-eco-u2",
        name: "Unit 2: Theories of Demand and Supply",
        subUnits: [
          {
            id: "g10-eco-u2-s1",
            name: "Theory of Demand",
          },
          {
            id: "g10-eco-u2-s2",
            name: "Theory of Supply",
          },
          {
            id: "g10-eco-u2-s3",
            name: "Market Equilibrium",
          },
          {
            id: "g10-eco-u2-s4",
            name: "Elasticities of Demand and Supply",
          },
        ],
      },
      {
        id: "g10-eco-u3",
        name: "Unit 3: Theories of Production and Cost",
        subUnits: [
          {
            id: "g10-eco-u3-s1",
            name: "Theory of Production",
          },
          {
            id: "g10-eco-u3-s2",
            name: "Short-Run and Long-Run Costs",
          },
          {
            id: "g10-eco-u3-s3",
            name: "Cost Minimization",
          },
        ],
      },
      {
        id: "g10-eco-u4",
        name: "Unit 4: Market Structure",
        subUnits: [
          {
            id: "g10-eco-u4-s1",
            name: "Perfectly Competitive Markets",
          },
          {
            id: "g10-eco-u4-s2",
            name: "Pure Monopoly Market",
          },
          {
            id: "g10-eco-u4-s3",
            name: "Monopolistically Competitive Market",
          },
          {
            id: "g10-eco-u4-s4",
            name: "Oligopoly Market",
          },
        ],
      },
      {
        id: "g10-eco-u5",
        name: "Unit 5: National Income Accounting",
        subUnits: [
          {
            id: "g10-eco-u5-s1",
            name: "Measuring GDP and GNP",
          },
          {
            id: "g10-eco-u5-s2",
            name: "Approaches to National Income Measurement",
          },
          {
            id: "g10-eco-u5-s3",
            name: "Limitations of National Income Statistics",
          },
        ],
      },
      {
        id: "g10-eco-u6",
        name: "Unit 6: Money, Banking and Public Finance",
        subUnits: [
          {
            id: "g10-eco-u6-s1",
            name: "Functions and Types of Money",
          },
          {
            id: "g10-eco-u6-s2",
            name: "The Banking System",
          },
          {
            id: "g10-eco-u6-s3",
            name: "Government Revenue and Expenditure",
          },
        ],
      },
      {
        id: "g10-eco-u7",
        name: "Unit 7: The Ethiopian Economy: Sectors and Development",
        subUnits: [
          {
            id: "g10-eco-u7-s1",
            name: "Agricultural Sector",
          },
          {
            id: "g10-eco-u7-s2",
            name: "Industrial Sector",
          },
          {
            id: "g10-eco-u7-s3",
            name: "Service Sector and Development Strategy",
          },
        ],
      },
      {
        id: "g10-eco-u8",
        name: "Unit 8: Business Startups and Innovation",
        subUnits: [
          {
            id: "g10-eco-u8-s1",
            name: "Innovation and Entrepreneurship",
          },
          {
            id: "g10-eco-u8-s2",
            name: "Types of Business Organizations",
          },
          {
            id: "g10-eco-u8-s3",
            name: "Feasibility Analysis for Startups",
          },
        ],
      },
    ],
  },
  {
    id: "g10-amh",
    name: "Amharic",
    icon: "MessageSquare",
    grade: "10",
    units: [
      {
        id: "g10-amh-u1",
        name: "Unit 1: Language and Society",
        subUnits: [
          {
            id: "g10-amh-u1-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-amh-u1-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-amh-u1-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-amh-u1-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-amh-u2",
        name: "Unit 2 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g10-amh-u2-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-amh-u2-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-amh-u2-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-amh-u2-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-amh-u3",
        name: "Unit 3 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g10-amh-u3-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-amh-u3-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-amh-u3-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-amh-u3-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-amh-u4",
        name: "Unit 4 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g10-amh-u4-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-amh-u4-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-amh-u4-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-amh-u4-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-amh-u5",
        name: "Unit 5: Marriage Traditions in Ethiopia",
        subUnits: [
          {
            id: "g10-amh-u5-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-amh-u5-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-amh-u5-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-amh-u5-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-amh-u6",
        name: "Unit 6: Women in Development",
        subUnits: [
          {
            id: "g10-amh-u6-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-amh-u6-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-amh-u6-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-amh-u6-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-amh-u7",
        name: "Unit 7 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g10-amh-u7-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-amh-u7-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-amh-u7-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-amh-u7-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-amh-u8",
        name: "Unit 8 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g10-amh-u8-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-amh-u8-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-amh-u8-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-amh-u8-s4",
            name: "Writing",
          },
        ],
      },
      {
        id: "g10-amh-u9",
        name: "Unit 9 (TBD — verify against textbook)",
        subUnits: [
          {
            id: "g10-amh-u9-s1",
            name: "Listening and Speaking",
          },
          {
            id: "g10-amh-u9-s2",
            name: "Reading Comprehension",
          },
          {
            id: "g10-amh-u9-s3",
            name: "Vocabulary and Grammar",
          },
          {
            id: "g10-amh-u9-s4",
            name: "Writing",
          },
        ],
      },
    ],
  },
  {
    id: "g10-ict",
    name: "Information Technology",
    icon: "MonitorSmartphone",
    grade: "10",
    units: [
      {
        id: "g10-ict-u1",
        name: "Unit 1: Organization of Files",
        subUnits: [
          {
            id: "g10-ict-u1-s1",
            name: "Advanced File and Folder Management",
          },
          {
            id: "g10-ict-u1-s2",
            name: "File Systems and Storage Devices",
          },
          {
            id: "g10-ict-u1-s3",
            name: "Backup Strategies",
          },
        ],
      },
      {
        id: "g10-ict-u2",
        name: "Unit 2: Computer Network",
        subUnits: [
          {
            id: "g10-ict-u2-s1",
            name: "Network Architecture and Protocols",
          },
          {
            id: "g10-ict-u2-s2",
            name: "Wired and Wireless Networking",
          },
          {
            id: "g10-ict-u2-s3",
            name: "Network Troubleshooting Basics",
          },
        ],
      },
      {
        id: "g10-ict-u3",
        name: "Unit 3: Application Software",
        subUnits: [
          {
            id: "g10-ict-u3-s1",
            name: "Advanced Word Processing",
          },
          {
            id: "g10-ict-u3-s2",
            name: "Advanced Spreadsheet Functions",
          },
          {
            id: "g10-ict-u3-s3",
            name: "Database Management Systems",
          },
        ],
      },
      {
        id: "g10-ict-u4",
        name: "Unit 4: Image Processing and Multimedia",
        subUnits: [
          {
            id: "g10-ict-u4-s1",
            name: "Image File Formats and Editing",
          },
          {
            id: "g10-ict-u4-s2",
            name: "Audio and Video Editing Basics",
          },
          {
            id: "g10-ict-u4-s3",
            name: "Multimedia Project Production",
          },
        ],
      },
      {
        id: "g10-ict-u5",
        name: "Unit 5: Information and Computer Security",
        subUnits: [
          {
            id: "g10-ict-u5-s1",
            name: "Types of Cyber Threats",
          },
          {
            id: "g10-ict-u5-s2",
            name: "Data Encryption and Protection",
          },
          {
            id: "g10-ict-u5-s3",
            name: "Digital Ethics and Legal Issues",
          },
        ],
      },
      {
        id: "g10-ict-u6",
        name: "Unit 6: Fundamentals of Programming",
        subUnits: [
          {
            id: "g10-ict-u6-s1",
            name: "Variables, Data Types and Operators",
          },
          {
            id: "g10-ict-u6-s2",
            name: "Control Structures",
          },
          {
            id: "g10-ict-u6-s3",
            name: "Writing and Debugging Simple Programs",
          },
        ],
      },
    ],
  },
  {
    id: "g10-hpe",
    name: "Health and Physical Education",
    icon: "Activity",
    grade: "10",
    units: [
      {
        id: "g10-hpe-u1",
        name: "Unit 1: Sport and Society",
        subUnits: [
          {
            id: "g10-hpe-u1-s1",
            name: "Sport, Media and Politics",
          },
          {
            id: "g10-hpe-u1-s2",
            name: "Sport and Religion",
          },
          {
            id: "g10-hpe-u1-s3",
            name: "Sport for Humanitarian and Peace Development",
          },
        ],
      },
      {
        id: "g10-hpe-u2",
        name: "Unit 2: Health and Physical Fitness",
        subUnits: [
          {
            id: "g10-hpe-u2-s1",
            name: "Advanced Components of Fitness",
          },
          {
            id: "g10-hpe-u2-s2",
            name: "Fitness Testing and Evaluation",
          },
          {
            id: "g10-hpe-u2-s3",
            name: "Designing a Personal Fitness Program",
          },
        ],
      },
      {
        id: "g10-hpe-u3",
        name: "Unit 3: Athletics",
        subUnits: [
          {
            id: "g10-hpe-u3-s1",
            name: "Advanced Track Techniques",
          },
          {
            id: "g10-hpe-u3-s2",
            name: "Advanced Field Techniques",
          },
          {
            id: "g10-hpe-u3-s3",
            name: "Competition Rules and Officiating",
          },
        ],
      },
      {
        id: "g10-hpe-u4",
        name: "Unit 4: Football",
        subUnits: [
          {
            id: "g10-hpe-u4-s1",
            name: "Advanced Techniques and Tactics",
          },
          {
            id: "g10-hpe-u4-s2",
            name: "Team Strategy and Positioning",
          },
          {
            id: "g10-hpe-u4-s3",
            name: "Officiating and Safety",
          },
        ],
      },
      {
        id: "g10-hpe-u5",
        name: "Unit 5: Volleyball",
        subUnits: [
          {
            id: "g10-hpe-u5-s1",
            name: "Advanced Techniques and Tactics",
          },
          {
            id: "g10-hpe-u5-s2",
            name: "Team Strategy and Positioning",
          },
          {
            id: "g10-hpe-u5-s3",
            name: "Officiating and Safety",
          },
        ],
      },
      {
        id: "g10-hpe-u6",
        name: "Unit 6: Basketball",
        subUnits: [
          {
            id: "g10-hpe-u6-s1",
            name: "Advanced Techniques and Tactics",
          },
          {
            id: "g10-hpe-u6-s2",
            name: "Team Strategy and Positioning",
          },
          {
            id: "g10-hpe-u6-s3",
            name: "Officiating and Safety",
          },
        ],
      },
      {
        id: "g10-hpe-u7",
        name: "Unit 7: Handball",
        subUnits: [
          {
            id: "g10-hpe-u7-s1",
            name: "Advanced Techniques and Tactics",
          },
          {
            id: "g10-hpe-u7-s2",
            name: "Team Strategy and Positioning",
          },
          {
            id: "g10-hpe-u7-s3",
            name: "Officiating and Safety",
          },
        ],
      },
      {
        id: "g10-hpe-u8",
        name: "Unit 8: Self-Defense and Sport Ethics",
        subUnits: [
          {
            id: "g10-hpe-u8-s1",
            name: "Intermediate Self-Defense Techniques",
          },
          {
            id: "g10-hpe-u8-s2",
            name: "Doping and Its Consequences",
          },
          {
            id: "g10-hpe-u8-s3",
            name: "Ethics, Fair Play and Injury Prevention",
          },
        ],
      },
    ],
  },
  {
    id: "g11-biolo",
    name: "Biology",
    icon: "Dna",
    grade: "11",
    stream: "Natural",
    units: [
      {
        id: "g11-biolog-u1",
        name: "Unit: The science of biology",
        subUnits: [
          {
            id: "g11-biolog-u1-s1",
            name: "The methods of science",
          },
          {
            id: "g11-biolog-u1-s2",
            name: "The tools of a biologist",
          },
          {
            id: "g11-biolog-u1-s3",
            name: "The relevance and promise of biological science",
          },
          {
            id: "g11-biolog-u1-s4",
            name: "Biology and HIV/AIDS",
          },
        ],
      },
      {
        id: "g11-biolog-u2",
        name: "Unit: Biochemical molecules",
        subUnits: [
          {
            id: "g11-biolog-u2-s1",
            name: "Inorganic and organic molecules",
          },
          {
            id: "g11-biolog-u2-s2",
            name: "Inorganic molecules",
          },
          {
            id: "g11-biolog-u2-s3",
            name: "Organic molecules",
          },
        ],
      },
      {
        id: "g11-biolog-u3",
        name: "Unit: Enzymes",
        subUnits: [
          {
            id: "g11-biolog-u3-s1",
            name: "Nature of enzymes",
          },
          {
            id: "g11-biolog-u3-s2",
            name: "Functions of enzymes",
          },
          {
            id: "g11-biolog-u3-s3",
            name: "Factors affecting the functions of enzymes",
          },
        ],
      },
      {
        id: "g11-biolog-u4",
        name: "Unit: Cell biology",
        subUnits: [
          {
            id: "g11-biolog-u4-s1",
            name: "Cell theory",
          },
          {
            id: "g11-biolog-u4-s2",
            name: "Types of cells",
          },
          {
            id: "g11-biolog-u4-s3",
            name: "Parts of the cell and their functions",
          },
        ],
      },
      {
        id: "g11-biolog-u5",
        name: "Unit: Energy transformation",
        subUnits: [
          {
            id: "g11-biolog-u5-s1",
            name: "Respiration",
          },
          {
            id: "g11-biolog-u5-s2",
            name: "How do plants harness light energy in photosynthesis?",
          },
        ],
      },
    ],
  },
  {
    id: "g11-chemi",
    name: "Chemistry",
    icon: "FlaskConical",
    grade: "11",
    stream: "Natural",
    units: [
      {
        id: "g11-chemis-u1",
        name: "Unit: Fundamental Concepts in Chemistry",
        subUnits: [
          {
            id: "g11-chemis-u1-s1",
            name: "The Scope of Chemistry",
          },
          {
            id: "g11-chemis-u1-s2",
            name: "Measurements and Units in Chemistry",
          },
          {
            id: "g11-chemis-u1-s3",
            name: "Chemistry as Experimental Science",
          },
        ],
      },
      {
        id: "g11-chemis-u2",
        name: "Unit: Atomic Structure and Periodic Table",
        subUnits: [
          {
            id: "g11-chemis-u2-s1",
            name: "Historical Development of the Atomic Nature of Substances",
          },
          {
            id: "g11-chemis-u2-s2",
            name: "Dalton’s Atomic Theory and the Modern Atomic Theory",
          },
          {
            id: "g11-chemis-u2-s3",
            name: "Early Experiments to Characterize the Atom",
          },
          {
            id: "g11-chemis-u2-s4",
            name: "Makeup of the Nucleus",
          },
          {
            id: "g11-chemis-u2-s5",
            name: "Electromagnetic Radiation (EMR) and Atomic Spectra",
          },
          {
            id: "g11-chemis-u2-s6",
            name: "The Quantum Mechanical Model of the Atom",
          },
          {
            id: "g11-chemis-u2-s7",
            name: "Electronic Configurations and Orbital Diagrams",
          },
          {
            id: "g11-chemis-u2-s8",
            name: "Electric Configuration and the Periodic Table of the Elements",
          },
        ],
      },
      {
        id: "g11-chemis-u3",
        name: "Unit: Chemical Bonding and Structure",
        subUnits: [
          {
            id: "g11-chemis-u3-s1",
            name: "Introduction",
          },
          {
            id: "g11-chemis-u3-s2",
            name: "Ionic Bonding",
          },
          {
            id: "g11-chemis-u3-s3",
            name: "Covalent Bonding and Molecular Geometry",
          },
          {
            id: "g11-chemis-u3-s4",
            name: "Metallic Bonding",
          },
          {
            id: "g11-chemis-u3-s5",
            name: "Chemical Bonding Theories",
          },
          {
            id: "g11-chemis-u3-s6",
            name: "Types of Crystals",
          },
        ],
      },
      {
        id: "g11-chemis-u4",
        name: "Unit: Chemical Kinetics",
        subUnits: [
          {
            id: "g11-chemis-u4-s1",
            name: "Rate of Reaction",
          },
          {
            id: "g11-chemis-u4-s2",
            name: "Theories of Reaction Rates",
          },
          {
            id: "g11-chemis-u4-s3",
            name: "Rate Equation or Rate Law",
          },
          {
            id: "g11-chemis-u4-s4",
            name: "Reaction Mechanism",
          },
        ],
      },
      {
        id: "g11-chemis-u5",
        name: "Unit: Chemical Equilibrium and Phase Equilibrium",
        subUnits: [
          {
            id: "g11-chemis-u5-s1",
            name: "Chemical Equilibrium",
          },
          {
            id: "g11-chemis-u5-s2",
            name: "Phase Equilibrium",
          },
        ],
      },
      {
        id: "g11-chemis-u6",
        name: "Unit: Carboxylic Acids, Esters, Fats and Oils",
        subUnits: [
          {
            id: "g11-chemis-u6-s1",
            name: "Carboxylic Acids",
          },
          {
            id: "g11-chemis-u6-s2",
            name: "Esters",
          },
          {
            id: "g11-chemis-u6-s3",
            name: "Fats and Oils",
          },
        ],
      },
    ],
  },
  {
    id: "g11-physi",
    name: "Physics",
    icon: "Zap",
    grade: "11",
    stream: "Natural",
    units: [
      {
        id: "g11-physic-u1",
        name: "Unit: Measurement and practical work",
        subUnits: [
          {
            id: "g11-physic-u1-s1",
            name: "Science of measurement",
          },
          {
            id: "g11-physic-u1-s2",
            name: "Errors in measurement",
          },
          {
            id: "g11-physic-u1-s3",
            name: "Precision, accuracy and significance",
          },
          {
            id: "g11-physic-u1-s4",
            name: "Report writing",
          },
        ],
      },
      {
        id: "g11-physic-u2",
        name: "Unit: Vector quantities",
        subUnits: [
          {
            id: "g11-physic-u2-s1",
            name: "Types of vector",
          },
          {
            id: "g11-physic-u2-s2",
            name: "Resolution of vectors",
          },
          {
            id: "g11-physic-u2-s3",
            name: "Vector addition and subtraction",
          },
          {
            id: "g11-physic-u2-s4",
            name: "Multiplication of vectors",
          },
        ],
      },
      {
        id: "g11-physic-u3",
        name: "Unit: Kinematics",
        subUnits: [
          {
            id: "g11-physic-u3-s1",
            name: "Motion in a straight line",
          },
          {
            id: "g11-physic-u3-s2",
            name: "Motion in a plane",
          },
        ],
      },
      {
        id: "g11-physic-u4",
        name: "Unit: Dynamics",
        subUnits: [
          {
            id: "g11-physic-u4-s1",
            name: "The force concept",
          },
          {
            id: "g11-physic-u4-s2",
            name: "Basic laws of dynamics",
          },
          {
            id: "g11-physic-u4-s3",
            name: "Law of conservation of linear momentum and its applications",
          },
          {
            id: "g11-physic-u4-s4",
            name: "Elastic and inelastic collisions in one and two dimensions",
          },
          {
            id: "g11-physic-u4-s5",
            name: "Centre of mass",
          },
          {
            id: "g11-physic-u4-s6",
            name: "Momentum conservation in a variable mass system",
          },
          {
            id: "g11-physic-u4-s7",
            name: "Dynamics of uniform circular motion",
          },
        ],
      },
      {
        id: "g11-physic-u5",
        name: "Unit: Work, energy and power",
        subUnits: [
          {
            id: "g11-physic-u5-s1",
            name: "Work as a scalar product",
          },
          {
            id: "g11-physic-u5-s2",
            name: "Work done by a constant and variable force",
          },
          {
            id: "g11-physic-u5-s3",
            name: "Kinetic energy and the work-energy theorem",
          },
          {
            id: "g11-physic-u5-s4",
            name: "Potential energy",
          },
          {
            id: "g11-physic-u5-s5",
            name: "Conservation of energy",
          },
          {
            id: "g11-physic-u5-s6",
            name: "Conservative and dissipative forces",
          },
          {
            id: "g11-physic-u5-s7",
            name: "Power",
          },
        ],
      },
      {
        id: "g11-physic-u6",
        name: "Unit: Rotational motion",
        subUnits: [
          {
            id: "g11-physic-u6-s1",
            name: "Rotation about a fixed axis",
          },
          {
            id: "g11-physic-u6-s2",
            name: "Torque and angular acceleration",
          },
          {
            id: "g11-physic-u6-s3",
            name: "Rotational kinetic energy and rotational inertia",
          },
          {
            id: "g11-physic-u6-s4",
            name: "Rotational dynamics of a rigid body",
          },
          {
            id: "g11-physic-u6-s5",
            name: "Parallel axis theorem",
          },
          {
            id: "g11-physic-u6-s6",
            name: "Angular momentum and angular impulse",
          },
          {
            id: "g11-physic-u6-s7",
            name: "Conservation of angular momentum",
          },
          {
            id: "g11-physic-u6-s8",
            name: "Centre of mass of a rigid body (circular ring, disc, rod and sphere)",
          },
        ],
      },
      {
        id: "g11-physic-u7",
        name: "Unit: Equilibrium",
        subUnits: [
          {
            id: "g11-physic-u7-s1",
            name: "Equilibrium of a particle",
          },
          {
            id: "g11-physic-u7-s2",
            name: "Moment or torque of a force",
          },
          {
            id: "g11-physic-u7-s3",
            name: "Conditions of equilibrium",
          },
          {
            id: "g11-physic-u7-s4",
            name: "Couples",
          },
        ],
      },
      {
        id: "g11-physic-u8",
        name: "Unit: Properties of bulk matter",
        subUnits: [
          {
            id: "g11-physic-u8-s1",
            name: "Elastic behaviour",
          },
          {
            id: "g11-physic-u8-s2",
            name: "Fluid statics",
          },
          {
            id: "g11-physic-u8-s3",
            name: "Fluid dynamics",
          },
          {
            id: "g11-physic-u8-s4",
            name: "Heat, temerature and thermal expansion",
          },
        ],
      },
    ],
  },
  {
    id: "g11-techn",
    name: "Technical Drawing",
    icon: "PenTool",
    grade: "11",
    stream: "Natural",
    units: [
      {
        id: "g11-techni-u1",
        name: "Unit: Introduction To Basic Technical Drawing",
        subUnits: [
          {
            id: "g11-techni-u1-s1",
            name: "History Of Drawing",
          },
          {
            id: "g11-techni-u1-s2",
            name: "Areas/professional Disciplines Of Technical Drawing",
          },
          {
            id: "g11-techni-u1-s3",
            name: "Technical Drawing Today (Computer Aided Design And Drafting)",
          },
          {
            id: "g11-techni-u1-s4",
            name: "Use And Educational Value Of Technical Drawing",
          },
        ],
      },
      {
        id: "g11-techni-u2",
        name: "Unit: Basic Technical Drawing Equipment",
        subUnits: [
          {
            id: "g11-techni-u2-s1",
            name: "Introduction",
          },
          {
            id: "g11-techni-u2-s2",
            name: "Selection Of Drawing Materials",
          },
          {
            id: "g11-techni-u2-s3",
            name: "Selection Of Drawing Instruments",
          },
          {
            id: "g11-techni-u2-s4",
            name: "Application Of Basic Technical Drawing Equipments",
          },
        ],
      },
      {
        id: "g11-techni-u3",
        name: "Unit: Alphabet Of Lines",
        subUnits: [
          {
            id: "g11-techni-u3-s1",
            name: "Introduction",
          },
        ],
      },
      {
        id: "g11-techni-u4",
        name: "Unit: Lettering",
        subUnits: [
          {
            id: "g11-techni-u4-s1",
            name: "Introduction",
          },
          {
            id: "g11-techni-u4-s2",
            name: "Technique Of Lettering",
          },
          {
            id: "g11-techni-u4-s3",
            name: "Single Stroke Letters",
          },
          {
            id: "g11-techni-u4-s4",
            name: "Guide Lines",
          },
          {
            id: "g11-techni-u4-s5",
            name: "Uniformity, Stability And Composition Of Lettering",
          },
          {
            id: "g11-techni-u4-s6",
            name: "Leroy Lettering And Lettering Template/ Guide Unit Summary",
          },
        ],
      },
      {
        id: "g11-techni-u5",
        name: "Unit: Geometric Construction",
        subUnits: [
          {
            id: "g11-techni-u5-s1",
            name: "Introduction",
          },
          {
            id: "g11-techni-u5-s2",
            name: "Construction Of Point, Line And Angle",
          },
          {
            id: "g11-techni-u5-s3",
            name: "Polygons",
          },
          {
            id: "g11-techni-u5-s4",
            name: "Circles And Tangents",
          },
          {
            id: "g11-techni-u5-s5",
            name: "Construction Of An Ellipse",
          },
        ],
      },
      {
        id: "g11-techni-u6",
        name: "Unit: Multi-view Drawing",
        subUnits: [
          {
            id: "g11-techni-u6-s1",
            name: "Introduction",
          },
          {
            id: "g11-techni-u6-s2",
            name: "Projection",
          },
          {
            id: "g11-techni-u6-s3",
            name: "Orthographic Projection",
          },
          {
            id: "g11-techni-u6-s4",
            name: "The Six Principal Views",
          },
          {
            id: "g11-techni-u6-s5",
            name: "Fundamental Views Of Edges And Surfaces",
          },
          {
            id: "g11-techni-u6-s6",
            name: "Visualization",
          },
        ],
      },
      {
        id: "g11-techni-u7",
        name: "Unit: Pictorial Drawing",
        subUnits: [
          {
            id: "g11-techni-u7-s1",
            name: "Introduction",
          },
          {
            id: "g11-techni-u7-s2",
            name: "Axonometric Projection",
          },
          {
            id: "g11-techni-u7-s3",
            name: "Oblique Projection",
          },
          {
            id: "g11-techni-u7-s4",
            name: "Perspective Projection",
          },
        ],
      },
    ],
  },
  {
    id: "g11-mathe",
    name: "Mathematics",
    icon: "Calculator",
    grade: "11",
    stream: "Natural",
    units: [
      {
        id: "g11-mathem-u1",
        name: "Unit: Further on Relation and Functions",
        subUnits: [
          {
            id: "g11-mathem-u1-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g11-mathem-u2",
        name: "Revision on relations",
        subUnits: [
          {
            id: "g11-mathem-u2-s1",
            name: "Some additional types of functions",
          },
          {
            id: "g11-mathem-u2-s2",
            name: "Classification of functions",
          },
          {
            id: "g11-mathem-u2-s3",
            name: "Composition of functions",
          },
          {
            id: "g11-mathem-u2-s4",
            name: "Inverse functions and their graphs",
          },
        ],
      },
      {
        id: "g11-mathem-u3",
        name: "Unit: Rational Expressions and Rational Functions",
        subUnits: [
          {
            id: "g11-mathem-u3-s1",
            name: "Simplification of rational expressions",
          },
          {
            id: "g11-mathem-u3-s2",
            name: "Rational equations",
          },
          {
            id: "g11-mathem-u3-s3",
            name: "Rational functions and their graphs",
          },
        ],
      },
      {
        id: "g11-mathem-u4",
        name: "Unit: Coordinate Geometry",
        subUnits: [
          {
            id: "g11-mathem-u4-s1",
            name: "Straight line",
          },
          {
            id: "g11-mathem-u4-s2",
            name: "Conic sections",
          },
        ],
      },
      {
        id: "g11-mathem-u5",
        name: "Unit: Mathematical Reasoning",
        subUnits: [
          {
            id: "g11-mathem-u5-s1",
            name: "Logic",
          },
          {
            id: "g11-mathem-u5-s2",
            name: "Arguments and validity",
          },
        ],
      },
      {
        id: "g11-mathem-u6",
        name: "Unit: Statistics and Probability",
        subUnits: [
          {
            id: "g11-mathem-u6-s1",
            name: "Statistics",
          },
          {
            id: "g11-mathem-u6-s2",
            name: "Probability",
          },
        ],
      },
      {
        id: "g11-mathem-u7",
        name: "Unit: Matrices and Determinants",
        subUnits: [
          {
            id: "g11-mathem-u7-s1",
            name: "Matrices",
          },
          {
            id: "g11-mathem-u7-s2",
            name: "Determinants and their properties",
          },
          {
            id: "g11-mathem-u7-s3",
            name: "Inverse of a square matrix",
          },
          {
            id: "g11-mathem-u7-s4",
            name: "Systems of equations with two or three variables",
          },
          {
            id: "g11-mathem-u7-s5",
            name: "Cramer’s rule",
          },
        ],
      },
      {
        id: "g11-mathem-u8",
        name: "Unit: The Set of Complex Numbers",
        subUnits: [
          {
            id: "g11-mathem-u8-s1",
            name: "The concept of complex numbers",
          },
          {
            id: "g11-mathem-u8-s2",
            name: "Operations on complex numbers",
          },
          {
            id: "g11-mathem-u8-s3",
            name: "Complex conjugate and modulus",
          },
          {
            id: "g11-mathem-u8-s4",
            name: "Simplification of complex numbers",
          },
          {
            id: "g11-mathem-u8-s5",
            name: "Argand diagram and polar representation of",
          },
        ],
      },
      {
        id: "g11-mathem-u9",
        name: "Unit: Vectors and Transformation of the Plane (For Natural Science Students)",
        subUnits: [
          {
            id: "g11-mathem-u9-s1",
            name: "Representation of vectors",
          },
          {
            id: "g11-mathem-u9-s2",
            name: "Scalar (inner or dot) product of vectors",
          },
          {
            id: "g11-mathem-u9-s3",
            name: "Application of vector",
          },
          {
            id: "g11-mathem-u9-s4",
            name: "Transformation of the plane",
          },
        ],
      },
      {
        id: "g11-mathem-u10",
        name: "Unit: Further on Trigonometric Functions (For Natural Science Students)",
        subUnits: [
          {
            id: "g11-mathem-u10-s1",
            name: "The functions y -sec x, y z csc x and y z cot x",
          },
          {
            id: "g11-mathem-u10-s2",
            name: "Inverse of trigonometric functions",
          },
          {
            id: "g11-mathem-u10-s3",
            name: "Graphs of some trigonometric functions",
          },
          {
            id: "g11-mathem-u10-s4",
            name: "Applications of trigonometric functions",
          },
        ],
      },
    ],
  },
  {
    id: "g11-ict",
    name: "ICT",
    icon: "Laptop",
    grade: "11",
    stream: "Natural",
    units: [
      {
        id: "g11-ict-u1",
        name: "Unit: Information Systems",
        subUnits: [
          {
            id: "g11-ict-u1-s1",
            name: "Know the application of ICT in different sectors",
          },
          {
            id: "g11-ict-u1-s2",
            name: "Understand the components of an Information System",
          },
          {
            id: "g11-ict-u1-s3",
            name: "Recognise the application of ICT in different sectors",
          },
          {
            id: "g11-ict-u1-s4",
            name: "Recognise how ICT can change the life of people",
          },
        ],
      },
      {
        id: "g11-ict-u2",
        name: "Unit: Enhancing the Use of Software",
        subUnits: [
          {
            id: "g11-ict-u2-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g11-ict-u3",
        name: "Unit: Basic Troubleshooting",
        subUnits: [
          {
            id: "g11-ict-u3-s1",
            name: "Recognise basic idea in preventive maintenance",
          },
          {
            id: "g11-ict-u3-s2",
            name: "Apply the knowledge gained in preventive maintenance to prolong the life of the computer",
          },
          {
            id: "g11-ict-u3-s3",
            name: "Be aware of basic safety issues",
          },
          {
            id: "g11-ict-u3-s4",
            name: "Recognise major hardware components inside the computer",
          },
          {
            id: "g11-ict-u3-s5",
            name: "Acquire knowledge on how to format hard disc and install software",
          },
        ],
      },
      {
        id: "g11-ict-u4",
        name: "Unit: Exploiting the Internet",
        subUnits: [
          {
            id: "g11-ict-u4-s1",
            name: "Develop an awareness of web developments in making information available in different formats",
          },
        ],
      },
      {
        id: "g11-ict-u5",
        name: "Unit: Image Processing and Multimedia Systems",
        subUnits: [
          {
            id: "g11-ict-u5-s1",
            name: "Understand the concept of image processing",
          },
          {
            id: "g11-ict-u5-s2",
            name: "Differentiate image file format",
          },
          {
            id: "g11-ict-u5-s3",
            name: "Recognize the function of image processing software",
          },
          {
            id: "g11-ict-u5-s4",
            name: "Recognize Interface layout of Image processing software",
          },
          {
            id: "g11-ict-u5-s5",
            name: "Edit images properly using image processing software",
          },
        ],
      },
    ],
  },
  {
    id: "g11-geogr-soc",
    name: "Geography",
    icon: "Globe",
    grade: "11",
    stream: "Social",
    units: [
      {
        id: "g11-geogra-u1",
        name: "Unit: The Science Of Geography",
        subUnits: [
          {
            id: "g11-geogra-u1-s1",
            name: "The Meaning Of Geography",
          },
          {
            id: "g11-geogra-u1-s2",
            name: "The Scope Of Geography",
          },
          {
            id: "g11-geogra-u1-s3",
            name: "Approaches In Geography",
          },
          {
            id: "g11-geogra-u1-s4",
            name: "Major School Of Thought In Geography",
          },
          {
            id: "g11-geogra-u1-s5",
            name: "The Relationship Between Geography And Other Disciplines",
          },
        ],
      },
      {
        id: "g11-geogra-u2",
        name: "Unit: Map Reading And Interpretation",
        subUnits: [
          {
            id: "g11-geogra-u2-s1",
            name: "Relief Representation On Contour Map",
          },
          {
            id: "g11-geogra-u2-s2",
            name: "Drainage On Map",
          },
          {
            id: "g11-geogra-u2-s3",
            name: "The Study Of Human Made Features On Maps",
          },
          {
            id: "g11-geogra-u2-s4",
            name: "Geographical Information System",
          },
        ],
      },
      {
        id: "g11-geogra-u3",
        name: "Unit: An Overview Of Physical Geography Of Africa",
        subUnits: [
          {
            id: "g11-geogra-u3-s1",
            name: "Geological And Relief Structure Of Africa",
          },
          {
            id: "g11-geogra-u3-s2",
            name: "Climate Of Africa",
          },
          {
            id: "g11-geogra-u3-s3",
            name: "Drainage In Africa",
          },
          {
            id: "g11-geogra-u3-s4",
            name: "Natural Vegetation And Wild Animals Of Africa",
          },
          {
            id: "g11-geogra-u3-s5",
            name: "Soils Of Africa",
          },
        ],
      },
      {
        id: "g11-geogra-u4",
        name: "Unit: Population, Economy And Natural Resources Of Africa",
        subUnits: [
          {
            id: "g11-geogra-u4-s1",
            name: "Aspects Of Population, Economy And Natural Resources Of Africa",
          },
          {
            id: "g11-geogra-u4-s2",
            name: "Concepts Of Economic Growth And Development",
          },
          {
            id: "g11-geogra-u4-s3",
            name: "Natural Resources Of Africa And Its Politics",
          },
        ],
      },
    ],
  },
  {
    id: "g11-histo-soc",
    name: "History",
    icon: "Landmark",
    grade: "11",
    stream: "Social",
    units: [
      {
        id: "g11-histor-u1",
        name: "Unit: History and the Historian’s Craft",
        subUnits: [
          {
            id: "g11-histor-u1-s1",
            name: "The Meaning and Use",
          },
          {
            id: "g11-histor-u1-s2",
            name: "Key Elements in the Study history",
          },
          {
            id: "g11-histor-u1-s3",
            name: "The Study of Ethiopian History",
          },
          {
            id: "g11-histor-u1-s4",
            name: "Periodization in History",
          },
        ],
      },
      {
        id: "g11-histor-u2",
        name: "Unit: Early Development of Human Beings",
        subUnits: [
          {
            id: "g11-histor-u2-s1",
            name: "Theories of the Origin of Human Beings",
          },
          {
            id: "g11-histor-u2-s2",
            name: "Human Evolution",
          },
          {
            id: "g11-histor-u2-s3",
            name: "Early Cultural Development",
          },
        ],
      },
      {
        id: "g11-histor-u3",
        name: "Unit: The Ancient World",
        subUnits: [
          {
            id: "g11-histor-u3-s1",
            name: "Emergence of States",
          },
          {
            id: "g11-histor-u3-s2",
            name: "Ancient World Civilazion",
          },
          {
            id: "g11-histor-u3-s3",
            name: "Christianity",
          },
        ],
      },
      {
        id: "g11-histor-u4",
        name: "Unit: The Medieval Period or Middle Ages",
        subUnits: [
          {
            id: "g11-histor-u4-s1",
            name: "Europe During the Middle Ages",
          },
          {
            id: "g11-histor-u4-s2",
            name: "The Byzantine Empire",
          },
          {
            id: "g11-histor-u4-s3",
            name: "The Rise and Expansion of Islam",
          },
          {
            id: "g11-histor-u4-s4",
            name: "Medieval Society",
          },
          {
            id: "g11-histor-u4-s5",
            name: "The Middle Ages in the Far East",
          },
          {
            id: "g11-histor-u4-s6",
            name: "The Development of Early Capitalism in the Middle Ages",
          },
        ],
      },
      {
        id: "g11-histor-u5",
        name: "Unit: The Ethiopian Region and the Horn of Africa up to 1270",
        subUnits: [
          {
            id: "g11-histor-u5-s1",
            name: "People and Languages of the Ethiopia Region and the Horn of",
          },
          {
            id: "g11-histor-u5-s2",
            name: "The Aksumite Kingdom",
          },
          {
            id: "g11-histor-u5-s3",
            name: "The Zagwe Dynasty",
          },
        ],
      },
      {
        id: "g11-histor-u6",
        name: "Unit: The Transition from Medieval to Modern Period",
        subUnits: [
          {
            id: "g11-histor-u6-s1",
            name: "The Renaissance: A Rebirth of",
          },
          {
            id: "g11-histor-u6-s2",
            name: "The Reformation",
          },
          {
            id: "g11-histor-u6-s3",
            name: "The Rise of Absolute Monarchs and the National States",
          },
          {
            id: "g11-histor-u6-s4",
            name: "European Expansion Over Seas",
          },
        ],
      },
      {
        id: "g11-histor-u7",
        name: "Unit: The Ethiopian Region and Horn of Africa up to 1529",
        subUnits: [
          {
            id: "g11-histor-u7-s1",
            name: "Restoration of the Solomonic Dynasty and the Christian Highland Kingdom",
          },
          {
            id: "g11-histor-u7-s2",
            name: "Muslim Sates in the Ethiopian Region and the Hom Of Africa up to 1529",
          },
          {
            id: "g11-histor-u7-s3",
            name: "Omotic Sates in the Ethiopian Region and Hom of Africa up to 1529",
          },
          {
            id: "g11-histor-u7-s4",
            name: "Hegemony of the Christian Highland Kingdom in the Ethiopian Region and the Hom of Africa to 1529",
          },
        ],
      },
      {
        id: "g11-histor-u8",
        name: "Unit: Major Events of the 16th Century Ethiopian Region and the Horn of Africa and their Impacts",
        subUnits: [
          {
            id: "g11-histor-u8-s1",
            name: "Portuguese and Ottoman Turkish Rivalries in the Ethiopian Region and the Horn of Africa",
          },
          {
            id: "g11-histor-u8-s2",
            name: "Conflicts Between the Sultanate of Adal and the Highland Christian Kingdom",
          },
          {
            id: "g11-histor-u8-s3",
            name: "Oromo Population Movement",
          },
        ],
      },
      {
        id: "g11-histor-u9",
        name: "Unit: The Ethiopian Christian Highland Kingdom (1543 - 1855)",
        subUnits: [
          {
            id: "g11-histor-u9-s1",
            name: "Attempts to Consolidate end Shift the Political Centre of the Highland Christian Kingdom",
          },
          {
            id: "g11-histor-u9-s2",
            name: "Catholicization and Civil Wars",
          },
          {
            id: "g11-histor-u9-s3",
            name: "The Gondar Period (1636- 1739)",
          },
          {
            id: "g11-histor-u9-s4",
            name: "The Zemene Mesafint (The Era of the Lords)",
          },
        ],
      },
      {
        id: "g11-histor-u10",
        name: "Unit: Capitalism and the Growth of Democracy",
        subUnits: [
          {
            id: "g11-histor-u10-s1",
            name: "China and Japan in the and 17th",
          },
          {
            id: "g11-histor-u10-s2",
            name: "The English Revolution",
          },
          {
            id: "g11-histor-u10-s3",
            name: "The Enlightenment",
          },
          {
            id: "g11-histor-u10-s4",
            name: "The American War Of Independence",
          },
          {
            id: "g11-histor-u10-s5",
            name: "The French Revolution",
          },
          {
            id: "g11-histor-u10-s6",
            name: "The Napoleonic Era (1799 – 1855) and Its Consequences",
          },
          {
            id: "g11-histor-u10-s7",
            name: "The Industrial Revolution",
          },
          {
            id: "g11-histor-u10-s8",
            name: "The Age of Reaction (1815 – 1848)",
          },
        ],
      },
      {
        id: "g11-histor-u11",
        name: "Unit: Peoples and States in Pre-Colonial Africa (1000 - 1884)",
        subUnits: [
          {
            id: "g11-histor-u11-s1",
            name: "North Africa",
          },
          {
            id: "g11-histor-u11-s2",
            name: "Western Africa (Western Sudan)",
          },
          {
            id: "g11-histor-u11-s3",
            name: "Equatorial, Eastern and South-Eastern Africa",
          },
          {
            id: "g11-histor-u11-s4",
            name: "Southern Africa",
          },
          {
            id: "g11-histor-u11-s5",
            name: "The Trans-Atlantic Slave Trade",
          },
        ],
      },
    ],
  },
  {
    id: "g11-econo-soc",
    name: "Economics",
    icon: "TrendingUp",
    grade: "11",
    stream: "Social",
    units: [
      {
        id: "g11-econom-u1",
        name: "Unit: Concepts of Economics",
        subUnits: [
          {
            id: "g11-econom-u1-s1",
            name: "Meaning And Scope Of Economics",
          },
          {
            id: "g11-econom-u1-s2",
            name: "Methods Of Studying Economic Principles",
          },
          {
            id: "g11-econom-u1-s3",
            name: "Resource Allocation",
          },
          {
            id: "g11-econom-u1-s4",
            name: "Economic Systems",
          },
          {
            id: "g11-econom-u1-s5",
            name: "Decision-Making Units And Circular Flows Of Economic Units",
          },
        ],
      },
      {
        id: "g11-econom-u2",
        name: "Unit: Demand, Supply and Elasticity",
        subUnits: [
          {
            id: "g11-econom-u2-s1",
            name: "Theory Of Demand",
          },
          {
            id: "g11-econom-u2-s2",
            name: "Theory Of Supply",
          },
          {
            id: "g11-econom-u2-s3",
            name: "Market Equilibrium",
          },
          {
            id: "g11-econom-u2-s4",
            name: "Elasticity Of Demand And Supply",
          },
          {
            id: "g11-econom-u2-s5",
            name: "Elasticity Of Supply",
          },
        ],
      },
      {
        id: "g11-econom-u3",
        name: "Unit: Theory of Consumer Behavior",
        subUnits: [
          {
            id: "g11-econom-u3-s1",
            name: "The Concept Of Utility",
          },
          {
            id: "g11-econom-u3-s2",
            name: "The Cardinal Utility Theory",
          },
          {
            id: "g11-econom-u3-s3",
            name: "The Ordinal Utility Theory: Indifference Curve Approach",
          },
        ],
      },
      {
        id: "g11-econom-u4",
        name: "Unit: Theory of Production and Cost",
        subUnits: [
          {
            id: "g11-econom-u4-s1",
            name: "Theory Of Production",
          },
          {
            id: "g11-econom-u4-s2",
            name: "Theory Of Cost",
          },
          {
            id: "g11-econom-u4-s3",
            name: "Relationship Between Production And Cost",
          },
        ],
      },
      {
        id: "g11-econom-u5",
        name: "Unit: Market Structures and The Decision of a Firm",
        subUnits: [
          {
            id: "g11-econom-u5-s1",
            name: "Perfectly Competitive Market",
          },
          {
            id: "g11-econom-u5-s2",
            name: "Pure Monopoly",
          },
          {
            id: "g11-econom-u5-s3",
            name: "Monopolistically Competitive Market",
          },
          {
            id: "g11-econom-u5-s4",
            name: "Oligopoly Market",
          },
        ],
      },
      {
        id: "g11-econom-u6",
        name: "Unit: The Fundamental Concerns of Macroeconomics",
        subUnits: [
          {
            id: "g11-econom-u6-s1",
            name: "Concerns Of Macroeconomics",
          },
          {
            id: "g11-econom-u6-s2",
            name: "Problems Of Macroeconomics",
          },
        ],
      },
      {
        id: "g11-econom-u7",
        name: "Unit: National Income Account",
        subUnits: [
          {
            id: "g11-econom-u7-s1",
            name: "GDP (Gross Domestic Product) Definition And Its Measurement",
          },
          {
            id: "g11-econom-u7-s2",
            name: "GDP (Gross Domestic Product) Definition And Its Measurement",
          },
          {
            id: "g11-econom-u7-s3",
            name: "Other National Income Account",
          },
          {
            id: "g11-econom-u7-s4",
            name: "GDP And Income Distribution",
          },
        ],
      },
      {
        id: "g11-econom-u8",
        name: "Unit: Consumption, Saving and Investment",
        subUnits: [
          {
            id: "g11-econom-u8-s1",
            name: "Consumption",
          },
          {
            id: "g11-econom-u8-s2",
            name: "Saving",
          },
          {
            id: "g11-econom-u8-s3",
            name: "Relationship Between Consumption And Saving",
          },
          {
            id: "g11-econom-u8-s4",
            name: "Investment",
          },
        ],
      },
      {
        id: "g11-econom-u9",
        name: "Unit: International Trade and Balance of Payments",
        subUnits: [
          {
            id: "g11-econom-u9-s1",
            name: "International Trade",
          },
          {
            id: "g11-econom-u9-s2",
            name: "Balance Of Payments",
          },
          {
            id: "g11-econom-u9-s3",
            name: "Foreign Exchange Rates",
          },
        ],
      },
      {
        id: "g11-econom-u10",
        name: "Unit: Macroeconomic Policy Instruments",
        subUnits: [
          {
            id: "g11-econom-u10-s1",
            name: "Determination Of Levels Of Output, Prices And Employment",
          },
          {
            id: "g11-econom-u10-s2",
            name: "Macroeconomic Policies",
          },
        ],
      },
    ],
  },
  {
    id: "g11-busin-soc",
    name: "Business",
    icon: "TrendingUp",
    grade: "11",
    stream: "Social",
    units: [
      {
        id: "g11-busine-u1",
        name: "Unit: The Nature Of Business",
        subUnits: [
          {
            id: "g11-busine-u1-s1",
            name: "What Is Business?",
          },
          {
            id: "g11-busine-u1-s2",
            name: "Importance Of Business Enterprises",
          },
          {
            id: "g11-busine-u1-s3",
            name: "Kinds Of Business",
          },
          {
            id: "g11-busine-u1-s4",
            name: "Business Environment",
          },
        ],
      },
      {
        id: "g11-busine-u2",
        name: "Unit: Type And Forms Of Business Ownership",
        subUnits: [
          {
            id: "g11-busine-u2-s1",
            name: "Common Forms Of Business Ownership",
          },
          {
            id: "g11-busine-u2-s2",
            name: "Other Forms Of Business Owner Ships",
          },
          {
            id: "g11-busine-u2-s3",
            name: "Choice Of Ownership Form",
          },
        ],
      },
      {
        id: "g11-busine-u3",
        name: "Unit: Financing Business Organizations",
        subUnits: [
          {
            id: "g11-busine-u3-s1",
            name: "Money And Its Importance",
          },
          {
            id: "g11-busine-u3-s2",
            name: "Source Of Capital For Investment",
          },
          {
            id: "g11-busine-u3-s3",
            name: "Bonds And Stocks",
          },
          {
            id: "g11-busine-u3-s4",
            name: "The Banking System",
          },
          {
            id: "g11-busine-u3-s5",
            name: "Risk And Insurance",
          },
          {
            id: "g11-busine-u3-s6",
            name: "Classifications Of Insurance",
          },
          {
            id: "g11-busine-u3-s7",
            name: "The Practice Of Insurance In Ethiopian",
          },
          {
            id: "g11-busine-u3-s8",
            name: "Investment Policies In Ethiopia",
          },
        ],
      },
      {
        id: "g11-busine-u4",
        name: "Unit: Production",
        subUnits: [
          {
            id: "g11-busine-u4-s1",
            name: "Definition Of Production",
          },
          {
            id: "g11-busine-u4-s2",
            name: "Production Functions",
          },
          {
            id: "g11-busine-u4-s3",
            name: "Factors Of Production",
          },
          {
            id: "g11-busine-u4-s4",
            name: "Production/operation Management",
          },
          {
            id: "g11-busine-u4-s5",
            name: "Cost Of Production",
          },
          {
            id: "g11-busine-u4-s6",
            name: "Location Of Facilities And Infrastructure For Production Process",
          },
        ],
      },
    ],
  },
  {
    id: "g11-mathe-soc",
    name: "Mathematics",
    icon: "Calculator",
    grade: "11",
    stream: "Social",
    units: [
      {
        id: "g11-mathem-u1",
        name: "Unit: Further on Relation and Functions",
        subUnits: [
          {
            id: "g11-mathem-u1-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g11-mathem-u2",
        name: "Revision on relations",
        subUnits: [
          {
            id: "g11-mathem-u2-s1",
            name: "Some additional types of functions",
          },
          {
            id: "g11-mathem-u2-s2",
            name: "Classification of functions",
          },
          {
            id: "g11-mathem-u2-s3",
            name: "Composition of functions",
          },
          {
            id: "g11-mathem-u2-s4",
            name: "Inverse functions and their graphs",
          },
        ],
      },
      {
        id: "g11-mathem-u3",
        name: "Unit: Rational Expressions and Rational Functions",
        subUnits: [
          {
            id: "g11-mathem-u3-s1",
            name: "Simplification of rational expressions",
          },
          {
            id: "g11-mathem-u3-s2",
            name: "Rational equations",
          },
          {
            id: "g11-mathem-u3-s3",
            name: "Rational functions and their graphs",
          },
        ],
      },
      {
        id: "g11-mathem-u4",
        name: "Unit: Coordinate Geometry",
        subUnits: [
          {
            id: "g11-mathem-u4-s1",
            name: "Straight line",
          },
          {
            id: "g11-mathem-u4-s2",
            name: "Conic sections",
          },
        ],
      },
      {
        id: "g11-mathem-u5",
        name: "Unit: Mathematical Reasoning",
        subUnits: [
          {
            id: "g11-mathem-u5-s1",
            name: "Logic",
          },
          {
            id: "g11-mathem-u5-s2",
            name: "Arguments and validity",
          },
        ],
      },
      {
        id: "g11-mathem-u6",
        name: "Unit: Statistics and Probability",
        subUnits: [
          {
            id: "g11-mathem-u6-s1",
            name: "Statistics",
          },
          {
            id: "g11-mathem-u6-s2",
            name: "Probability",
          },
        ],
      },
      {
        id: "g11-mathem-u7",
        name: "Unit: Matrices and Determinants",
        subUnits: [
          {
            id: "g11-mathem-u7-s1",
            name: "Matrices",
          },
          {
            id: "g11-mathem-u7-s2",
            name: "Determinants and their properties",
          },
          {
            id: "g11-mathem-u7-s3",
            name: "Inverse of a square matrix",
          },
          {
            id: "g11-mathem-u7-s4",
            name: "Systems of equations with two or three variables",
          },
          {
            id: "g11-mathem-u7-s5",
            name: "Cramer’s rule",
          },
        ],
      },
      {
        id: "g11-mathem-u8",
        name: "Unit: The Set of Complex Numbers",
        subUnits: [
          {
            id: "g11-mathem-u8-s1",
            name: "The concept of complex numbers",
          },
          {
            id: "g11-mathem-u8-s2",
            name: "Operations on complex numbers",
          },
          {
            id: "g11-mathem-u8-s3",
            name: "Complex conjugate and modulus",
          },
          {
            id: "g11-mathem-u8-s4",
            name: "Simplification of complex numbers",
          },
          {
            id: "g11-mathem-u8-s5",
            name: "Argand diagram and polar representation of",
          },
        ],
      },
      {
        id: "g11-mathem-u9",
        name: "Unit: Mathematical Applications in Business (For Social Science Students)",
        subUnits: [
          {
            id: "g11-mathem-u9-s1",
            name: "Basic mathematical concepts in business",
          },
          {
            id: "g11-mathem-u9-s2",
            name: "Compound interest and depreciation",
          },
          {
            id: "g11-mathem-u9-s3",
            name: "Saving, investing and borrowing money",
          },
          {
            id: "g11-mathem-u9-s4",
            name: "Taxation",
          },
        ],
      },
    ],
  },
  {
    id: "g11-ict-soc",
    name: "ICT",
    icon: "Laptop",
    grade: "11",
    stream: "Social",
    units: [
      {
        id: "g11-ict-u1",
        name: "Unit: Information Systems",
        subUnits: [
          {
            id: "g11-ict-u1-s1",
            name: "Know the application of ICT in different sectors",
          },
          {
            id: "g11-ict-u1-s2",
            name: "Understand the components of an Information System",
          },
          {
            id: "g11-ict-u1-s3",
            name: "Recognise the application of ICT in different sectors",
          },
          {
            id: "g11-ict-u1-s4",
            name: "Recognise how ICT can change the life of people",
          },
        ],
      },
      {
        id: "g11-ict-u2",
        name: "Unit: Enhancing the Use of Software",
        subUnits: [
          {
            id: "g11-ict-u2-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g11-ict-u3",
        name: "Unit: Basic Troubleshooting",
        subUnits: [
          {
            id: "g11-ict-u3-s1",
            name: "Recognise basic idea in preventive maintenance",
          },
          {
            id: "g11-ict-u3-s2",
            name: "Apply the knowledge gained in preventive maintenance to prolong the life of the computer",
          },
          {
            id: "g11-ict-u3-s3",
            name: "Be aware of basic safety issues",
          },
          {
            id: "g11-ict-u3-s4",
            name: "Recognise major hardware components inside the computer",
          },
          {
            id: "g11-ict-u3-s5",
            name: "Acquire knowledge on how to format hard disc and install software",
          },
        ],
      },
      {
        id: "g11-ict-u4",
        name: "Unit: Exploiting the Internet",
        subUnits: [
          {
            id: "g11-ict-u4-s1",
            name: "Develop an awareness of web developments in making information available in different formats",
          },
        ],
      },
      {
        id: "g11-ict-u5",
        name: "Unit: Image Processing and Multimedia Systems",
        subUnits: [
          {
            id: "g11-ict-u5-s1",
            name: "Understand the concept of image processing",
          },
          {
            id: "g11-ict-u5-s2",
            name: "Differentiate image file format",
          },
          {
            id: "g11-ict-u5-s3",
            name: "Recognize the function of image processing software",
          },
          {
            id: "g11-ict-u5-s4",
            name: "Recognize Interface layout of Image processing software",
          },
          {
            id: "g11-ict-u5-s5",
            name: "Edit images properly using image processing software",
          },
        ],
      },
    ],
  },
  {
    id: "g12-engli-soc",
    name: "English",
    icon: "BookA",
    grade: "12",
    stream: "Social",
    units: [
      {
        id: "g12-englis-u1",
        name: "Unit: Family life",
        subUnits: [
          {
            id: "g12-englis-u1-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u2",
        name: "Unit: Communication",
        subUnits: [
          {
            id: "g12-englis-u2-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u3",
        name: "Unit: Education",
        subUnits: [
          {
            id: "g12-englis-u3-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u4",
        name: "Revision 1 (Units 1–3)",
        subUnits: [
          {
            id: "g12-englis-u4-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u5",
        name: "Unit: The arts and literature",
        subUnits: [
          {
            id: "g12-englis-u5-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u6",
        name: "Unit: The United Nations",
        subUnits: [
          {
            id: "g12-englis-u6-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u7",
        name: "Unit: Trade and globalisation",
        subUnits: [
          {
            id: "g12-englis-u7-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u8",
        name: "Revision 2 (Units 4–6)",
        subUnits: [
          {
            id: "g12-englis-u8-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u9",
        name: "Unit: Finding a job",
        subUnits: [
          {
            id: "g12-englis-u9-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u10",
        name: "Unit: Human development",
        subUnits: [
          {
            id: "g12-englis-u10-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u11",
        name: "Unit: Tradition versus progress",
        subUnits: [
          {
            id: "g12-englis-u11-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u12",
        name: "Revision 3 (Units 7–9)",
        subUnits: [
          {
            id: "g12-englis-u12-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u13",
        name: "Unit: Future threats",
        subUnits: [
          {
            id: "g12-englis-u13-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u14",
        name: "Unit: The film industry",
        subUnits: [
          {
            id: "g12-englis-u14-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u15",
        name: "Unit: Class magazine",
        subUnits: [
          {
            id: "g12-englis-u15-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u16",
        name: "Revision 4 (Units 10–12)",
        subUnits: [
          {
            id: "g12-englis-u16-s1",
            name: "Civics and Ethical Education (Grade 11)",
          },
          {
            id: "g12-englis-u16-s2",
            name: "Introduction",
          },
          {
            id: "g12-englis-u16-s3",
            name: "Building a Democratic System",
          },
          {
            id: "g12-englis-u16-s4",
            name: "Basic Principles of the Ethiopian Constitution",
          },
          {
            id: "g12-englis-u16-s5",
            name: "Human and Democratic Rights and the Ethiopian Constitution",
          },
          {
            id: "g12-englis-u16-s6",
            name: "Citizens Obligations/ Duties",
          },
          {
            id: "g12-englis-u16-s7",
            name: "Features of a Democratic System",
          },
          {
            id: "g12-englis-u16-s8",
            name: "Federalism",
          },
          {
            id: "g12-englis-u16-s9",
            name: "Ethiopia and International Relations",
          },
          {
            id: "g12-englis-u16-s10",
            name: "Rule of Law",
          },
          {
            id: "g12-englis-u16-s11",
            name: "Rule of Law and Constitution",
          },
          {
            id: "g12-englis-u16-s12",
            name: "The Necessity of the Rule of Law",
          },
          {
            id: "g12-englis-u16-s13",
            name: "Limited and Unlimited Governments",
          },
          {
            id: "g12-englis-u16-s14",
            name: "The Rule of Law and Combating Corruption",
          },
          {
            id: "g12-englis-u16-s15",
            name: "Equality",
          },
          {
            id: "g12-englis-u16-s16",
            name: "The Importance of Equality among the Nations, Nationalities and Peoples of Ethiopia",
          },
          {
            id: "g12-englis-u16-s17",
            name: "The Individual and the Public Interest",
          },
          {
            id: "g12-englis-u16-s18",
            name: "Gender Issues and Socially Discriminated Groups",
          },
          {
            id: "g12-englis-u16-s19",
            name: "The Tendency to Negate Unity in Diversity",
          },
          {
            id: "g12-englis-u16-s20",
            name: "Justice",
          },
          {
            id: "g12-englis-u16-s21",
            name: "Fairness",
          },
          {
            id: "g12-englis-u16-s22",
            name: "Analysis of Equitability",
          },
          {
            id: "g12-englis-u16-s23",
            name: "Components of the Justice System",
          },
          {
            id: "g12-englis-u16-s24",
            name: "The Workings of the Court",
          },
          {
            id: "g12-englis-u16-s25",
            name: "Fairness in Taxation",
          },
          {
            id: "g12-englis-u16-s26",
            name: "Patriotism",
          },
          {
            id: "g12-englis-u16-s27",
            name: "The Bases of Patriotism",
          },
          {
            id: "g12-englis-u16-s28",
            name: "Responsibilities required from a Patriotic Citizen",
          },
          {
            id: "g12-englis-u16-s29",
            name: "Issues of Development",
          },
          {
            id: "g12-englis-u16-s30",
            name: "Voluntarism on a National Basis",
          },
          {
            id: "g12-englis-u16-s31",
            name: "Responsibility",
          },
          {
            id: "g12-englis-u16-s32",
            name: "Citizens' Obligations in Society",
          },
          {
            id: "g12-englis-u16-s33",
            name: "Being responsible for the Consequences of one's own Actions",
          },
          {
            id: "g12-englis-u16-s34",
            name: "Responsibility to respect Moral and Legal Obligations in Society",
          },
          {
            id: "g12-englis-u16-s35",
            name: "Responsibility to Protect the Environment",
          },
          {
            id: "g12-englis-u16-s36",
            name: "Responsibility to Overcome Wastage of Public Property",
          },
          {
            id: "g12-englis-u16-s37",
            name: "Responsible Behaviour against HIV/AIDS",
          },
          {
            id: "g12-englis-u16-s38",
            name: "Industriousness",
          },
          {
            id: "g12-englis-u16-s39",
            name: "Respect for Work",
          },
          {
            id: "g12-englis-u16-s40",
            name: "Ethical Work Conduct",
          },
          {
            id: "g12-englis-u16-s41",
            name: "Hard work and Development",
          },
          {
            id: "g12-englis-u16-s42",
            name: "Policies and Strategies for Development",
          },
          {
            id: "g12-englis-u16-s43",
            name: "Self-Reliance",
          },
          {
            id: "g12-englis-u16-s44",
            name: "Attributes of Self-reliance",
          },
          {
            id: "g12-englis-u16-s45",
            name: "Dependency and its Consequences",
          },
          {
            id: "g12-englis-u16-s46",
            name: "Self reliance and Decision making",
          },
          {
            id: "g12-englis-u16-s47",
            name: "Saving",
          },
          {
            id: "g12-englis-u16-s48",
            name: "The Need for New Thinking in Saving",
          },
          {
            id: "g12-englis-u16-s49",
            name: "Ways of Improving the Habit of Saving",
          },
          {
            id: "g12-englis-u16-s50",
            name: "Traditional and Modern Institutions of Saving in Ethiopia",
          },
          {
            id: "g12-englis-u16-s51",
            name: "Saving as an Instrument of Investment and Development",
          },
          {
            id: "g12-englis-u16-s52",
            name: "Active Community Participation",
          },
          {
            id: "g12-englis-u16-s53",
            name: "Civic Participation",
          },
          {
            id: "g12-englis-u16-s54",
            name: "Monitoring and Influencing Actions of Government Bodies",
          },
          {
            id: "g12-englis-u16-s55",
            name: "The Pursuit of Wisdom",
          },
          {
            id: "g12-englis-u16-s56",
            name: "The Significance of Knowledge",
          },
          {
            id: "g12-englis-u16-s57",
            name: "Knowledge and Data",
          },
          {
            id: "g12-englis-u16-s58",
            name: "Reading for more Knowledge",
          },
          {
            id: "g12-englis-u16-s59",
            name: "Truth versus Myth",
          },
        ],
      },
    ],
  },
  {
    id: "g12-histo-soc",
    name: "History",
    icon: "Landmark",
    grade: "12",
    stream: "Social",
    units: [
      {
        id: "g12-histor-u1",
        name: "Unit: Development of Capitalism and Nationalism from 1815 to 1914",
        subUnits: [
          {
            id: "g12-histor-u1-s1",
            name: "Development of Capitalism",
          },
          {
            id: "g12-histor-u1-s2",
            name: "The Industrial Revolution",
          },
          {
            id: "g12-histor-u1-s3",
            name: "Nationalism",
          },
          {
            id: "g12-histor-u1-s4",
            name: "Unification of Italy",
          },
          {
            id: "g12-histor-u1-s5",
            name: "Unification of Germany",
          },
          {
            id: "g12-histor-u1-s6",
            name: "The American Civil War",
          },
          {
            id: "g12-histor-u1-s7",
            name: "The Eastern Question",
          },
        ],
      },
      {
        id: "g12-histor-u2",
        name: "Unit: Africa and the Colonial Experience (1880s - 1960s)",
        subUnits: [
          {
            id: "g12-histor-u2-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-histor-u3",
        name: "Unit: Society and Politics in the Age of World Wars, 1914 - 1945",
        subUnits: [
          {
            id: "g12-histor-u3-s1",
            name: "World War I and Its Settlement",
          },
          {
            id: "g12-histor-u3-s2",
            name: "The Russian Revolution of 1917",
          },
          {
            id: "g12-histor-u3-s3",
            name: "Interwar Period: Capitalist Economy, Fascism and Nazism",
          },
          {
            id: "g12-histor-u3-s4",
            name: "World War II",
          },
        ],
      },
      {
        id: "g12-histor-u4",
        name: "Unit: Global and Regional Developments Since 1945",
        subUnits: [
          {
            id: "g12-histor-u4-s1",
            name: "The Aftermath and Consequences of WW II",
          },
          {
            id: "g12-histor-u4-s2",
            name: "The United Nations Organization (the UN)",
          },
          {
            id: "g12-histor-u4-s3",
            name: "The Post-War Global Socio-Economic Recovery and Developments",
          },
          {
            id: "g12-histor-u4-s4",
            name: "The Cold War Realities",
          },
        ],
      },
      {
        id: "g12-histor-u5",
        name: "Unit: Africa since the 1960s",
        subUnits: [
          {
            id: "g12-histor-u5-s1",
            name: "The Road to Independence and the Rise of Independent States in Africa",
          },
          {
            id: "g12-histor-u5-s2",
            name: "Politics in Independent African States",
          },
          {
            id: "g12-histor-u5-s3",
            name: "Economy and Society in Independent Africa",
          },
          {
            id: "g12-histor-u5-s4",
            name: "The Cold War and Africa",
          },
          {
            id: "g12-histor-u5-s5",
            name: "Pan-Africanism, from Organization of African Unity to African Union",
          },
        ],
      },
      {
        id: "g12-histor-u6",
        name: "Unit: Post 1991 Developments in Ethiopia",
        subUnits: [
          {
            id: "g12-histor-u6-s1",
            name: "The Transitional Government of Ethiopia",
          },
          {
            id: "g12-histor-u6-s2",
            name: "Ethiopia after the 1995 Constitution",
          },
          {
            id: "g12-histor-u6-s3",
            name: "Socio-Economic Issues",
          },
        ],
      },
    ],
  },
  {
    id: "g12-geogr-soc",
    name: "Geography",
    icon: "Globe",
    grade: "12",
    stream: "Social",
    units: [
      {
        id: "g12-geogra-u1",
        name: "Unit: Basic Research Methodologies In Geography",
        subUnits: [
          {
            id: "g12-geogra-u1-s1",
            name: "Definition and Concept",
          },
          {
            id: "g12-geogra-u1-s2",
            name: "The Significance of Research (qualitative and quantitative)",
          },
          {
            id: "g12-geogra-u1-s3",
            name: "Approaches of Research",
          },
          {
            id: "g12-geogra-u1-s4",
            name: "The Nature of Geographic Research",
          },
          {
            id: "g12-geogra-u1-s5",
            name: "Basic Research Methodology in Geography",
          },
          {
            id: "g12-geogra-u1-s6",
            name: "Conducting Action Research",
          },
        ],
      },
      {
        id: "g12-geogra-u2",
        name: "Unit: Map Use And Map Work",
        subUnits: [
          {
            id: "g12-geogra-u2-s1",
            name: "The Study of Topographic Maps",
          },
          {
            id: "g12-geogra-u2-s2",
            name: "Globe and Map",
          },
          {
            id: "g12-geogra-u2-s3",
            name: "Map Projection",
          },
          {
            id: "g12-geogra-u2-s4",
            name: "Drawing Sketch Map",
          },
        ],
      },
      {
        id: "g12-geogra-u3",
        name: "Unit: Physical Geography Of Ethiopia And The Horn",
        subUnits: [
          {
            id: "g12-geogra-u3-s1",
            name: "Location of the Horn of Africa and Sizes of Member Countries",
          },
          {
            id: "g12-geogra-u3-s2",
            name: "Location, Size and Shape of Ethiopia",
          },
          {
            id: "g12-geogra-u3-s3",
            name: "Geological Structure and Relief of the Horn of Africa",
          },
          {
            id: "g12-geogra-u3-s4",
            name: "Climate of Ethiopia and the Horn",
          },
          {
            id: "g12-geogra-u3-s5",
            name: "Natural Vegetation and Wild Animals of Ethiopia",
          },
          {
            id: "g12-geogra-u3-s6",
            name: "Soils of Ethiopia",
          },
        ],
      },
      {
        id: "g12-geogra-u4",
        name: "Unit: Population Of Ethiopia And The Horn",
        subUnits: [
          {
            id: "g12-geogra-u4-s1",
            name: "Population Theories",
          },
          {
            id: "g12-geogra-u4-s2",
            name: "Trends of Population Growth and Structure in Ethiopia",
          },
          {
            id: "g12-geogra-u4-s3",
            name: "The Spatial Distribution of Population in Ethiopia",
          },
          {
            id: "g12-geogra-u4-s4",
            name: "Factors Affecting Population Distribution in Ethiopia",
          },
          {
            id: "g12-geogra-u4-s5",
            name: "Settlement Patterns of Ethiopian Population",
          },
          {
            id: "g12-geogra-u4-s6",
            name: "Determinants of Population Change in Ethiopia",
          },
          {
            id: "g12-geogra-u4-s7",
            name: "Impacts of Rapid Population Growth in Ethiopia",
          },
          {
            id: "g12-geogra-u4-s8",
            name: "Population Policy of Ethiopia",
          },
          {
            id: "g12-geogra-u4-s9",
            name: "Urbanization in Ethiopia",
          },
        ],
      },
      {
        id: "g12-geogra-u5",
        name: "Unit: Economic Growth And Development Trend In Ethiopia",
        subUnits: [
          {
            id: "g12-geogra-u5-s1",
            name: "An Overview of Growth and Development Trend in Ethiopia",
          },
          {
            id: "g12-geogra-u5-s2",
            name: "Major Features of the Ethiopian Economy",
          },
          {
            id: "g12-geogra-u5-s3",
            name: "Present features of Ethiopian socio-economic development",
          },
          {
            id: "g12-geogra-u5-s4",
            name: "Challenges and Prospects of Socio-economic Development for Ethiopia",
          },
          {
            id: "g12-geogra-u5-s5",
            name: "Economic Relation",
          },
          {
            id: "g12-geogra-u5-s6",
            name: "PASDEP (Plan for Accelerated and Sustained Development to End Poverty)",
          },
        ],
      },
    ],
  },
  {
    id: "g12-econo-soc",
    name: "Economics",
    icon: "TrendingUp",
    grade: "12",
    stream: "Social",
    units: [
      {
        id: "g12-econom-u1",
        name: "Unit: Main Sectors Of Ethiopian Economy",
        subUnits: [
          {
            id: "g12-econom-u1-s1",
            name: "An Overview Of Main Sectors Of Ethiopian Economy",
          },
          {
            id: "g12-econom-u1-s2",
            name: "Resource Base Of Ethiopia",
          },
          {
            id: "g12-econom-u1-s3",
            name: "National Development Objectives And Strategies-a Historical Review",
          },
        ],
      },
      {
        id: "g12-econom-u2",
        name: "Unit: The Agricultural Sector In Ethiopian Economy",
        subUnits: [
          {
            id: "g12-econom-u2-s1",
            name: "Agricultural Versus Industrial Development",
          },
          {
            id: "g12-econom-u2-s2",
            name: "Uni-modal Agricultural Strategy",
          },
          {
            id: "g12-econom-u2-s3",
            name: "Bi-modal Agricultural Strategy",
          },
          {
            id: "g12-econom-u2-s4",
            name: "Roles Of The Agricultural Sector",
          },
          {
            id: "g12-econom-u2-s5",
            name: "Structure Of The Agricultural Sector",
          },
          {
            id: "g12-econom-u2-s6",
            name: "Specific Policies And Strategies Of The Agricultural Sector Since the 1960s",
          },
          {
            id: "g12-econom-u2-s7",
            name: "The Performance Of The Agricultural Sector",
          },
          {
            id: "g12-econom-u2-s8",
            name: "Problems And Possible Remedies Of The Agricultural Sector",
          },
        ],
      },
      {
        id: "g12-econom-u3",
        name: "Unit: The Industrial Sector In Ethiopia",
        subUnits: [
          {
            id: "g12-econom-u3-s1",
            name: "Introduction",
          },
          {
            id: "g12-econom-u3-s2",
            name: "Arguments Of Industrial Sector Vs The Rest Of The Economic Sector",
          },
          {
            id: "g12-econom-u3-s3",
            name: "The Role Of The Industrial Sector In The Ethiopian Economy",
          },
          {
            id: "g12-econom-u3-s4",
            name: "Industrial Development Strategies During The Imperial Period",
          },
          {
            id: "g12-econom-u3-s5",
            name: "Industrial Development Strategies During The Derg Regime",
          },
          {
            id: "g12-econom-u3-s6",
            name: "Industrial Development Strategies During The Post-derg Period",
          },
          {
            id: "g12-econom-u3-s7",
            name: "The Performance Of The Industrial Sector",
          },
          {
            id: "g12-econom-u3-s8",
            name: "Problems And Possible Remedies Of The Industrial Sector",
          },
        ],
      },
      {
        id: "g12-econom-u4",
        name: "Unit: The Service Sector In Ethiopia",
        subUnits: [
          {
            id: "g12-econom-u4-s1",
            name: "Introduction",
          },
          {
            id: "g12-econom-u4-s2",
            name: "Role Of The Service Sector In The Ethiopian Economy",
          },
          {
            id: "g12-econom-u4-s3",
            name: "The Education Sector In Ethiopia",
          },
          {
            id: "g12-econom-u4-s4",
            name: "The Health Sector",
          },
          {
            id: "g12-econom-u4-s5",
            name: "The Transport Sector",
          },
          {
            id: "g12-econom-u4-s6",
            name: "The Communication Sector",
          },
          {
            id: "g12-econom-u4-s7",
            name: "The Tourism Sector",
          },
        ],
      },
      {
        id: "g12-econom-u5",
        name: "Unit: Trade In The Ethiopian Economy",
        subUnits: [
          {
            id: "g12-econom-u5-s1",
            name: "Role And Importance Of Trade In Economic Development",
          },
          {
            id: "g12-econom-u5-s2",
            name: "Trade Policies And Strategies In Ethiopia",
          },
          {
            id: "g12-econom-u5-s3",
            name: "The Structure And Performance Of Trade",
          },
          {
            id: "g12-econom-u5-s4",
            name: "Developments In The Balance Of Payments In Ethiopia",
          },
        ],
      },
      {
        id: "g12-econom-u6",
        name: "Unit: Fiscal Policy And Public Development In Ethiopia",
        subUnits: [
          {
            id: "g12-econom-u6-s1",
            name: "Economic Role Of The Government",
          },
          {
            id: "g12-econom-u6-s2",
            name: "Historical Background Of Public Finance In Ethiopia",
          },
          {
            id: "g12-econom-u6-s3",
            name: "Structure And Performance Of Revenue And Expenditure",
          },
          {
            id: "g12-econom-u6-s4",
            name: "Analysis Of Government Budget And Deficit Financing",
          },
          {
            id: "g12-econom-u6-s5",
            name: "Fiscal Decentralization And Public Sector Reform In Ethiopia",
          },
        ],
      },
      {
        id: "g12-econom-u7",
        name: "Unit: Monetary Policy and Financial Sector in Ethiopia",
        subUnits: [
          {
            id: "g12-econom-u7-s1",
            name: "Historical Background Of Money And The Financial Sector In Ethiopia",
          },
          {
            id: "g12-econom-u7-s2",
            name: "Financial Sector Policies And Reforms In Ethiopia",
          },
          {
            id: "g12-econom-u7-s3",
            name: "Performance Of Financial Sector In Ethiopia",
          },
          {
            id: "g12-econom-u7-s4",
            name: "Problems And Possible Remedies Of The Financial Sector In Ethiopia",
          },
        ],
      },
      {
        id: "g12-econom-u8",
        name: "Unit: The Economic Reform Program In Ethiopia",
        subUnits: [
          {
            id: "g12-econom-u8-s1",
            name: "The New Economic Policy And The Need For Reform",
          },
          {
            id: "g12-econom-u8-s2",
            name: "Performance Of The Economy After The New Economic Reform Program",
          },
          {
            id: "g12-econom-u8-s3",
            name: "Investment Policy And Climate In Ethiopia During The Post-1991 Period",
          },
        ],
      },
    ],
  },
  {
    id: "g12-busin-soc",
    name: "Business",
    icon: "TrendingUp",
    grade: "12",
    stream: "Social",
    units: [
      {
        id: "g12-busine-u1",
        name: "Unit: MARKETING",
        subUnits: [
          {
            id: "g12-busine-u1-s1",
            name: "What is Marketing?",
          },
          {
            id: "g12-busine-u1-s2",
            name: "What is Market?",
          },
          {
            id: "g12-busine-u1-s3",
            name: "Major Marketing Functions",
          },
          {
            id: "g12-busine-u1-s4",
            name: "Marketing Mix- Overview",
          },
        ],
      },
      {
        id: "g12-busine-u2",
        name: "Unit: COMMUNICATION",
        subUnits: [
          {
            id: "g12-busine-u2-s1",
            name: "Definition of Communication and Business Communication",
          },
          {
            id: "g12-busine-u2-s2",
            name: "Methods of Communication",
          },
          {
            id: "g12-busine-u2-s3",
            name: "Effective Formats of Business Messages",
          },
          {
            id: "g12-busine-u2-s4",
            name: "Business Report Writing and Business Reports",
          },
          {
            id: "g12-busine-u2-s5",
            name: "Other Common Reports and their Headings",
          },
          {
            id: "g12-busine-u2-s6",
            name: "Writing Your Curriculum Vitae (CV)",
          },
          {
            id: "g12-busine-u2-s7",
            name: "Preparing for an Interview",
          },
        ],
      },
      {
        id: "g12-busine-u3",
        name: "Unit: TRADE",
        subUnits: [
          {
            id: "g12-busine-u3-s1",
            name: "Definition of Trade",
          },
          {
            id: "g12-busine-u3-s2",
            name: "Foreign Trade",
          },
        ],
      },
      {
        id: "g12-busine-u4",
        name: "Unit: BUSINESS RECORDS KEEPING AND FINANCIAL REPORTS",
        subUnits: [
          {
            id: "g12-busine-u4-s1",
            name: "What is Accounting?",
          },
          {
            id: "g12-busine-u4-s2",
            name: "Importance of Accounting",
          },
          {
            id: "g12-busine-u4-s3",
            name: "The Beginning Balance Sheet",
          },
          {
            id: "g12-busine-u4-s4",
            name: "Recording the Opening Entry",
          },
          {
            id: "g12-busine-u4-s5",
            name: "Posting the Opening Entry",
          },
          {
            id: "g12-busine-u4-s6",
            name: "Business Transaction",
          },
          {
            id: "g12-busine-u4-s7",
            name: "Income and Expense Accounts",
          },
          {
            id: "g12-busine-u4-s8",
            name: "The Six-Column work Sheet",
          },
          {
            id: "g12-busine-u4-s9",
            name: "Financial Statements",
          },
          {
            id: "g12-busine-u4-s10",
            name: "The Petty Cash Fund",
          },
        ],
      },
      {
        id: "g12-busine-u5",
        name: "Glossary",
        subUnits: [
          {
            id: "g12-busine-u5-s1",
            name: "General Overview",
          },
        ],
      },
    ],
  },
  {
    id: "g12-mathe-soc",
    name: "Mathematics",
    icon: "Calculator",
    grade: "12",
    stream: "Social",
    units: [
      {
        id: "g12-mathem-u1",
        name: "Unit: Further on Relation and Functions",
        subUnits: [
          {
            id: "g12-mathem-u1-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-mathem-u2",
        name: "Revision on relations",
        subUnits: [
          {
            id: "g12-mathem-u2-s1",
            name: "Some additional types of functions",
          },
          {
            id: "g12-mathem-u2-s2",
            name: "Classification of functions.",
          },
          {
            id: "g12-mathem-u2-s3",
            name: "Composition of functions",
          },
          {
            id: "g12-mathem-u2-s4",
            name: "Inverse functions and their graphs.",
          },
        ],
      },
      {
        id: "g12-mathem-u3",
        name: "Unit: Rational Expressions and Rational Functions.",
        subUnits: [
          {
            id: "g12-mathem-u3-s1",
            name: "Simplification of rational expressions",
          },
          {
            id: "g12-mathem-u3-s2",
            name: "Rational equations",
          },
          {
            id: "g12-mathem-u3-s3",
            name: "Rational functions and their graphs.",
          },
        ],
      },
      {
        id: "g12-mathem-u4",
        name: "Unit: Coordinate Geometry",
        subUnits: [
          {
            id: "g12-mathem-u4-s1",
            name: "Straight line",
          },
          {
            id: "g12-mathem-u4-s2",
            name: "Conic sections",
          },
        ],
      },
      {
        id: "g12-mathem-u5",
        name: "Unit: Mathematical Reasoning",
        subUnits: [
          {
            id: "g12-mathem-u5-s1",
            name: "Logic",
          },
          {
            id: "g12-mathem-u5-s2",
            name: "Arguments and validity",
          },
        ],
      },
      {
        id: "g12-mathem-u6",
        name: "Unit: Statistics and Probability",
        subUnits: [
          {
            id: "g12-mathem-u6-s1",
            name: "Statistics",
          },
          {
            id: "g12-mathem-u6-s2",
            name: "Probability",
          },
        ],
      },
      {
        id: "g12-mathem-u7",
        name: "Unit: Matrices and Determinants",
        subUnits: [
          {
            id: "g12-mathem-u7-s1",
            name: "Matrices",
          },
          {
            id: "g12-mathem-u7-s2",
            name: "Determinants and their properties",
          },
          {
            id: "g12-mathem-u7-s3",
            name: "Inverse of a square matrix",
          },
          {
            id: "g12-mathem-u7-s4",
            name: "Systems of equations with two or three variables",
          },
          {
            id: "g12-mathem-u7-s5",
            name: "Cramer’s rule",
          },
        ],
      },
      {
        id: "g12-mathem-u8",
        name: "Unit: The Set of Complex Numbers",
        subUnits: [
          {
            id: "g12-mathem-u8-s1",
            name: "The concept of complex numbers",
          },
          {
            id: "g12-mathem-u8-s2",
            name: "Operations on complex numbers",
          },
          {
            id: "g12-mathem-u8-s3",
            name: "Complex conjugate and modulus",
          },
          {
            id: "g12-mathem-u8-s4",
            name: "Simplification of complex numbers",
          },
          {
            id: "g12-mathem-u8-s5",
            name: "Argand diagram and polar representation of",
          },
        ],
      },
      {
        id: "g12-mathem-u9",
        name: "Unit: Mathematical Applications in Business (For Social Science Students)",
        subUnits: [
          {
            id: "g12-mathem-u9-s1",
            name: "Basic mathematical concepts in business.",
          },
          {
            id: "g12-mathem-u9-s2",
            name: "Compound interest and depreciation",
          },
          {
            id: "g12-mathem-u9-s3",
            name: "Saving, investing and borrowing money",
          },
          {
            id: "g12-mathem-u9-s4",
            name: "Taxation",
          },
        ],
      },
      {
        id: "g12-mathem-u1",
        name: "Unit: Sequences and Series",
        subUnits: [
          {
            id: "g12-mathem-u1-s1",
            name: "Sequences",
          },
          {
            id: "g12-mathem-u1-s2",
            name: "Arithmetic sequences and geometric sequences",
          },
          {
            id: "g12-mathem-u1-s3",
            name: "The sigma notation and partial sums",
          },
          {
            id: "g12-mathem-u1-s4",
            name: "Infinities series",
          },
          {
            id: "g12-mathem-u1-s5",
            name: "Applications of arithmetic progressions and geometric progressions",
          },
        ],
      },
      {
        id: "g12-mathem-u2",
        name: "Unit: Introduction to Limits and Continuity",
        subUnits: [
          {
            id: "g12-mathem-u2-s1",
            name: "Limits of sequences of numbers",
          },
          {
            id: "g12-mathem-u2-s2",
            name: "Limits of functions",
          },
          {
            id: "g12-mathem-u2-s3",
            name: "Continuity of a function",
          },
          {
            id: "g12-mathem-u2-s4",
            name: "Exercises on applications of limits",
          },
        ],
      },
      {
        id: "g12-mathem-u3",
        name: "Unit: Introduction to Differential Calculus",
        subUnits: [
          {
            id: "g12-mathem-u3-s1",
            name: "Introduction to Derivatives",
          },
          {
            id: "g12-mathem-u3-s2",
            name: "Derivatives of some functions",
          },
          {
            id: "g12-mathem-u3-s3",
            name: "Derivatives of combinations and compositions of functions",
          },
        ],
      },
      {
        id: "g12-mathem-u4",
        name: "Unit: Applications of Differential Calculus",
        subUnits: [
          {
            id: "g12-mathem-u4-s1",
            name: "Extreme values of functions",
          },
          {
            id: "g12-mathem-u4-s2",
            name: "Minimization and maximization problems",
          },
          {
            id: "g12-mathem-u4-s3",
            name: "Rate of change",
          },
        ],
      },
      {
        id: "g12-mathem-u5",
        name: "Unit: Introduction to Integral Calculus",
        subUnits: [
          {
            id: "g12-mathem-u5-s1",
            name: "Integration as reverse process of differentiation",
          },
          {
            id: "g12-mathem-u5-s2",
            name: "Techniques of integration",
          },
          {
            id: "g12-mathem-u5-s3",
            name: "Definite integrals, area and fundamental theorem of calculus",
          },
          {
            id: "g12-mathem-u5-s4",
            name: "Applications of Integral calculus",
          },
        ],
      },
      {
        id: "g12-mathem-u6",
        name: "Unit: Further on Statistics (For Social Science Students)",
        subUnits: [
          {
            id: "g12-mathem-u6-s1",
            name: "Sampling techniques",
          },
          {
            id: "g12-mathem-u6-s2",
            name: "Representation of data",
          },
          {
            id: "g12-mathem-u6-s3",
            name: "Construction and interpretation of graphs",
          },
          {
            id: "g12-mathem-u6-s4",
            name: "Measures of central tendency and measures of variability",
          },
          {
            id: "g12-mathem-u6-s5",
            name: "Analysis of frequency distributions",
          },
          {
            id: "g12-mathem-u6-s6",
            name: "Use of cumulative frequency curves",
          },
        ],
      },
      {
        id: "g12-mathem-u7",
        name: "Unit: Mathematical Applications for Business and consumers (For Social Science Students)",
        subUnits: [
          {
            id: "g12-mathem-u7-s1",
            name: "Applications to purchasing",
          },
          {
            id: "g12-mathem-u7-s2",
            name: "Percent increase and percent decrease",
          },
          {
            id: "g12-mathem-u7-s3",
            name: "Real estate expenses",
          },
          {
            id: "g12-mathem-u7-s4",
            name: "Wages",
          },
          {
            id: "g12-mathem-u7-s5",
            name: "Information Technology / ICT (Syllabus Set A - Outcomes)",
          },
        ],
      },
      {
        id: "g12-mathem-u8",
        name: "Unit: Information Systems",
        subUnits: [
          {
            id: "g12-mathem-u8-s1",
            name: "Know the application of ICT in different sectors;",
          },
          {
            id: "g12-mathem-u8-s2",
            name: "Understand the components of an Information System;",
          },
          {
            id: "g12-mathem-u8-s3",
            name: "Recognise the application of ICT in different sectors;",
          },
          {
            id: "g12-mathem-u8-s4",
            name: "Recognise how ICT can change the life of people.",
          },
        ],
      },
      {
        id: "g12-mathem-u9",
        name: "Unit: Enhancing the Use of Software",
        subUnits: [
          {
            id: "g12-mathem-u9-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-mathem-u10",
        name: "Unit: Basic Troubleshooting",
        subUnits: [
          {
            id: "g12-mathem-u10-s1",
            name: "Recognise basic idea in preventive maintenance",
          },
          {
            id: "g12-mathem-u10-s2",
            name: "Apply the knowledge gained in preventive maintenance to prolong the life of the computer",
          },
          {
            id: "g12-mathem-u10-s3",
            name: "Be aware of basic safety issues",
          },
          {
            id: "g12-mathem-u10-s4",
            name: "Recognise major hardware components inside the computer",
          },
          {
            id: "g12-mathem-u10-s5",
            name: "Acquire knowledge on how to format hard disc and install software",
          },
        ],
      },
      {
        id: "g12-mathem-u11",
        name: "Unit: Exploiting the Internet",
        subUnits: [
          {
            id: "g12-mathem-u11-s1",
            name: "Develop an awareness of web developments in making information available in different formats.",
          },
        ],
      },
      {
        id: "g12-mathem-u12",
        name: "Unit: Image Processing and Multimedia Systems",
        subUnits: [
          {
            id: "g12-mathem-u12-s1",
            name: "Understand the concept of image processing.",
          },
          {
            id: "g12-mathem-u12-s2",
            name: "Differentiate image file format.",
          },
          {
            id: "g12-mathem-u12-s3",
            name: "Recognize the function of image processing software.",
          },
          {
            id: "g12-mathem-u12-s4",
            name: "Recognize Interface layout of Image processing software",
          },
          {
            id: "g12-mathem-u12-s5",
            name: "Edit images properly using image processing software.",
          },
          {
            id: "g12-mathem-u12-s6",
            name: "Information Technology / ICT (Syllabus Set B - Contents)",
          },
        ],
      },
      {
        id: "g12-mathem-u13",
        name: "Unit: Information Systems",
        subUnits: [
          {
            id: "g12-mathem-u13-s1",
            name: "Basics of E-learning.",
          },
          {
            id: "g12-mathem-u13-s2",
            name: "Basics of E-Government",
          },
          {
            id: "g12-mathem-u13-s3",
            name: "Basics of E-Banking",
          },
          {
            id: "g12-mathem-u13-s4",
            name: "Basics of E-Libraries",
          },
          {
            id: "g12-mathem-u13-s5",
            name: "Basics of E-Commerce",
          },
          {
            id: "g12-mathem-u13-s6",
            name: "System Analysis.",
          },
        ],
      },
      {
        id: "g12-mathem-u14",
        name: "Unit: Enhancing the Use Of Software",
        subUnits: [
          {
            id: "g12-mathem-u14-s1",
            name: "Using Application Software",
          },
        ],
      },
      {
        id: "g12-mathem-u15",
        name: "Unit: Exploiting the Internet",
        subUnits: [
          {
            id: "g12-mathem-u15-s1",
            name: "General Concept of Website Design",
          },
          {
            id: "g12-mathem-u15-s2",
            name: "Planning a Website.",
          },
          {
            id: "g12-mathem-u15-s3",
            name: "Website Design Considerations",
          },
          {
            id: "g12-mathem-u15-s4",
            name: "Website Development",
          },
        ],
      },
      {
        id: "g12-mathem-u16",
        name: "Unit: Image Processing and Multimedia Systems",
        subUnits: [
          {
            id: "g12-mathem-u16-s1",
            name: "Basics Of Multimedia Multimedia",
          },
          {
            id: "g12-mathem-u16-s2",
            name: "Introduction to Multimedia Authoring Tools",
          },
          {
            id: "g12-mathem-u16-s3",
            name: "Inserting and Editing Text",
          },
          {
            id: "g12-mathem-u16-s4",
            name: "Working with Images and Graphics",
          },
          {
            id: "g12-mathem-u16-s5",
            name: "Page Transitions, Positioning and Motion Icon",
          },
          {
            id: "g12-mathem-u16-s6",
            name: "Libraries",
          },
          {
            id: "g12-mathem-u16-s7",
            name: "Working with Sound and Digital Movies",
          },
          {
            id: "g12-mathem-u16-s8",
            name: "Overview of Film Editing",
          },
        ],
      },
      {
        id: "g12-mathem-u17",
        name: "Glossary",
        subUnits: [
          {
            id: "g12-mathem-u17-s1",
            name: "General Overview",
          },
        ],
      },
    ],
  },
  {
    id: "g12-engli",
    name: "English",
    icon: "BookA",
    grade: "12",
    stream: "Natural",
    units: [
      {
        id: "g12-englis-u1",
        name: "Unit: Family life",
        subUnits: [
          {
            id: "g12-englis-u1-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u2",
        name: "Unit: Communication",
        subUnits: [
          {
            id: "g12-englis-u2-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u3",
        name: "Unit: Education",
        subUnits: [
          {
            id: "g12-englis-u3-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u4",
        name: "Revision 1 (Units 1–3)",
        subUnits: [
          {
            id: "g12-englis-u4-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u5",
        name: "Unit: The arts and literature",
        subUnits: [
          {
            id: "g12-englis-u5-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u6",
        name: "Unit: The United Nations",
        subUnits: [
          {
            id: "g12-englis-u6-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u7",
        name: "Unit: Trade and globalisation",
        subUnits: [
          {
            id: "g12-englis-u7-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u8",
        name: "Revision 2 (Units 4–6)",
        subUnits: [
          {
            id: "g12-englis-u8-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u9",
        name: "Unit: Finding a job",
        subUnits: [
          {
            id: "g12-englis-u9-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u10",
        name: "Unit: Human development",
        subUnits: [
          {
            id: "g12-englis-u10-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u11",
        name: "Unit: Tradition versus progress",
        subUnits: [
          {
            id: "g12-englis-u11-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u12",
        name: "Revision 3 (Units 7–9)",
        subUnits: [
          {
            id: "g12-englis-u12-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u13",
        name: "Unit: Future threats",
        subUnits: [
          {
            id: "g12-englis-u13-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u14",
        name: "Unit: The film industry",
        subUnits: [
          {
            id: "g12-englis-u14-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u15",
        name: "Unit: Class magazine",
        subUnits: [
          {
            id: "g12-englis-u15-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-englis-u16",
        name: "Revision 4 (Units 10–12)",
        subUnits: [
          {
            id: "g12-englis-u16-s1",
            name: "Civics and Ethical Education (Grade 11)",
          },
          {
            id: "g12-englis-u16-s2",
            name: "Introduction",
          },
          {
            id: "g12-englis-u16-s3",
            name: "Building a Democratic System",
          },
          {
            id: "g12-englis-u16-s4",
            name: "Basic Principles of the Ethiopian Constitution",
          },
          {
            id: "g12-englis-u16-s5",
            name: "Human and Democratic Rights and the Ethiopian Constitution",
          },
          {
            id: "g12-englis-u16-s6",
            name: "Citizens Obligations/ Duties",
          },
          {
            id: "g12-englis-u16-s7",
            name: "Features of a Democratic System",
          },
          {
            id: "g12-englis-u16-s8",
            name: "Federalism",
          },
          {
            id: "g12-englis-u16-s9",
            name: "Ethiopia and International Relations",
          },
          {
            id: "g12-englis-u16-s10",
            name: "Rule of Law",
          },
          {
            id: "g12-englis-u16-s11",
            name: "Rule of Law and Constitution",
          },
          {
            id: "g12-englis-u16-s12",
            name: "The Necessity of the Rule of Law",
          },
          {
            id: "g12-englis-u16-s13",
            name: "Limited and Unlimited Governments",
          },
          {
            id: "g12-englis-u16-s14",
            name: "The Rule of Law and Combating Corruption",
          },
          {
            id: "g12-englis-u16-s15",
            name: "Equality",
          },
          {
            id: "g12-englis-u16-s16",
            name: "The Importance of Equality among the Nations, Nationalities and Peoples of Ethiopia",
          },
          {
            id: "g12-englis-u16-s17",
            name: "The Individual and the Public Interest",
          },
          {
            id: "g12-englis-u16-s18",
            name: "Gender Issues and Socially Discriminated Groups",
          },
          {
            id: "g12-englis-u16-s19",
            name: "The Tendency to Negate Unity in Diversity",
          },
          {
            id: "g12-englis-u16-s20",
            name: "Justice",
          },
          {
            id: "g12-englis-u16-s21",
            name: "Fairness",
          },
          {
            id: "g12-englis-u16-s22",
            name: "Analysis of Equitability",
          },
          {
            id: "g12-englis-u16-s23",
            name: "Components of the Justice System",
          },
          {
            id: "g12-englis-u16-s24",
            name: "The Workings of the Court",
          },
          {
            id: "g12-englis-u16-s25",
            name: "Fairness in Taxation",
          },
          {
            id: "g12-englis-u16-s26",
            name: "Patriotism",
          },
          {
            id: "g12-englis-u16-s27",
            name: "The Bases of Patriotism",
          },
          {
            id: "g12-englis-u16-s28",
            name: "Responsibilities required from a Patriotic Citizen",
          },
          {
            id: "g12-englis-u16-s29",
            name: "Issues of Development",
          },
          {
            id: "g12-englis-u16-s30",
            name: "Voluntarism on a National Basis",
          },
          {
            id: "g12-englis-u16-s31",
            name: "Responsibility",
          },
          {
            id: "g12-englis-u16-s32",
            name: "Citizens' Obligations in Society",
          },
          {
            id: "g12-englis-u16-s33",
            name: "Being responsible for the Consequences of one's own Actions",
          },
          {
            id: "g12-englis-u16-s34",
            name: "Responsibility to respect Moral and Legal Obligations in Society",
          },
          {
            id: "g12-englis-u16-s35",
            name: "Responsibility to Protect the Environment",
          },
          {
            id: "g12-englis-u16-s36",
            name: "Responsibility to Overcome Wastage of Public Property",
          },
          {
            id: "g12-englis-u16-s37",
            name: "Responsible Behaviour against HIV/AIDS",
          },
          {
            id: "g12-englis-u16-s38",
            name: "Industriousness",
          },
          {
            id: "g12-englis-u16-s39",
            name: "Respect for Work",
          },
          {
            id: "g12-englis-u16-s40",
            name: "Ethical Work Conduct",
          },
          {
            id: "g12-englis-u16-s41",
            name: "Hard work and Development",
          },
          {
            id: "g12-englis-u16-s42",
            name: "Policies and Strategies for Development",
          },
          {
            id: "g12-englis-u16-s43",
            name: "Self-Reliance",
          },
          {
            id: "g12-englis-u16-s44",
            name: "Attributes of Self-reliance",
          },
          {
            id: "g12-englis-u16-s45",
            name: "Dependency and its Consequences",
          },
          {
            id: "g12-englis-u16-s46",
            name: "Self reliance and Decision making",
          },
          {
            id: "g12-englis-u16-s47",
            name: "Saving",
          },
          {
            id: "g12-englis-u16-s48",
            name: "The Need for New Thinking in Saving",
          },
          {
            id: "g12-englis-u16-s49",
            name: "Ways of Improving the Habit of Saving",
          },
          {
            id: "g12-englis-u16-s50",
            name: "Traditional and Modern Institutions of Saving in Ethiopia",
          },
          {
            id: "g12-englis-u16-s51",
            name: "Saving as an Instrument of Investment and Development",
          },
          {
            id: "g12-englis-u16-s52",
            name: "Active Community Participation",
          },
          {
            id: "g12-englis-u16-s53",
            name: "Civic Participation",
          },
          {
            id: "g12-englis-u16-s54",
            name: "Monitoring and Influencing Actions of Government Bodies",
          },
          {
            id: "g12-englis-u16-s55",
            name: "The Pursuit of Wisdom",
          },
          {
            id: "g12-englis-u16-s56",
            name: "The Significance of Knowledge",
          },
          {
            id: "g12-englis-u16-s57",
            name: "Knowledge and Data",
          },
          {
            id: "g12-englis-u16-s58",
            name: "Reading for more Knowledge",
          },
          {
            id: "g12-englis-u16-s59",
            name: "Truth versus Myth",
          },
        ],
      },
    ],
  },
  {
    id: "g12-biolo",
    name: "Biology",
    icon: "Dna",
    grade: "12",
    stream: "Natural",
    units: [
      {
        id: "g12-biolog-u1",
        name: "Unit: Micro-organisms",
        subUnits: [
          {
            id: "g12-biolog-u1-s1",
            name: "Bacteria",
          },
          {
            id: "g12-biolog-u1-s2",
            name: "Ecology and uses of bacteria",
          },
          {
            id: "g12-biolog-u1-s3",
            name: "Viruses",
          },
        ],
      },
      {
        id: "g12-biolog-u2",
        name: "Unit: Ecology",
        subUnits: [
          {
            id: "g12-biolog-u2-s1",
            name: "Cycling of matter through ecosystems",
          },
          {
            id: "g12-biolog-u2-s2",
            name: "Ecological succession",
          },
          {
            id: "g12-biolog-u2-s3",
            name: "Biomes",
          },
          {
            id: "g12-biolog-u2-s4",
            name: "Biodiversity",
          },
          {
            id: "g12-biolog-u2-s5",
            name: "Population structure and dynamics",
          },
        ],
      },
      {
        id: "g12-biolog-u3",
        name: "Unit: Genetics",
        subUnits: [
          {
            id: "g12-biolog-u3-s1",
            name: "Crossing principles",
          },
          {
            id: "g12-biolog-u3-s2",
            name: "Molecular genetics",
          },
          {
            id: "g12-biolog-u3-s3",
            name: "Protein synthesis",
          },
          {
            id: "g12-biolog-u3-s4",
            name: "Mutations",
          },
        ],
      },
      {
        id: "g12-biolog-u4",
        name: "Unit: Evolution",
        subUnits: [
          {
            id: "g12-biolog-u4-s1",
            name: "The origin of life",
          },
          {
            id: "g12-biolog-u4-s2",
            name: "Theories of evolution",
          },
          {
            id: "g12-biolog-u4-s3",
            name: "Evidences of evolution",
          },
          {
            id: "g12-biolog-u4-s4",
            name: "The process of evolution",
          },
          {
            id: "g12-biolog-u4-s5",
            name: "The evolution of humans",
          },
        ],
      },
      {
        id: "g12-biolog-u5",
        name: "Unit: Behaviour",
        subUnits: [
          {
            id: "g12-biolog-u5-s1",
            name: "Introduction",
          },
          {
            id: "g12-biolog-u5-s2",
            name: "Innate behaviour",
          },
          {
            id: "g12-biolog-u5-s3",
            name: "Learned behaviour",
          },
          {
            id: "g12-biolog-u5-s4",
            name: "Patterns of behaviour",
          },
        ],
      },
    ],
  },
  {
    id: "g12-chemi",
    name: "Chemistry",
    icon: "FlaskConical",
    grade: "12",
    stream: "Natural",
    units: [
      {
        id: "g12-chemis-u1",
        name: "Unit: Solutions",
        subUnits: [
          {
            id: "g12-chemis-u1-s1",
            name: "Homogeneous and Heterogeneous Mixtures",
          },
          {
            id: "g12-chemis-u1-s2",
            name: "Types of Solutions",
          },
          {
            id: "g12-chemis-u1-s3",
            name: "The Solution Process",
          },
          {
            id: "g12-chemis-u1-s4",
            name: "Solubility as an Equilibrium Process",
          },
          {
            id: "g12-chemis-u1-s5",
            name: "Ways of Expressing Concentrations of Solutions",
          },
          {
            id: "g12-chemis-u1-s6",
            name: "Preparation of Solutions",
          },
          {
            id: "g12-chemis-u1-s7",
            name: "Solution Stoichiometry",
          },
          {
            id: "g12-chemis-u1-s8",
            name: "Describing Reactions in Solution",
          },
          {
            id: "g12-chemis-u1-s9",
            name: "Colligative Properties of Solutions",
          },
        ],
      },
      {
        id: "g12-chemis-u2",
        name: "Unit: Acid-Base Equilibrium",
        subUnits: [
          {
            id: "g12-chemis-u2-s1",
            name: "Acid-Base Concepts",
          },
          {
            id: "g12-chemis-u2-s2",
            name: "Ionic Equilibria of Weak Acids and Bases",
          },
          {
            id: "g12-chemis-u2-s3",
            name: "Common Ion Effect and Buffer Solutions",
          },
          {
            id: "g12-chemis-u2-s4",
            name: "Hydrolysis of Salts",
          },
          {
            id: "g12-chemis-u2-s5",
            name: "Acid-Base Indicators",
          },
        ],
      },
      {
        id: "g12-chemis-u3",
        name: "Unit: Introduction to Chemical Thermodynamics",
        subUnits: [
          {
            id: "g12-chemis-u3-s1",
            name: "Common Thermodynamic Terms",
          },
          {
            id: "g12-chemis-u3-s2",
            name: "First Law of Thermodynamics and some Thermodynamic quantities",
          },
          {
            id: "g12-chemis-u3-s3",
            name: "Thermochemistry",
          },
          {
            id: "g12-chemis-u3-s4",
            name: "Entropy and Second Law of Thermodynamics",
          },
        ],
      },
      {
        id: "g12-chemis-u4",
        name: "Unit: Electrochemistry",
        subUnits: [
          {
            id: "g12-chemis-u4-s1",
            name: "Oxidation-Reduction Reaction",
          },
          {
            id: "g12-chemis-u4-s2",
            name: "Electrolysis of Aqueous Solutions",
          },
          {
            id: "g12-chemis-u4-s3",
            name: "Quantitative Aspects of Electrolysis",
          },
          {
            id: "g12-chemis-u4-s4",
            name: "Industrial Application of Electrolysis",
          },
          {
            id: "g12-chemis-u4-s5",
            name: "Galvanic (Voltaic) Cells",
          },
        ],
      },
      {
        id: "g12-chemis-u5",
        name: "Unit: Some Elements in Nature and Industry",
        subUnits: [
          {
            id: "g12-chemis-u5-s1",
            name: "Some Elements in Nature",
          },
          {
            id: "g12-chemis-u5-s2",
            name: "Some Elements in Industry",
          },
        ],
      },
      {
        id: "g12-chemis-u6",
        name: "Unit: Polymers",
        subUnits: [
          {
            id: "g12-chemis-u6-s1",
            name: "Introduction to Polymers",
          },
          {
            id: "g12-chemis-u6-s2",
            name: "Polymerization",
          },
          {
            id: "g12-chemis-u6-s3",
            name: "Synthetic Polymers",
          },
          {
            id: "g12-chemis-u6-s4",
            name: "Natural Polymers",
          },
        ],
      },
    ],
  },
  {
    id: "g12-physi",
    name: "Physics",
    icon: "Zap",
    grade: "12",
    stream: "Natural",
    units: [
      {
        id: "g12-physic-u1",
        name: "Unit: Thermodynamics",
        subUnits: [
          {
            id: "g12-physic-u1-s1",
            name: "Thermal equilibrium and definition of temperature",
          },
          {
            id: "g12-physic-u1-s2",
            name: "Work, heat and the first law of thermodynamics",
          },
          {
            id: "g12-physic-u1-s3",
            name: "Kinetic theory of gases",
          },
          {
            id: "g12-physic-u1-s4",
            name: "Second law of thermodynamics, efficiency, and entropy",
          },
          {
            id: "g12-physic-u1-s5",
            name: "Heat engines and refrigerators",
          },
        ],
      },
      {
        id: "g12-physic-u2",
        name: "Unit: Oscillations and waves",
        subUnits: [
          {
            id: "g12-physic-u2-s1",
            name: "Periodic motion (basic concepts)",
          },
          {
            id: "g12-physic-u2-s2",
            name: "Wave motion",
          },
          {
            id: "g12-physic-u2-s3",
            name: "Sound, loudness and the human ear",
          },
        ],
      },
      {
        id: "g12-physic-u3",
        name: "Unit: Wave optics",
        subUnits: [
          {
            id: "g12-physic-u3-s1",
            name: "Wavefronts and Huygens’s principle",
          },
          {
            id: "g12-physic-u3-s2",
            name: "Reflection and refraction of plane wavefronts",
          },
          {
            id: "g12-physic-u3-s3",
            name: "Proof of the laws of reflection and refraction using Huygens’s principle",
          },
          {
            id: "g12-physic-u3-s4",
            name: "Interference",
          },
          {
            id: "g12-physic-u3-s5",
            name: "Young’s double-slit experiment and expression for fringe width",
          },
          {
            id: "g12-physic-u3-s6",
            name: "Coherent sources and sustained interference of light",
          },
          {
            id: "g12-physic-u3-s7",
            name: "Diffraction due to a single slit and a diffraction grating",
          },
        ],
      },
      {
        id: "g12-physic-u4",
        name: "Unit: Electrostatics",
        subUnits: [
          {
            id: "g12-physic-u4-s1",
            name: "Electric charge and Coulomb’s law",
          },
          {
            id: "g12-physic-u4-s2",
            name: "Electric potential",
          },
          {
            id: "g12-physic-u4-s3",
            name: "Capacitors and dielectrics",
          },
        ],
      },
      {
        id: "g12-physic-u5",
        name: "Unit: Steady electric current and circuit properties",
        subUnits: [
          {
            id: "g12-physic-u5-s1",
            name: "Basic principles",
          },
          {
            id: "g12-physic-u5-s2",
            name: "Kirchoff’s rules",
          },
          {
            id: "g12-physic-u5-s3",
            name: "Measuring instruments",
          },
          {
            id: "g12-physic-u5-s4",
            name: "The Wheatstone bridge and the potentiometer",
          },
        ],
      },
      {
        id: "g12-physic-u6",
        name: "Unit: Magnetism",
        subUnits: [
          {
            id: "g12-physic-u6-s1",
            name: "Concepts of a magnetic field",
          },
          {
            id: "g12-physic-u6-s2",
            name: "The Earth and magnetic fields",
          },
          {
            id: "g12-physic-u6-s3",
            name: "Motion of charged particles in a magnetic field",
          },
          {
            id: "g12-physic-u6-s4",
            name: "Magnetic force on current-carrying conductors (long, straight, circular loop)",
          },
          {
            id: "g12-physic-u6-s5",
            name: "Ampere’s law and its application",
          },
          {
            id: "g12-physic-u6-s6",
            name: "Earth’s magnetism",
          },
        ],
      },
      {
        id: "g12-physic-u7",
        name: "Unit: Electromagnetic induction and a.c. circuits",
        subUnits: [
          {
            id: "g12-physic-u7-s1",
            name: "Phenomena of electromagnetic induction",
          },
          {
            id: "g12-physic-u7-s2",
            name: "Alternating current (a.c.) generator and transformers",
          },
          {
            id: "g12-physic-u7-s3",
            name: "Alternating current (a.c.)",
          },
          {
            id: "g12-physic-u7-s4",
            name: "Power in a.c. circuits",
          },
        ],
      },
    ],
  },
  {
    id: "g12-techn",
    name: "Technical Drawing",
    icon: "PenTool",
    grade: "12",
    stream: "Natural",
    units: [
      {
        id: "g12-techni-u1",
        name: "Unit: Free-hand Sketching",
        subUnits: [
          {
            id: "g12-techni-u1-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-techni-u2",
        name: "Unit: Auxiliary view",
        subUnits: [
          {
            id: "g12-techni-u2-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-techni-u3",
        name: "Unit: Sectional view",
        subUnits: [
          {
            id: "g12-techni-u3-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-techni-u4",
        name: "Unit: Dimensioning",
        subUnits: [
          {
            id: "g12-techni-u4-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-techni-u5",
        name: "Unit: Development and Intersection",
        subUnits: [
          {
            id: "g12-techni-u5-s1",
            name: "General Overview",
          },
        ],
      },
    ],
  },
  {
    id: "g12-mathe",
    name: "Mathematics",
    icon: "Calculator",
    grade: "12",
    stream: "Natural",
    units: [
      {
        id: "g12-mathem-u1",
        name: "Unit: Further on Relation and Functions",
        subUnits: [
          {
            id: "g12-mathem-u1-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-mathem-u2",
        name: "Revision on relations",
        subUnits: [
          {
            id: "g12-mathem-u2-s1",
            name: "Some additional types of functions",
          },
          {
            id: "g12-mathem-u2-s2",
            name: "Classification of functions.",
          },
          {
            id: "g12-mathem-u2-s3",
            name: "Composition of functions",
          },
          {
            id: "g12-mathem-u2-s4",
            name: "Inverse functions and their graphs.",
          },
        ],
      },
      {
        id: "g12-mathem-u3",
        name: "Unit: Rational Expressions and Rational Functions.",
        subUnits: [
          {
            id: "g12-mathem-u3-s1",
            name: "Simplification of rational expressions",
          },
          {
            id: "g12-mathem-u3-s2",
            name: "Rational equations",
          },
          {
            id: "g12-mathem-u3-s3",
            name: "Rational functions and their graphs.",
          },
        ],
      },
      {
        id: "g12-mathem-u4",
        name: "Unit: Coordinate Geometry",
        subUnits: [
          {
            id: "g12-mathem-u4-s1",
            name: "Straight line",
          },
          {
            id: "g12-mathem-u4-s2",
            name: "Conic sections",
          },
        ],
      },
      {
        id: "g12-mathem-u5",
        name: "Unit: Mathematical Reasoning",
        subUnits: [
          {
            id: "g12-mathem-u5-s1",
            name: "Logic",
          },
          {
            id: "g12-mathem-u5-s2",
            name: "Arguments and validity",
          },
        ],
      },
      {
        id: "g12-mathem-u6",
        name: "Unit: Statistics and Probability",
        subUnits: [
          {
            id: "g12-mathem-u6-s1",
            name: "Statistics",
          },
          {
            id: "g12-mathem-u6-s2",
            name: "Probability",
          },
        ],
      },
      {
        id: "g12-mathem-u7",
        name: "Unit: Matrices and Determinants",
        subUnits: [
          {
            id: "g12-mathem-u7-s1",
            name: "Matrices",
          },
          {
            id: "g12-mathem-u7-s2",
            name: "Determinants and their properties",
          },
          {
            id: "g12-mathem-u7-s3",
            name: "Inverse of a square matrix",
          },
          {
            id: "g12-mathem-u7-s4",
            name: "Systems of equations with two or three variables",
          },
          {
            id: "g12-mathem-u7-s5",
            name: "Cramer’s rule",
          },
        ],
      },
      {
        id: "g12-mathem-u8",
        name: "Unit: The Set of Complex Numbers",
        subUnits: [
          {
            id: "g12-mathem-u8-s1",
            name: "The concept of complex numbers",
          },
          {
            id: "g12-mathem-u8-s2",
            name: "Operations on complex numbers",
          },
          {
            id: "g12-mathem-u8-s3",
            name: "Complex conjugate and modulus",
          },
          {
            id: "g12-mathem-u8-s4",
            name: "Simplification of complex numbers",
          },
          {
            id: "g12-mathem-u8-s5",
            name: "Argand diagram and polar representation of",
          },
        ],
      },
      {
        id: "g12-mathem-u9",
        name: "Unit: Vectors and Transformation of the Plane (For Natural Science Students)",
        subUnits: [
          {
            id: "g12-mathem-u9-s1",
            name: "Representation of vectors.",
          },
          {
            id: "g12-mathem-u9-s2",
            name: "Scalar (inner or dot) product of vectors",
          },
          {
            id: "g12-mathem-u9-s3",
            name: "Application of vector",
          },
          {
            id: "g12-mathem-u9-s4",
            name: "Transformation of the plane",
          },
        ],
      },
      {
        id: "g12-mathem-u10",
        name: "Unit: Further on Trigonometric Functions (For Natural Science Students)",
        subUnits: [
          {
            id: "g12-mathem-u10-s1",
            name: "The functions y -sec x, y z csc x and y z cot x",
          },
          {
            id: "g12-mathem-u10-s2",
            name: "Inverse of trigonometric functions",
          },
          {
            id: "g12-mathem-u10-s3",
            name: "Graphs of some trigonometric functions",
          },
          {
            id: "g12-mathem-u10-s4",
            name: "Applications of trigonometric functions",
          },
        ],
      },
      {
        id: "g12-mathem-u1",
        name: "Unit: Sequences and Series",
        subUnits: [
          {
            id: "g12-mathem-u1-s1",
            name: "Sequences",
          },
          {
            id: "g12-mathem-u1-s2",
            name: "Arithmetic sequences and geometric sequences",
          },
          {
            id: "g12-mathem-u1-s3",
            name: "The sigma notation and partial sums",
          },
          {
            id: "g12-mathem-u1-s4",
            name: "Infinities series",
          },
          {
            id: "g12-mathem-u1-s5",
            name: "Applications of arithmetic progressions and geometric progressions",
          },
        ],
      },
      {
        id: "g12-mathem-u2",
        name: "Unit: Introduction to Limits and Continuity",
        subUnits: [
          {
            id: "g12-mathem-u2-s1",
            name: "Limits of sequences of numbers",
          },
          {
            id: "g12-mathem-u2-s2",
            name: "Limits of functions",
          },
          {
            id: "g12-mathem-u2-s3",
            name: "Continuity of a function",
          },
          {
            id: "g12-mathem-u2-s4",
            name: "Exercises on applications of limits",
          },
        ],
      },
      {
        id: "g12-mathem-u3",
        name: "Unit: Introduction to Differential Calculus",
        subUnits: [
          {
            id: "g12-mathem-u3-s1",
            name: "Introduction to Derivatives",
          },
          {
            id: "g12-mathem-u3-s2",
            name: "Derivatives of some functions",
          },
          {
            id: "g12-mathem-u3-s3",
            name: "Derivatives of combinations and compositions of functions",
          },
        ],
      },
      {
        id: "g12-mathem-u4",
        name: "Unit: Applications of Differential Calculus",
        subUnits: [
          {
            id: "g12-mathem-u4-s1",
            name: "Extreme values of functions",
          },
          {
            id: "g12-mathem-u4-s2",
            name: "Minimization and maximization problems",
          },
          {
            id: "g12-mathem-u4-s3",
            name: "Rate of change",
          },
        ],
      },
      {
        id: "g12-mathem-u5",
        name: "Unit: Introduction to Integral Calculus",
        subUnits: [
          {
            id: "g12-mathem-u5-s1",
            name: "Integration as reverse process of differentiation",
          },
          {
            id: "g12-mathem-u5-s2",
            name: "Techniques of integration",
          },
          {
            id: "g12-mathem-u5-s3",
            name: "Definite integrals, area and fundamental theorem of calculus",
          },
          {
            id: "g12-mathem-u5-s4",
            name: "Applications of Integral calculus",
          },
        ],
      },
      {
        id: "g12-mathem-u6",
        name: "Unit: Three Dimensional Geometry and Vectors in Space (For Natural Science Students)",
        subUnits: [
          {
            id: "g12-mathem-u6-s1",
            name: "Coordinate axes and coordinate planes in space",
          },
          {
            id: "g12-mathem-u6-s2",
            name: "Coordinates of a point in space",
          },
          {
            id: "g12-mathem-u6-s3",
            name: "Distance between two points in space",
          },
          {
            id: "g12-mathem-u6-s4",
            name: "Mid-point of a line segment in space",
          },
          {
            id: "g12-mathem-u6-s5",
            name: "Equation of sphere",
          },
          {
            id: "g12-mathem-u6-s6",
            name: "Vectors in space",
          },
        ],
      },
      {
        id: "g12-mathem-u7",
        name: "Unit: Mathematical Proofs (For Natural Science Students)",
        subUnits: [
          {
            id: "g12-mathem-u7-s1",
            name: "Revision on logic",
          },
          {
            id: "g12-mathem-u7-s2",
            name: "Different types of proofs",
          },
          {
            id: "g12-mathem-u7-s3",
            name: "Principle and application of mathematical induction",
          },
          {
            id: "g12-mathem-u7-s4",
            name: "Information Technology / ICT (Syllabus Set A - Outcomes)",
          },
        ],
      },
      {
        id: "g12-mathem-u8",
        name: "Unit: Information Systems",
        subUnits: [
          {
            id: "g12-mathem-u8-s1",
            name: "Know the application of ICT in different sectors;",
          },
          {
            id: "g12-mathem-u8-s2",
            name: "Understand the components of an Information System;",
          },
          {
            id: "g12-mathem-u8-s3",
            name: "Recognise the application of ICT in different sectors;",
          },
          {
            id: "g12-mathem-u8-s4",
            name: "Recognise how ICT can change the life of people.",
          },
        ],
      },
      {
        id: "g12-mathem-u9",
        name: "Unit: Enhancing the Use of Software",
        subUnits: [
          {
            id: "g12-mathem-u9-s1",
            name: "General Overview",
          },
        ],
      },
      {
        id: "g12-mathem-u10",
        name: "Unit: Basic Troubleshooting",
        subUnits: [
          {
            id: "g12-mathem-u10-s1",
            name: "Recognise basic idea in preventive maintenance",
          },
          {
            id: "g12-mathem-u10-s2",
            name: "Apply the knowledge gained in preventive maintenance to prolong the life of the computer",
          },
          {
            id: "g12-mathem-u10-s3",
            name: "Be aware of basic safety issues",
          },
          {
            id: "g12-mathem-u10-s4",
            name: "Recognise major hardware components inside the computer",
          },
          {
            id: "g12-mathem-u10-s5",
            name: "Acquire knowledge on how to format hard disc and install software",
          },
        ],
      },
      {
        id: "g12-mathem-u11",
        name: "Unit: Exploiting the Internet",
        subUnits: [
          {
            id: "g12-mathem-u11-s1",
            name: "Develop an awareness of web developments in making information available in different formats.",
          },
        ],
      },
      {
        id: "g12-mathem-u12",
        name: "Unit: Image Processing and Multimedia Systems",
        subUnits: [
          {
            id: "g12-mathem-u12-s1",
            name: "Understand the concept of image processing.",
          },
          {
            id: "g12-mathem-u12-s2",
            name: "Differentiate image file format.",
          },
          {
            id: "g12-mathem-u12-s3",
            name: "Recognize the function of image processing software.",
          },
          {
            id: "g12-mathem-u12-s4",
            name: "Recognize Interface layout of Image processing software",
          },
          {
            id: "g12-mathem-u12-s5",
            name: "Edit images properly using image processing software.",
          },
          {
            id: "g12-mathem-u12-s6",
            name: "Information Technology / ICT (Syllabus Set B - Contents)",
          },
        ],
      },
      {
        id: "g12-mathem-u13",
        name: "Unit: Information Systems",
        subUnits: [
          {
            id: "g12-mathem-u13-s1",
            name: "Basics of E-learning.",
          },
          {
            id: "g12-mathem-u13-s2",
            name: "Basics of E-Government",
          },
          {
            id: "g12-mathem-u13-s3",
            name: "Basics of E-Banking",
          },
          {
            id: "g12-mathem-u13-s4",
            name: "Basics of E-Libraries",
          },
          {
            id: "g12-mathem-u13-s5",
            name: "Basics of E-Commerce",
          },
          {
            id: "g12-mathem-u13-s6",
            name: "System Analysis.",
          },
        ],
      },
      {
        id: "g12-mathem-u14",
        name: "Unit: Enhancing the Use Of Software",
        subUnits: [
          {
            id: "g12-mathem-u14-s1",
            name: "Using Application Software",
          },
        ],
      },
      {
        id: "g12-mathem-u15",
        name: "Unit: Exploiting the Internet",
        subUnits: [
          {
            id: "g12-mathem-u15-s1",
            name: "General Concept of Website Design",
          },
          {
            id: "g12-mathem-u15-s2",
            name: "Planning a Website.",
          },
          {
            id: "g12-mathem-u15-s3",
            name: "Website Design Considerations",
          },
          {
            id: "g12-mathem-u15-s4",
            name: "Website Development",
          },
        ],
      },
      {
        id: "g12-mathem-u16",
        name: "Unit: Image Processing and Multimedia Systems",
        subUnits: [
          {
            id: "g12-mathem-u16-s1",
            name: "Basics Of Multimedia Multimedia",
          },
          {
            id: "g12-mathem-u16-s2",
            name: "Introduction to Multimedia Authoring Tools",
          },
          {
            id: "g12-mathem-u16-s3",
            name: "Inserting and Editing Text",
          },
          {
            id: "g12-mathem-u16-s4",
            name: "Working with Images and Graphics",
          },
          {
            id: "g12-mathem-u16-s5",
            name: "Page Transitions, Positioning and Motion Icon",
          },
          {
            id: "g12-mathem-u16-s6",
            name: "Libraries",
          },
          {
            id: "g12-mathem-u16-s7",
            name: "Working with Sound and Digital Movies",
          },
          {
            id: "g12-mathem-u16-s8",
            name: "Overview of Film Editing",
          },
        ],
      },
      {
        id: "g12-mathem-u17",
        name: "Glossary",
        subUnits: [
          {
            id: "g12-mathem-u17-s1",
            name: "General Overview",
          },
        ],
      },
    ],
  },
];
