import express from "express";
import path from "path";
import dotenv from "dotenv";
import fs from "fs";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore, doc, getDoc } from "firebase/firestore";

dotenv.config();

const firebaseConfig = {
  apiKey: process.env.VITE_FIREBASE_API_KEY || "AIzaSyBw1Hyf7F_HWZU8nJQ9q2P2yfY2-dPk050",
  authDomain: process.env.VITE_FIREBASE_AUTH_DOMAIN || "lively-pipe-jd2jw.firebaseapp.com",
  projectId: process.env.VITE_FIREBASE_PROJECT_ID || "lively-pipe-jd2jw",
  storageBucket: process.env.VITE_FIREBASE_STORAGE_BUCKET || "lively-pipe-jd2jw.firebasestorage.app",
  messagingSenderId: process.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "637000654202",
  appId: process.env.VITE_FIREBASE_APP_ID || "1:637000654202:web:172fb12339effed98c8ac3"
};

const firebaseApp = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(firebaseApp, "ai-studio-3f374b50-9b5a-4609-b07b-a9eeca5546e3");

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK lazily to avoid crashing on start if the key is missing
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not defined.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Robust fallback-enabled model generation helper to bypass 429 quota blockades on free keys
async function generateContentWithFallback(ai: GoogleGenAI, params: any, customModels?: string[]) {
  const models = customModels || ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash"];
  let firstError: any = null;
  for (const model of models) {
    try {
      console.log(`[FIYIT Model Fallback] Trying dynamic generation with model: ${model}`);
      
      const requestConfig = { ...(params.config || {}) };
      
      // Remove any thinkingConfig if mistakenly passed, as standard flash models do not support it
      delete requestConfig.thinkingConfig;

      const response = await ai.models.generateContent({
        ...params,
        model: model,
        config: requestConfig
      });
      console.log(`[FIYIT Model Fallback] Success with model: ${model}`);
      return response;
    } catch (err: any) {
      console.warn(`[FIYIT Model Fallback] Model ${model} returned error:`, err?.message || err);
      if (!firstError) {
        firstError = err;
      }
    }
  }
  throw firstError || new Error("All requested models failed fallback checks.");
}

// High-companionship active offline learning coach as secondary backup
function getOfflineCoachReply(message: string, grade: string, subject: string, name: string): string {
  const msg = message.toLowerCase();
  
  if (msg.includes("hello") || msg.includes("hi") || msg.includes("hey") || msg.includes("fiy")) {
    return `Hello ${name}! [HEART] Fiy is right here. Although my real-time server connection is undergoing temporary maintenance, I am always ready to help you study Grade ${grade} curriculum areas!

Which topic—like Mathematics, Chemistry, or Biology—would you like to practice today? Just say the name, and let's go!`;
  }
  
  if (msg.includes("math") || msg.includes("align") || msg.includes("equation") || msg.includes("algebra") || msg.includes("geometric") || msg.includes("number")) {
    return `Excellent focus on Mathematics! [TARGET] Under the Grade ${grade} curriculum, solving equations and simplifying expressions is crucial for exam power.

Let's test your math instincts:
What is the value of x if: 3x - 12 = 0?
A) x = 3
B) x = 4 [CHECK]
C) x = 6
D) x = 2

Type your answer! Fiy believes in your skills!`;
  }

  if (msg.includes("bio") || msg.includes("cell") || msg.includes("plant") || msg.includes("human") || msg.includes("organelle")) {
    return `Fascinating! Let's explore Biology. [BRAIN] In Grade ${grade} Biology, understand that Cells are the building blocks of all living organisms.

Here's a concept test:
Which organelle is responsible for generating energy in the form of ATP?
A) Ribosome
B) Nucleus
C) Mitochondrion [CHECK]
D) Vacuole

Go ahead and pick the best option!`;
  }

  if (msg.includes("chem") || msg.includes("atom") || msg.includes("element") || msg.includes("bond") || msg.includes("periodic")) {
    return `Chemistry is the science of atoms and bonding! [IDEA] Did you know that atoms gain, lose, or share valence electrons to achieve structural stability?

Recall this fundamental concept:
Which subatomic particle carries a negative electrical charge?
A) Proton
B) Neutron
C) Electron [CHECK]
D) Nucleus

Let me know which answer you choose!`;
  }

  if (msg.includes("phys") || msg.includes("force") || msg.includes("speed") || msg.includes("gravity") || msg.includes("motion") || msg.includes("constant")) {
    return `Physics rules mechanical motion around us! [ROCKET] In Grade ${grade} Physics, Newton's Second Law defines how force depends on an object's mass and speed acceleration.

Quick practice check:
What formula represents Newton's Second Law of Motion?
A) Force = Mass x Acceleration (F = ma) [CHECK]
B) Distance = Speed / Time
C) Density = Mass x Volume

Identify the correct formula, and let's keep study tracks active!`;
  }

  if (msg.includes("advice") || msg.includes("study") || msg.includes("help") || msg.includes("tip") || msg.includes("how")) {
    return `Fiy's proven study tip of the day: [STREAK]
1. Chunk your study: Work intensely for 25 minutes, then take a peaceful 5-minute break.
2. Space out review: Short daily reviews are 10x more effective than pulling late-night cram sessions.
3. Use Active Recall: Close the book and quiz yourself right after reading.

Which Grade ${grade} topic should we practice next? Fiy is right behind you!`;
  }

  return `Hey there, ${name}! [STREAK] Our standard server is currently undergoing quick maintenance due to high volume traffic, so I am operating in an offline companion mentoring mode right now to make sure you never miss a study task!

Are we ready to review some Grade ${grade} subjects together? Type "Mathematics", "Biology", "Chemistry", "Physics", or ask for "Study Advice", and let's conquer your curriculum study goals!`;
}

// Helper to robustly clean and parse JSON response containing potential markdown fences or stray wrap symbols
function parseCleanJson(text: string): any {
  let cleaned = text.trim();
  
  // Strip markdown code fences if present
  if (cleaned.startsWith("```json")) {
    cleaned = cleaned.substring("```json".length);
  } else if (cleaned.startsWith("```")) {
    cleaned = cleaned.substring("```".length);
  }
  if (cleaned.endsWith("```")) {
    cleaned = cleaned.substring(0, cleaned.length - "```".length);
  }
  cleaned = cleaned.trim();
  
  try {
    return JSON.parse(cleaned);
  } catch (err) {
    // Attempt 1: escape literal newlines inside strings with \n and remove trailing commas
    try {
      let temp = cleaned;
      // Replace raw newlines and carriage returns inside quotes with escaped \n and \r
      temp = temp.replace(/"([^"\\]*(?:\\.[^"\\]*)*)"/g, (match, p1) => {
        return '"' + p1.replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t') + '"';
      });
      // Strip trailing commas from objects/arrays
      temp = temp.replace(/,(\s*[\]}])/g, "$1");
      return JSON.parse(temp);
    } catch (err1) {
      // Attempt 2: salvage by grabbing contents between first '{' and last '}'
      const startIdx = cleaned.indexOf("{");
      const endIdx = cleaned.lastIndexOf("}");
      if (startIdx !== -1 && endIdx !== -1 && endIdx > startIdx) {
        try {
          let salvaged = cleaned.substring(startIdx, endIdx + 1);
          // Escape strings and remove trailing commas in salvaged
          salvaged = salvaged.replace(/"([^"\\]*(?:\\.[^"\\]*)*)"/g, (match, p1) => {
            return '"' + p1.replace(/\n/g, '\\n').replace(/\r/g, '\\r').replace(/\t/g, '\\t') + '"';
          });
          salvaged = salvaged.replace(/,(\s*[\]}])/g, "$1");
          return JSON.parse(salvaged);
        } catch (nestedErr) {
          throw err; // throw original JSON.parse error
        }
      }
      throw err;
    }
  }
}

// Helper to provide realistic educational mock responses as a fallback
function getMockLesson(subject: string, unit: string, subUnit: string, grade: string) {
  const normSub = (subject || "").toLowerCase();
  
  if (normSub.includes("biol")) {
    return {
      explanation: `Modern biological taxonomy divides living life-forms into five core kingdoms of life: Monera (unicellular prokaryotes like bacteria), Protista (single-celled eukaryotes), Fungi (decomposing heterotrophs), Plantae (autotrophic plant cells), and Animalia (multicellular ingestive ingestors). To study cells, remember how plant vacuoles apply high internal protoplast pressure to remain rigid. Transpiration and translocational vessels maintain nutrient flows.`,
      formula: "Core Photosynthetic Formula: 6CO₂ + 6H₂O + Solar Energy → C₆H₁₂O₆ + 6O₂",
      workedExample: {
        problem: `Explain how cell wall pressure and osmosis regulate plant cell turgidity in "${subUnit}".`,
        solution: "1. Under osmotic inflow, water enters the plant cell's large vacuole.\n2. Protoplast volume rises, pushing outward against the cellulose boundaries.\n3. The cell wall applies equal opposing Wall Pressure (WP), keeping cell shape beautifully turgid rather than lysing."
      },
      keyPoints: [
        "Monera consists entirely of prokaryotes devoid of nucleotic shells.",
        "Xylem pipelines transport ionic soil-water upwards via transpirational pull.",
        "Chloroplast plastids inside plant tissues convert light photons into stored glucose sugars."
      ]
    };
  }

  if (normSub.includes("chem")) {
    return {
      explanation: `Chemical elements are ordered sequentially in the Periodic Table according to their atomic number (the absolute proton count inside the nucleus). Atoms carry electrons inside specific energy shell levels surrounding positive protons and neutral neutrons. Compounds form via chemical valence sharing or complete ionic electron displacement.`,
      formula: "The Ideal Gas Law Equation: P * V = n * R * T",
      workedExample: {
        problem: `Find the complete orbital electron shell configuration for Carbon (Atomic Number: 6) studied under "${subUnit}".`,
        solution: "1. Locate 6 electrons in a neutral Carbon atom.\n2. Fill lower levels first according to building principles: 1s² takes 2 electrons.\n3. Move to next energy level: 2s² takes 2 electrons, and 2p² contains the remaining 2 valence electrons. Hence, the model is 1s² 2s² 2p²."
      },
      keyPoints: [
        "Atomic count corresponds directly to the proton number in the atomic nucleus.",
        "Valence electrons located in outer shells determine periodic bonding reactions.",
        "Noble gaseous elements possess complete outer octet structures, remaining chemically inert."
      ]
    };
  }

  if (normSub.includes("phys")) {
    return {
      explanation: `Classical thermodynamic and mechanical systems behave according to Newton's universal motion principles. Mass represents physical resistance to acceleration (inertia). Kinematic speed is a scalar rate, whereas velocity measures direction vectors. Energies translate across potential, kinetic, and thermal work boundaries.`,
      formula: "Net Work Magnitude: Work (W) = Force (F) * displacement (d) * cos(θ)",
      workedExample: {
        problem: `Compute the net horizontal mechanical force in "${subUnit}" required to accelerate a 5 kg mass at 4 m/s².`,
        solution: "1. State Newton's second law: Force (F) = mass (m) * Acceleration (a).\n2. Substitute the given values: F = 5 kg * 4 m/s².\n3. Determine the output: F = 20 Newtons (N)."
      },
      keyPoints: [
        "Inertia represents the natural mechanical resistance to sudden coordinate shifts.",
        "Kinetic energy remains directly proportional to mass and the square of scalar velocity.",
        "Every force action triggers an equal coplanar reaction on interacting contact points."
      ]
    };
  }

  if (normSub.includes("math")) {
    return {
      explanation: `Quadratic and algebraic equations model relationships of order two. In mathematics, we classify real figures into rational fractions and irrational decimals (such as square roots and pi) which cannot be written as simple ratios. Solving equations requires bringing variables to isolation and factoring carefully.`,
      formula: "The Quadratic Equation Formula: x = (-b ± √(b² - 4ac)) / (2a)",
      workedExample: {
        problem: `Solve for the roots of the algebraic quadratic equation x² + 5x + 6 = 0 in "${subUnit}".`,
        solution: "1. Seek two factors whose product is 6 and whose sum is 5.\n2. Rewrite the quadratic form as factors: (x + 2)(x + 3) = 0.\n3. Set each isolated bracket to zero, giving the distinct solutions: x = -2 and x = -3."
      },
      keyPoints: [
        "Irrational numbers cannot be represented as simple integer divisions.",
        "The quadratic discriminant (b² - 4ac) determines if root pairs are real or imaginary.",
        "Always maintain balanced proportions by applying mathematical operations across both equation sides."
      ]
    };
  }

  if (normSub.includes("eng")) {
    return {
      explanation: `Mastering syntactic voice shifts and proper grammatical tense is crucial in secondary English study. Active voice highlights the subject performing the action directly, while passive structure shifts attention to the object acting under the verb. Always ensure strong singular-plural subject-verb alignment.`,
      formula: "Active Sentence Syntax: Subject + Verb + Object (e.g., Fiy solved the query)",
      workedExample: {
        problem: `Transform 'The complex unit quiz was compiled by Teacher Tesfaye' in "${subUnit}" into Active Voice.`,
        solution: "1. Map the active agent 'Teacher Tesfaye' as the starting sentence subject.\n2. Shift passive past verb 'was compiled' to active simple past 'compiled'.\n3. Bind 'the complex unit quiz' as direct object: 'Teacher Tesfaye compiled the complex unit quiz.'"
      },
      keyPoints: [
        "Singular collective terms (like 'each' or 'every') require singular verb conjugations.",
        "Active clauses establish greater immediacy and read much cleaner than passive phrases.",
        "Conjugated helping verbs must align with temporal event coordinates."
      ]
    };
  }

  if (normSub.includes("ict") || normSub.includes("computer")) {
    return {
      explanation: `Information technology platforms structure, store, and compute logic blocks using primary binary digits (0 and 1 representation). Relational databases compile datasets inside strict indexed tables connected through primary key fields to prevent redundant entries. Logic gates govern electronic memory flow.`,
      formula: "Binary Weight Pattern: 2³=8, 2²=4, 2¹=2, 2⁰=1 (Decimal 5 is Binary 101)",
      workedExample: {
        problem: `Explain the fundamental role of Primary keys in relational tables studied in "${subUnit}".`,
        solution: "1. Primary keys act as absolute identifier tags.\n2. They prevent duplicate record rows from generating in relational storage.\n3. They allow nested referencing across tables using corresponding foreign key bounds."
      },
      keyPoints: [
        "Binary represents numbers solely using sequences of powers of two (base-2).",
        "Primary Keys must remain completely unique and can never contain empty null properties.",
        "Algorithms are sequential, step-by-step logic workflows written to resolve computable tasks."
      ]
    };
  }

  if (normSub.includes("geo")) {
    return {
      explanation: `Topographic map contours, relief curves, and contours outline actual elevation shifts across terrestrial geographic points. Ethiopian high highlands, split rift basins, and rain shadow zones dictate farming outputs and moisture patterns across our agro-ecological states. Use contour spacing to decode mountain slopes.`,
      formula: "Contour Interval calculation: Vertical elevation change / number of contour spaces",
      workedExample: {
        problem: `Determine the contour interval height in "${subUnit}" when index indicators rise from 1000m to 1200m across 5 spaces.`,
        solution: "1. Subtract boundary elevations: 1200m - 1000m = 200m.\n2. Divide this shift by map spaces: 200m / 5 steps.\n3. The contour interval is exactly 40 meters."
      },
      keyPoints: [
        "Densely packed contour maps represent steep cliffs and high elevation gradients drag.",
        "Agro-ecological zones are bounded by temperature indicators and yearly rain averages.",
        "Geographic features are charted using absolute global spherical coordinates (latitude and longitude)."
      ]
    };
  }

  if (normSub.includes("his")) {
    return {
      explanation: `Modern state history tracks heroic battles, international treaties, and crucial political transformations. Our immortal sovereign victory at Adwa on March 1, 1896, secured territorial freedom and shone as a global guiding beacon of black liberty against aggressive colonial expansions. Visual chronological timelines verify how events tie together.`,
      formula: "Adwa Victory Milestone: March 1, 1896 (Ethiopian independent sovereign triumph)",
      workedExample: {
        problem: `Summarize the major geopolitical impact of the historic Battle of Adwa in "${subUnit}".`,
        solution: "1. Ethiopian local defense forces successfully repelled and defeated invading European armies.\n2. This victory forced international treaty recognition of Ethiopia's total sovereign status.\n3. It established Ethiopia as a worldwide symbol of anti-colonial resistance and African pride."
      },
      keyPoints: [
        "Adwa represents a watershed moment of African independent success.",
        "Chronological mapping helps historical analysis by grouping interrelated treaties.",
        "Primary source documents like local letters provide original, unedited historical details."
      ]
    };
  }

  // General fallback
  return {
    explanation: `This is an curriculum-aligned book summary explaining "${subUnit}" under "${unit}" for Grade ${grade} ${subject}. In the Ethiopian high school curriculum, understanding this core topic is crucial for building robust knowledge, mastering exams, and preparing for national assessments. It details fundamental relationships, concepts, and practical applications.`,
    formula: "Key Study Concept: Break down extensive chapters into active recall summaries and quiz patterns.",
    workedExample: {
      problem: `Practice question for ${subUnit}: Explain the practical application of this topic in Ethiopian secondary studies.`,
      solution: "1. Identify the fundamental principles of the topic.\n2. Apply the concepts to continuous classroom exercises.\n3. Complete self-quizzes to lock in key facts and definitions."
    },
    keyPoints: [
      "Fiy recommends reviewing key terms and summaries sequentially.",
      "Solve five core quiz questions daily to boost your subject confidence index.",
      "Capture important formulas and definitions in your physical study notebook."
    ]
  };
}

function getMockQuiz(subUnit: string) {
  return {
    questions: [
      {
        id: "q1",
        question: `What is the primary governing principle of ${subUnit}?`,
        options: [
          "It scales linearly with initial system conditions.",
          "It remains completely static and independent of external variables.",
          "It represents a local equilibrium state.",
          "It relies entirely on empirical constant measurements."
        ],
        answerIndex: 0,
        explanation: "Linear scaling allows simple proportional calculations, which is standard for secondary level studies."
      },
      {
        id: "q2",
        question: `Which of the following is most critical when analyzing a question in ${subUnit}?`,
        options: [
          "Disregarding all minor decimal values.",
          "Ensuring all measurement units match standard SI coordinates.",
          "Memorizing only final static definitions.",
          "Relying solely on digital calculations."
        ],
        answerIndex: 1,
        explanation: "SI unit alignment is critical to ensure equations compile correctly without dimensional errors."
      },
      {
        id: "q3",
        question: `In standard terms, how would you best summarize ${subUnit}?`,
        options: [
          "A tool of purely historical theoretical importance.",
          "An applied mechanism representing structural, physical, or logical balance.",
          "A complex study restricted only to postgraduate scholars.",
          "A random series of unlinked equations."
        ],
        answerIndex: 1,
        explanation: "Balance and applied mechanisms form the foundations of both natural and social sciences in grades 9 through 12."
      }
    ]
  };
}

// --- CACHING ENGINE SETUP ---

interface CacheStats {
  totalRequests: number;
  cacheHits: number;
  cacheMisses: number;
  usdSaved: number;
}

interface ServerCache {
  lessons: Record<string, any>;
  quizzes: Record<string, any[]>; // Array of cached quiz questions variations (bounded to 3 variants)
  stats: CacheStats;
}

const CACHE_FILE_PATH = path.join(process.cwd(), "dev_server_cache.json");

let serverCache: ServerCache = {
  lessons: {},
  quizzes: {},
  stats: {
    totalRequests: 0,
    cacheHits: 0,
    cacheMisses: 0,
    usdSaved: 0
  }
};

// Load cache on server start
try {
  if (fs.existsSync(CACHE_FILE_PATH)) {
    const data = fs.readFileSync(CACHE_FILE_PATH, "utf-8");
    serverCache = JSON.parse(data);
    if (!serverCache.lessons) serverCache.lessons = {};
    if (!serverCache.quizzes) serverCache.quizzes = {};
    if (!serverCache.stats) serverCache.stats = { totalRequests: 0, cacheHits: 0, cacheMisses: 0, usdSaved: 0 };
    console.log(`[FIYIT Cache Engine] Loaded cached lessons: ${Object.keys(serverCache.lessons).length}, quizzes: ${Object.keys(serverCache.quizzes).length}`);
  }
} catch (err) {
  console.error("[FIYIT Cache Engine] Error loading cache file, starting fresh", err);
}

function saveServerCache() {
  try {
    fs.writeFileSync(CACHE_FILE_PATH, JSON.stringify(serverCache, null, 2), "utf-8");
  } catch (err) {
    console.error("[FIYIT Cache Engine] Error writing cache to disk", err);
  }
}

function getCacheKey(grade: string, stream: string | undefined, subject: string, unit: string, subUnit: string, language: string, version: string = "v1"): string {
  const normGrade = String(grade || "").trim();
  const normStream = stream ? String(stream).trim().toLowerCase() : "general";
  const normSub = String(subject || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
  const normUn = String(unit || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
  const normSubUn = String(subUnit || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "");
  const normLang = String(language || "English").trim().toLowerCase();
  return `g${normGrade}_s_${normStream}_sub_${normSub}_u_${normUn}_un_${normSubUn}_lang_${normLang}_ver_${version}`;
}

// --- API ENDPOINTS ---

// Health Check API
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    hasApiKey: !!process.env.GEMINI_API_KEY,
    time: new Date().toISOString()
  });
});

// Cache Stats API for tracking hit-rate and exact cost savings
app.get("/api/cache-stats", (req, res) => {
  res.json({
    ...serverCache.stats,
    lessonsCachedCount: Object.keys(serverCache.lessons).length,
    quizzesCachedCount: Object.keys(serverCache.quizzes).length,
    hitRatePercentage: serverCache.stats.totalRequests > 0 
      ? Math.round((serverCache.stats.cacheHits / serverCache.stats.totalRequests) * 100) 
      : 0
  });
});

// Generate Lesson via Gemini with Shared Server-Side Caching & Personalization
app.post("/api/generate-lesson", async (req, res) => {
  const { subject, unit, subUnit, grade, stream, language = "English", profile } = req.body;

  if (!subject || !unit || !subUnit || !grade) {
    res.status(400).json({ error: "Missing required parameters: subject, unit, subUnit, grade" });
    return;
  }

  const cacheKey = getCacheKey(grade, stream, subject, unit, subUnit, language, "v1");

  console.log(`[FIYIT Engine] Generating lesson from Gemini for key: ${cacheKey}`);

  try {
    const ai = getGeminiClient();
    const streamText = stream ? `(${stream} Stream)` : "";

    // Build personalization settings
    let personalizationInstructions = "";
    if (profile) {
      const tone = profile.coachingTonePreference || "Kind";
      const style = profile.learningStylePreference || "Practice";
      const session = profile.sessionLengthPreference || "Focused";
      const struggle = profile.commonStruggleKeywords || "Concepts";

      personalizationInstructions = `
- Personalized Studying Adaptations:
  * Coaching Tone: Respond with a ${tone} tone. (Kind = warm, ultra-supportive, empathetic. Strict = highly direct, structured, focused. Data = analytical, performance-driven).
  * Learning Style: Focus especially on ${style} style explanations.
  * Session Duration Target: The student prefers ${session} sessions, so adjust density accordingly (Short = concise bullets, Focused = standard, Marathon = comprehensive depth).
  * Core Struggle Trigger: The student struggles with ${struggle}, so address this directly by providing aids like mnemonics table, definitions, or procedural instructions.
`;
    }

    const prompt = `You are a professional, motivating Ethiopian High School educator and Study Coach.
Generate structured, curriculum-appropriate lesson content for:
- Grade: ${grade}
- Subject: ${subject} ${streamText}
- Unit: ${unit}
- Sub-unit / Lesson Title: ${subUnit}
- Target Language: ${language}

CRITICAL TEACHER CONSISTENCY & INTEGRITY RULES:
The hardcoded teacher lookup table in FIYIT consists of the following specific subject educators:
- Mathematics: Teacher Mufariat
- Biology: Teacher Tesfaye
- Physics: Teacher Hanan
- Chemistry: Teacher Biruk
- English: Teacher Nuri
- Geography: Teacher Wazir
- History: Teacher Bekele
- ICT: Teacher Ismael

These are the ONLY teacher names that exist in FIYIT. Never invent, suggest, hypothesize, or reference any other teacher name (e.g. NEVER mention "Ms. Anya Sharma", "Mrs. Smith", "Teacher Aster", or any other made-up names). Use these names EXACTLY as listed if you ever need to reference a teacher in any context.

Language Requirement & LaTeX/Math Formatting Rules:
1. You MUST write all textual content (explanation, problem, solution, and keyPoints) ENTIRELY in ${language}. DO NOT mix languages under any circumstances. If the Target Language is Amharic, use Amharic text. If Afaan Oromo, use Oromo text. If English, use English.
2. Do not use LaTeX syntax in your responses (no dollar signs $, no \\frac, \\xrightarrow, \\text{}, ^{}, _{}, or similar LaTeX/markdown math commands). Write all chemical formulas, equations, and mathematical expressions using plain text with Unicode subscript/superscript characters where appropriate.
Examples of CORRECT formatting:
- H₂O (not $H_2O$)
- 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂ (not LaTeX equation blocks)
- x² + 5x + 6 = 0 (not $x^2 + 5x + 6=0$)
Use simple arrows (→), Unicode subscripts (₀₁₂₃₄₅₆₇₈₉), and Unicode superscripts (⁰¹²³⁴⁵⁶⁷⁸⁹) for all scientific notation.
3. You are strictly forbidden from outputting standard pictorial emojis (e.g., 😀, 🔥, 📚, ✅, etc.). Instead, use exactly ONE of these custom visual tags if and only if visual focus is desired (otherwise use none): [STREAK] [BOOK] [TARGET] [TROPHY] [IDEA] [CHECK] [STAR] [ROCKET] [CLOCK] [PENCIL] [HEART] [TRENDING] [THUMBSUP] [BRAIN] [CELEBRATE] [ALARM]. Avoid placing multiple tags in a single paragraph.

This lesson is being designed for Ethiopian secondary students (Grades 9-12), who are preparing for continuous assessments and competitive national entrance exams. Keep language simple, extremely clear, encouragement-packed, and visually structured.
${personalizationInstructions}

You must respond with raw JSON only, matching the exact structure below (no markdown wrappers like \`\`\`json, just the pure json text):
{
  "explanation": "Detailed, highly clear, and digestible study notes explaining the topic's core concept, in student-friendly terms.",
  "formula": "Single crucial mathematical formula, chemical equation, or key definition box (leave empty if not applicable).",
  "workedExample": {
    "problem": "An educational worked practice problem or situational question demonstrating the concept.",
    "solution": "Clear, detailed step-by-step mathematical or logical solution to the problem."
  },
  "keyPoints": [
    "Key takeaway point 1 for memorization and quick study.",
    "Key takeaway point 2 focused on common exam traps.",
    "Key takeaway point 3 summarizing the core takeaway."
  ]
}`;

    const response = await generateContentWithFallback(ai, {
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text || "";
    const lessonData = parseCleanJson(text);

    res.json(lessonData);

  } catch (error: any) {
    console.error("Gemini lesson generator error:", error);
    // Graceful fallback
    const fallback = getMockLesson(subject, unit, subUnit, grade);
    res.json({
      ...fallback,
      isDemoMode: true,
      debugMessage: error.message || String(error)
    });
  }
});

// Translate Generated Lesson content into target language
app.post("/api/translate-lesson", async (req, res) => {
  const { lessonContent, targetLanguage, subUnitId } = req.body;

  if (!lessonContent || !targetLanguage || !subUnitId) {
    res.status(400).json({ error: "Missing required parameters: lessonContent, targetLanguage, subUnitId" });
    return;
  }

  try {
    const ai = getGeminiClient();
    const prompt = `You are an expert professional Ethiopian educational translator specializing in secondary school curriculums.
Translate the following High School lesson content into clear, natural, grammatically perfect ${targetLanguage}.

Lesson content to translate:
${JSON.stringify(lessonContent)}

Strict Rules:
1. Return your translation as raw JSON matching this exact structure:
   {
     "explanation": "Translated explanation text...",
     "formula": "Translated formulas/concepts if applicable...",
     "workedExample": {
       "problem": "Translated problem...",
       "solution": "Translated step-by-step solution..."
     },
     "keyPoints": [
       "Translated keypoint 1...",
       "Translated keypoint 2...",
       "Translated keypoint 3..."
     ]
   }
2. IMPORTANT: Do NOT translate or transliterate any of these hardcoded Teacher names (keep them exactly as written in Latin script and same spelling): Teacher Alemu, Teacher Tesfaye, Teacher Hana, Teacher Biruk, Teacher Ruth, Teacher Dawit, Teacher Bekele, Teacher Samuel. (e.g., maintain "Teacher Dawit", do not change it in Amharic/Oromo).
3. Do not use LaTeX syntax in your answers (no $, no \\frac, etc.). Write all chemical formulas, equations, and mathematical symbols using plain text with unicode subscript/superscript characters.
4. Do not output any pictographic emojis. Use the bracket tags like [BOOK], [TARGET] if present in the source text, but do not add new ones.
5. Return ONLY pure raw JSON, no markdown codeblocks (\`\`\`json).`;

    const response = await generateContentWithFallback(ai, {
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const translatedData = parseCleanJson(response.text || "");
    res.json(translatedData);
  } catch (err: any) {
    console.error("Lesson translation error:", err);
    res.status(500).json({ error: "Failed to translate lesson content." });
  }
});

// Generate Practice Quiz via Gemini with Shared Server-Side Caching & Personalization
app.post("/api/generate-quiz", async (req, res) => {
  const { subject, unit, subUnit, grade, stream, lessonContent, language = "English", variantIndex = 0, profile } = req.body;

  if (!subUnit) {
    res.status(400).json({ error: "Missing required parameters: subUnit" });
    return;
  }

  const targetVariantIdx = Math.min(Math.max(0, parseInt(variantIndex as any) || 0), 2);

  console.log(`[FIYIT Engine] Generating quiz from Gemini for subUnit: ${subUnit}, variant index: ${targetVariantIdx}`);

  try {
    const ai = getGeminiClient();
    const streamText = stream ? `(${stream} Stream)` : "";

    // Build personalization settings
    let quizPersonalizationInstructions = "";
    if (profile) {
      const goal = profile.targetScoreGoal || "Strong";
      const style = profile.learningStylePreference || "Practice";
      const confidence = profile.subjectConfidence?.[subject ? subject.toLowerCase() : "maths"] || "Okay";
      
      quizPersonalizationInstructions = `
- Quiz Tailoring Parameters:
  * Target Score Goal: Designed for a student aiming for a ${goal} score. Adjust question challenge level (Star = distinction level exam questions, Strong = standard high-performance competitive national exam level, Pass = fundamental assessment standards).
  * Learning Style Preference: Focus questions on ${style} check patterns.
  * Student Subject Confidence Level: The student feels ${confidence} in this subject. Adjust difficulty or structure to build their competence and avoid discouragement.
`;
    }

    const prompt = `You are a professional high school examiner for the Ethiopian Ministry of Education.
Generate an interactive multiple-choice practice quiz based on the following specific high school lesson content and target parameters:
- Lesson Content: ${JSON.stringify(lessonContent || {})}
- Sub-unit: ${subUnit}
- Subject: ${subject || ""} Grade ${grade || ""} ${streamText}
- Target Language: ${language}
- Question Variant Index: ${targetVariantIdx} (Generate a completely unique and separate alternative set of questions from other variants)

CRITICAL TEACHER CONSISTENCY & INTEGRITY RULES:
The hardcoded teacher lookup table in FIYIT consists of the following specific subject educators:
- Mathematics: Teacher Mufariat
- Biology: Teacher Tesfaye
- Physics: Teacher Hanan
- Chemistry: Teacher Biruk
- English: Teacher Nuri
- Geography: Teacher Wazir
- History: Teacher Bekele
- ICT: Teacher Ismael

These are the ONLY teacher names that exist in FIYIT. Never invent, suggest, hypothesize, or reference any other teacher name (e.g. NEVER mention "Ms. Anya Sharma", "Mrs. Smith", "Teacher Aster", or any other made-up names). Use these names EXACTLY as listed if you ever need to reference a teacher in any context.

Language Requirement & LaTeX/Math Formatting Rules:
1. You MUST write all textual content (question statement, multiple-choice options, and explanations) ENTIRELY in ${language}. DO NOT mix languages. If Target Language is Amharic, use Amharic text. If Afaan Oromo, use Oromo text. If English, use English.
2. Do not use LaTeX syntax in your responses (no dollar signs $, no \\frac, \\xrightarrow, \\text{}, ^{}, _{}, or similar LaTeX/markdown math commands). Write all chemical formulas, equations, and mathematical expressions using plain text with Unicode subscript/superscript characters where appropriate.
Examples of CORRECT formatting:
- H₂O (not $H_2O$)
- 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂ (not LaTeX equation blocks)
- x² + 5x + 6 = 0 (not $x^2 + 5x + 6=0$)
Use simple arrows (→), Unicode subscripts (₀₁₂₃₄₅₆₇₈₉), and Unicode superscripts (⁰¹²³⁴⁵⁶⁷⁸⁹) for all scientific notation.
3. You are strictly forbidden from outputting standard pictorial emojis (e.g., 😀, 🔥, 📚, ✅, etc.). Instead, use exactly ONE of these custom visual tags if and only if visual focus is desired (otherwise use none): [STREAK] [BOOK] [TARGET] [TROPHY] [IDEA] [CHECK] [STAR] [ROCKET] [CLOCK] [PENCIL] [HEART] [TRENDING] [THUMBSUP] [BRAIN] [CELEBRATE] [ALARM]. Avoid placing multiple tags in a single paragraph.

Create exactly 5 high-quality, multiple-choice questions matching this material's depth. Focus on verifying deep comprehension, common student misconceptions, and numerical/analytical prowess.
${quizPersonalizationInstructions}

You must respond with raw JSON only, matching the exact structure below (no markdown wrappers, just the raw json text):
{
  "questions": [
    {
      "id": "q1_${targetVariantIdx}",
      "question": "Clear and challenging question statement here?",
      "options": ["Option A text", "Option B text", "Option C text", "Option D text"],
      "answerIndex": 0, // 0-indexed integer corresponding to correct option
      "explanation": "Brief explanation describing why this answer is correct and clarifying concepts."
    },
    ...
  ]
}`;

    const response = await generateContentWithFallback(ai, {
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text || "";
    const quizData = parseCleanJson(text);

    res.json(quizData);

  } catch (error: any) {
    console.error("Gemini quiz generator error:", error);
    // Graceful offline fallback
    const fallback = getMockQuiz(subUnit);
    res.json({
      ...fallback,
      isDemoMode: true,
      debugMessage: error.message || String(error)
    });
  }
});

// Chat Coach AI proxy route with support for Fiy, emotional intelligence, subject teachers, and custom icons tag restrictions
const SUBJECT_TEACHERS: Record<string, { name: string; style: string; bio: string }> = {
  maths: {
    name: "Teacher Mufariat",
    style: "strict but brilliant geometric/algebraic visualization",
    bio: "Sparsely utilizes visual spatial models and holds highly rigorous proofs. Encourages precise derivation."
  },
  mathematics: {
    name: "Teacher Mufariat",
    style: "strict but brilliant geometric/algebraic visualization",
    bio: "Sparsely utilizes visual spatial models and holds highly rigorous proofs. Encourages precise derivation."
  },
  biology: {
    name: "Teacher Tesfaye",
    style: "fun, practical storytelling style, relates structures to Ethiopia's ecosystems",
    bio: "Enjoys connecting human biomechanics and cellular pathways directly to local context."
  },
  physics: {
    name: "Teacher Hanan",
    style: "direct, logical formulas breakdown, interactive everyday mechanics analogies",
    bio: "Passionate about simplifying mechanical dynamics and quantum state variables using everyday analogies."
  },
  chemistry: {
    name: "Teacher Biruk",
    style: "engaging molecular diagrams, laboratory walkthroughs",
    bio: "Translates atomic reaction formulas and molecular geometries into vivid conceptual stories."
  },
  english: {
    name: "Teacher Nuri",
    style: "patient grammar structures, conversational vocabulary exercises",
    bio: "Empathetic linguistics guide focusing on structured vocabulary acquisition in simple lessons."
  },
  geography: {
    name: "Teacher Wazir",
    style: "vivid geographic mapping, agricultural and topographic examples",
    bio: "Brings maps, soils, and demographic grids to life with real-life Ethiopian terrain studies."
  },
  history: {
    name: "Teacher Bekele",
    style: "epic historical timelines, narrates battles and global events like a movie",
    bio: "Transports you back to legendary moments in Ethiopian and world civilizations with rich, vivid pacing."
  },
  ict: {
    name: "Teacher Ismael",
    style: "modern, code-packed, practical computing concepts",
    bio: "High-tech software engineer and hardware expert explaining binary, databases, and algorithms directly."
  },
  information: {
    name: "Teacher Ismael",
    style: "modern, code-packed, practical computing concepts",
    bio: "High-tech software engineer and hardware expert explaining binary, databases, and algorithms directly."
  }
};

const getTeacherForSubject = (subj?: string) => {
  if (!subj) return null;
  const norm = subj.toLowerCase().trim();

  // Multilingual subject mapping
  if (norm.includes("math") || norm.includes("ሒሳብ") || norm.includes("herrega") || norm.includes("hisab")) {
    return SUBJECT_TEACHERS.mathematics;
  }
  if (norm.includes("phys") || norm.includes("ፊዚክስ") || norm.includes("fiiziksii") || norm.includes("fiziks")) {
    return SUBJECT_TEACHERS.physics;
  }
  if (norm.includes("biol") || norm.includes("ባዮሎጂ") || norm.includes("baayoloojii") || norm.includes("bioloojii") || norm.includes("bayoloji")) {
    return SUBJECT_TEACHERS.biology;
  }
  if (norm.includes("chem") || norm.includes("ኬሚስትሪ") || norm.includes("keemistrii") || norm.includes("kemistri")) {
    return SUBJECT_TEACHERS.chemistry;
  }
  if (norm.includes("engl") || norm.includes("እንግሊዝኛ") || norm.includes("ingiliffa") || norm.includes("english")) {
    return SUBJECT_TEACHERS.english;
  }
  if (norm.includes("geog") || norm.includes("ጂኦግራፊ") || norm.includes("jiyoogiraafii") || norm.includes("geografi")) {
    return SUBJECT_TEACHERS.geography;
  }
  if (norm.includes("hist") || norm.includes("ታሪክ") || norm.includes("seenaa") || norm.includes("tarik")) {
    return SUBJECT_TEACHERS.history;
  }
  if (norm.includes("ict") || norm.includes("አይሲቲ") || norm.includes("kompuyutara") || norm.includes("saayinsii") || norm.includes("computing") || norm.includes("information")) {
    return SUBJECT_TEACHERS.ict;
  }

  for (const key in SUBJECT_TEACHERS) {
    if (norm.includes(key)) return SUBJECT_TEACHERS[key];
  }
  return null;
};

function detectLanguageOfText(text: string): "Amharic" | "Oromo" | "English" {
  if (!text) return "English";
  
  // 1. If text has Ge'ez characters (Ethiopic range: \u1200-\u137F), it is Amharic
  if (/[\u1200-\u137F]/.test(text)) {
    return "Amharic";
  }

  const lower = text.toLowerCase().trim();

  // 2. Scan for Amharic mentions or transliterations
  const amharicTriggers = [
    "amharic", "amarigna", "amharigna", "selam", "tadias", "astemari", "temari", 
    "እንደምን", "አማርኛ", "ጎበዝ"
  ];
  for (const trigger of amharicTriggers) {
    if (lower.includes(trigger)) {
      return "Amharic";
    }
  }

  // 3. Scan for Afaan Oromo mentions or transliterations
  const oromoTriggers = [
    "akkam", "oromo", "oromoo", "oromif", "afaan", "qubee", "galatoom", "barsiis", 
    "barat", "gaaff", "deebii", "herreg", "fiiziks", "keemist", "barnoot", "seenaa"
  ];
  for (const trigger of oromoTriggers) {
    if (lower.includes(trigger)) {
      return "Oromo";
    }
  }

  return "English";
}

function generateOfflineCoachReply(message: string, profile: any, activeTeacherSubject: string): string {
  const name = profile?.name || "Serious Student";
  const grade = profile?.grade || "9";
  const detectedLang = detectLanguageOfText(message || "");
  const profileLang = profile?.language || "English";
  const language = (detectedLang === "English" && profileLang !== "English") ? profileLang : detectedLang;
  const activeSubject = (activeTeacherSubject || "General").trim();
  const lowMsg = message.toLowerCase();

  // Pick customized teacher/persona prefix
  const teacher = getTeacherForSubject(activeSubject);
  const teacherPrefix = teacher 
    ? `[BRAIN] Hi ${name}! I am ${teacher.name}, your ${activeSubject} teacher. Even though my connection with our brain center is a bit slow right now, my offline curriculum database is fully ready to guide you.` 
    : `[STAR] Hi ${name}! I am Fiy, your AI study companion. Our connection is currently experiencing high demand, but my offline study engines are completely armed with your Grade ${grade} profile. Let's keep studying!`;

  // Language customization
  const translationMap: Record<string, any> = {
    Amharic: {
      maths: "ሒሳብ (Mathematics)",
      biology: "ባዮሎጂ (Biology)",
      physics: "ፊዚክስ (Physics)",
      chemistry: "ኬሚስትሪ (Chemistry)",
      english: "እንግሊዝኛ (English)",
      history: "ታሪክ (History)",
      geography: "ጂኦግራፊ (Geography)",
      ict: "ኮምፒውተር (ICT)",
      formula: "ቀመር (Formula): ",
      quizPrompt: "ለእርስዎ ፈጣን ጥያቄ ይኸውና (Here is a quiz question for you):",
      explanation: "ማብራሪያ (Explanation):",
      greeting: `ሰላም ${name}! እኔ ፊይ (Fiy) ነኝ። አሁን አጭር የኢንተርኔት መቆራረጥ ስላጋጠመን የቅርብ የጥናት ረዳትዎ ሆኜ እቀጥላለሁ።`
    },
    Oromo: {
      maths: "Herrega (Mathematics)",
      biology: "Biology (Biology)",
      physics: "Fiiziksii (Physics)",
      chemistry: "Keemistrii (Chemistry)",
      english: "Afaan Ingiliizii (English)",
      history: "Seenaa (History)",
      geography: "Ji'oogiraafii (Geography)",
      ict: "Kompiutara (ICT)",
      formula: "Formulaa: ",
      quizPrompt: "Gaaffii fi deebii siif qopheesseen jira (Here is a quiz question):",
      explanation: "Ibsa (Explanation):",
      greeting: `Akkam ${name}! Ani Fiy dha. Sababa qunnamtii xiqqoo kanaan yeroof offline ta'us si gargaaruuf qophiidha.`
    },
    English: {
      maths: "Mathematics",
      biology: "Biology",
      physics: "Physics",
      chemistry: "Chemistry",
      english: "English",
      history: "History",
      geography: "Geography",
      ict: "ICT",
      formula: "Key Formula / Rule: ",
      quizPrompt: "Let's challenge your brain with this practice question:",
      explanation: "Explanation:",
      greeting: `[STAR] Hello ${name}! Fiy is here as your offline companion during this network slowdown.`
    }
  };

  const t = translationMap[language] || translationMap["English"];

  // 1. GREETING/INTRO
  if (lowMsg.includes("hello") || lowMsg.includes("hi ") || lowMsg.length < 4 || lowMsg.includes("hey") || lowMsg.includes("who are you") || lowMsg.includes("welcome")) {
    if (language === "Amharic") {
      return `${t.greeting} ዛሬ 9ኛ-12ኛ ክፍል ትምህርት የትኛውን ርዕስ ማጥናት ይፈልጋሉ? [CHECK]`;
    } else if (language === "Oromo") {
      return `${t.greeting} Har'a barnoota maalii barachuu barbaadda? [CHECK]`;
    } else {
      return `${teacherPrefix}
I am fully optimized to help you with your Ethiopian Ministry of Education curriculum. What topic, formula, or practice quiz would you like to tackle today for Grade ${grade} ${activeSubject}? [CHECK]`;
    }
  }

  // 2. QUIZ / TEST / ASK QUESTIONS REQUEST
  if (lowMsg.includes("quiz") || lowMsg.includes("test") || lowMsg.includes("question") || lowMsg.includes("problem") || lowMsg.includes("ask me")) {
    // Generate a beautiful, specific offline question based on activeSubject and grade
    const sub = activeSubject.toLowerCase();
    let qText = "";
    let options: string[] = [];
    let correct = "";
    let explanation = "";

    if (sub.includes("math")) {
      qText = `For Grade ${grade} Mathematics: Which of the following is the correct scientific notation for the number 450,000?`;
      options = ["A) 45 * 10⁴", "B) 4.5 * 10⁵", "C) 4.5 * 10⁻⁵", "D) 0.45 * 10⁶"];
      correct = "B";
      explanation = "Scientific notation is written in the form a * 10ⁿ, where 1 ≤ a < 10. Thus, shifting the decimal point 5 places left gives us 4.5 * 10⁵. [CHECK]";
    } else if (sub.includes("biol")) {
      qText = `For Grade ${grade} Biology: What is the main structural difference between Plant Cells and Animal cells?`;
      options = [
        "A) Plant cells have mitochondria, animal cells do not.",
        "B) Plant cells possess a rigid Cellulose Cell Wall and Chloroplasts.",
        "C) Animal cells have larger central vacuoles.",
        "D) Plant cells do not contain cellular nuclei."
      ];
      correct = "B";
      explanation = "Only plant cells possess a thick cellulose cell wall and chlorophyll-containing chloroplasts for photosynthesis. [CHECK]";
    } else if (sub.includes("phys")) {
      qText = `For Grade ${grade} Physics: According to Newton's Second Law of Motion, what is the formula for force?`;
      options = ["A) F = m * a", "B) F = m / a", "C) F = m * v²", "D) F = w * h"];
      correct = "A";
      explanation = "Newton's second law states Force (F) equals Mass (m) times Acceleration (a). Units are in Newtons (N). [CHECK]";
    } else if (sub.includes("chem")) {
      qText = `For Grade ${grade} Chemistry: What is the atomic number of Carbon, which sits in Group 14 of the Periodic Table?`;
      options = ["A) 4", "B) 6", "C) 8", "D) 12"];
      correct = "B";
      explanation = "Carbon has an atomic number of 6, carrying exactly 6 protons in its atomic nucleus. [CHECK]";
    } else if (sub.includes("eng")) {
      qText = `For Grade ${grade} English Grammar: Identify the active voice form of: 'The lesson was explained by Teacher Ruth.'`;
      options = [
        "A) Teacher Ruth is explaining the lesson.",
        "B) Teacher Ruth explained the lesson.",
        "C) The lesson explains Teacher Ruth.",
        "D) Teacher Ruth will explain the lesson."
      ];
      correct = "B";
      explanation = "The sentence 'The lesson was explained by Teacher Ruth' is in the past simple passive. Its active counterpart is 'Teacher Ruth explained the lesson.' [CHECK]";
    } else {
      qText = `Let's check your key Grade ${grade} analytical understanding. Which method is most effective when preparing for Ethiopia's national exams?`;
      options = [
        "A) Blind cramming of concepts the night before.",
        "B) Active learning via consistent flashcards, quizzes, and spaced retrieval practice.",
        "C) Simply reading textbooks passive-style.",
        "D) Disregarding practical laboratory formulas."
      ];
      correct = "B";
      explanation = "Active, spaced recall is scientifically proven to establish durable neurological connections and higher scores! [CHECK]";
    }

    if (language === "Amharic") {
      return `${teacherPrefix}
${t.quizPrompt}
**ጥያቄ**: ${qText}
${options.join("\n")}

${t.explanation} ትክክለኛው መልስ **${correct}** ነው። ማብራሪያው- ${explanation} [TROPHY]`;
    } else if (language === "Oromo") {
      return `${teacherPrefix}
${t.quizPrompt}
**Gaaffii**: ${qText}
${options.join("\n")}

${t.explanation} Deebiin sirriin **${correct}** dha. Ibsa- ${explanation} [TROPHY]`;
    } else {
      return `${teacherPrefix}
${t.quizPrompt}
**Question**: ${qText}
${options.join("\n")}

**Correct Answer**: **${correct}**
${t.explanation} ${explanation} [TROPHY]`;
    }
  }

  // 3. FORMULA / EQUATION REQUEST
  if (lowMsg.includes("formula") || lowMsg.includes("equation") || lowMsg.includes("math expression") || lowMsg.includes("how to solve")) {
    const sub = activeSubject.toLowerCase();
    let formulaBlock = "";
    if (sub.includes("math")) {
      formulaBlock = "Quadratic Equation Formula:\nFor ax² + bx + c = 0, the roots are:\nx = (-b ± √(b² - 4ac)) / (2a)";
    } else if (sub.includes("phys")) {
      formulaBlock = "Work and Kinetic Energy equations:\nWork (W) = Force (F) * distance (d) * cos(θ)\nKinetic Energy (KE) = ½ * m * v²";
    } else if (sub.includes("chem")) {
      formulaBlock = "The Ideal Gas Law Equation:\nP * V = n * R * T\nWhere: P = pressure, V = volume, n = moles, R = gas constant, T = temperature in Kelvin.";
    } else if (sub.includes("eng")) {
      formulaBlock = "Active vs. Passive Voice pattern:\nActive: Subject + Verb + Object (e.g. Fiy solved the problem)\nPassive: Object + auxiliary Be + Past Participle + by + Subject (e.g. The problem was solved by Fiy).";
    } else {
      formulaBlock = "Ethiopian High School Unified Metric Unit conversion:\n1 Kilometer (km) = 1,000 Meters (m)\n1 Liter (L) = 1,000 Milliliters (mL)\nSI Unit of Force = Newton (N)\nSI Unit of Energy = Joule (J)";
    }

    return `${teacherPrefix}
Here is a vital formula representation from your Grade ${grade} studies:
\`\`\`text
${formulaBlock}
\`\`\`
Take a moment to write this down in your physical study notebook! Applying this systematically will yield incredible exam gains. [PENCIL]`;
  }

  // 4. SUBJECT-SPECIFIC GENERAL LESSON REQUEST (e.g. "Biology", "real numbers", "cell biology")
  const sub = activeSubject.toLowerCase();
  let customAnswer = "";
  if (sub.includes("math") || lowMsg.includes("number") || lowMsg.includes("algebra") || lowMsg.includes("geometry")) {
    customAnswer = `In Grade ${grade} Mathematics, we learn that number systems are built from real numbers (which encompass all rational figures like fractions, and irrational units like √2 which cannot be written as a quotient of two integers). 
For Algebra, we specialize in solving linear expressions and system equations of two variables. Remember to always bring constants to one side and simplify carefully!`;
  } else if (sub.includes("biol") || lowMsg.includes("cell") || lowMsg.includes("plant") || lowMsg.includes("nutrition")) {
    customAnswer = `In Grade ${grade} Biology, the cell is the essential building unit of life. Plant cells possess a dense cellulose wall, a large central sap vacuole, and green plastids called chloroplasts. 
Under nutrition, cells transport raw water and mineral food using dual specialized pathways: xylem handles transpiration, while phloem carries glucose syrup through translocation.`;
  } else if (sub.includes("phys") || lowMsg.includes("motion") || lowMsg.includes("force") || lowMsg.includes("speed")) {
    customAnswer = `In Grade ${grade} Physics, motion is defined as a continuous shift in an object's position coordinates. 
We distinguish between speed (scalar) and velocity (vector). Newton's Laws model all mechanical interactions:
1. Inertia: Objects resist sudden change.
2. F = m * a: Core acceleration proportion.
3. Action-Reaction: Dual equal opposite impact.`;
  } else if (sub.includes("chem") || lowMsg.includes("atom") || lowMsg.includes("bond") || lowMsg.includes("matter")) {
    customAnswer = `In Grade ${grade} Chemistry, all matter is made of tiny atoms consisting of three main structural units: protons (positive) and neutrons (neutral) in the nucleus, plus electrons (negative) orbiting in energy shells.
Periodic elements are structured sequentially according to their atomic number. Group placement corresponds directly to their count of valence bonding electrons.`;
  } else if (sub.includes("eng") || lowMsg.includes("grammar") || lowMsg.includes("tense")) {
    customAnswer = `In Grade ${grade} English, mastering primary tenses (Present Simple, Past Simple, Present Perfect) and structural voice transitions is crucial.
Always double check subject-verb agreement! For example, 'Each of the academic units has (not have) its own core worked question set.'`;
  } else if (sub.includes("geo") || lowMsg.includes("map") || lowMsg.includes("soil") || lowMsg.includes("ethiopia")) {
    customAnswer = `In Geography, we examine the physical structure of our earth. The Ethiopian highlands, rift valley structure, and diverse agro-ecological zones shape agricultural outputs.
Always practice reading topographic contour intervals to identify slopes and relief elevation correctly!`;
  } else if (sub.includes("his") || lowMsg.includes("battle") || lowMsg.includes("history")) {
    customAnswer = `In History, we study heroic timelines and crucial milestones, from our famous sovereign victory at Adwa to global geopolitical shifting eras.
Chronological visual mapping is key to tracking dates, treaties, and industrial transitions flawlessly.`;
  } else if (sub.includes("ict") || lowMsg.includes("computer") || lowMsg.includes("code") || lowMsg.includes("binary") || sub.includes("information")) {
    customAnswer = `In ICT/Computing, systems compute logic using binary signals (0 and 1 representation).
Data collections are structured in files or tables within relational databases. Programming is the systematic breakdown of problems into step-by-step algorithms.`;
  } else {
    customAnswer = `As your study guide, I recommend we review the core syllabus outline for Grade ${grade}. 
A solid approach is to study key terms sequentially, complete five short self-quiz problems daily, track your emotional mood, and record any equations in your notebook. Let's build your study readiness index high!`;
  }

  return `${teacherPrefix}
${customAnswer}

[CHECK] What specific sub-topic or exam question from this would you like us to explain further now? I'm listening.`;
}

app.post("/api/check-understanding", async (req, res) => {
  const { subUnitId, subUnitName, subjectName, studentExplanation, profile, checkType } = req.body;

  if (!studentExplanation) {
    res.status(400).json({ error: "Missing parameter: studentExplanation" });
    return;
  }

  try {
    const ai = getGeminiClient();
    const grade = profile?.grade || "9";
    const language = profile?.language || "English";
    const checkMode = checkType || "teachBack";

    const systemPrompt = `You are Fiy, an expert education evaluation system for high school students (Grade 9-12) in Ethiopia.
Your mission is to perform a strict but encouraging "Understanding Check" of a student's explanation of a lesson.
We do NOT want to mark a lesson as mastered merely because a student opened it. Mastery requires authentic proof of comprehension!

Analyze the student's text for:
1. Scientific accuracy (based on high school standard)
2. Conceptual depth vs. superficial/shallow memorization
3. Confidence Level (Does the student sound highly confident but have poor understanding, or are they unsure but accurate?)
4. Misconceptions: Detect common misconceptions (especially in Ethiopian High School Physics, Chemistry, Biology, Math, and English).

Check Mode requested: ${checkMode}

You MUST return your answer as a JSON object matching this exact TypeScript structure:
{
  "confidenceScore": "Low" | "Medium" | "High",
  "understandingScore": "Low" | "Medium" | "High",
  "detectedMisconception": {
    "name": "a brief simple name of the misconception",
    "correctedSimply": "a 1-2 sentence simple intuitive correction",
    "example": "a simple relatable real-world example",
    "checkQuestion": "A multiple choice question testing if they understand the correction. Output format must show a question testing the exact corrected concept, with clear choices and an answer index (0-3)."
  } | null,
  "passed": boolean, // true if understandingScore is "High" or "Medium"
  "gapReport": "A quick summary of what important details are missing from their explanation, or what was incorrect",
  "microCorrection": "A 1-3 sentence high-impact, encouraging, and accurate conceptual correction",
  "challengeQuestion": {
    "question": "A conceptual multiple-choice question to test transfer or application of knowledge",
    "options": ["Option A", "Option B", "Option C", "Option D"],
    "answerIndex": number, // 0-3
    "explanation": "Brief explanation of why this option is correct"
  },
  "feedbackText": "A warm, personal, encouraging response written entirely and grammatically perfect in ${language}. If language is Amharic, write in Amharic Ge'ez script. If Afaan Oromo, write in Afaan Oromo Qubee. NEVER mix languages in this text, and match the selected language strictly."
}

Ensure all texts are high quality, helpful, and never use shaming, insulting, or guilt-inducing words. Keep it motivational and focused on helping them learn!`;

    const prompt = `Student Profile: Grade ${grade}, Language: ${language}, Subject: ${subjectName || "General"}, Topic: ${subUnitName || "Syllabus topic"}.
Check Type Mode: ${checkMode}
Student's Typed or Spoken Explanation: "${studentExplanation}"`;

    const response = await generateContentWithFallback(ai, {
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json"
      }
    });

    const replyText = response?.text || "{}";
    let parsedResult;
    try {
      parsedResult = parseCleanJson(replyText);
    } catch (parseError) {
      console.warn("[FIYIT] parseCleanJson failed for check-understanding, applying robust fallback structure:", parseError);
      
      const isAmharic = language === "Amharic";
      const isOromo = language === "Oromo";
      
      parsedResult = {
        confidenceScore: "Medium",
        understandingScore: "Medium",
        detectedMisconception: null,
        passed: true,
        gapReport: isAmharic 
          ? "ስለ አስረዳዱ እናመሰግናለን! አንዳንድ ተጨማሪ ነጥቦችን በጋራ ማየት እንችላለን።" 
          : isOromo 
          ? "Ibsa keessaniif galatoomaa! Qabxiiwwan dabalataa waliin ilaaluu dandenya." 
          : "Thank you for explaining! Your concept is simple and clear. Let's practice some more questions together.",
        microCorrection: isAmharic
          ? "የሰጡት ማብራሪያ ጥሩ ግንዛቤ ያሳያል፤ ነገር ግን ትክክለኛውን ጽንሰ-ሀሳብ ይበልጥ ለማጠናከር ጥያቄዎችን እንለማመድ።"
          : isOromo
          ? "Garuu yaadota keessan caalaatti gabbisuuf gaaffiiwwan haa shaakallu."
          : "Your explanation shows solid initial work. Let's continue to practice interactive questions to form a robust foundation.",
        challengeQuestion: {
          question: isAmharic 
            ? "በዚህ ትምህርት ውስጥ ዋነኛው እና መሠረታዊው መነሻ ምንድን ነው?"
            : isOromo 
            ? "Barnoota kana keessatti inni bu'uuraa fi jalqabaa maali?"
            : "Which of the following describes the most important starting point of safety or precision in this topic?",
          options: isAmharic 
            ? ["ቁልፍ ትርጓሜዎችን በጥንቃቄ መረዳት", "አስቸጋሪ ጥያቄዎችን መተው", "ቀላል ነጥቦችን ብቻ ማጥናት", "ጥያቄዎችን አለመመለስ"]
            : isOromo
            ? ["Hiika bu'uuraa sirriitti hubachuu", "Gaaffilee dhiisuu", "Ibsa gabaabaa qofa gochuu", "Yaada dhiisuu"]
            : ["Carefully master key definitions", "Relying on initial practice", "Skipping advanced concepts", "Avoiding quizzes"],
          answerIndex: 0,
          explanation: isAmharic 
            ? "ውጤታማ ግንዛቤን ለመገንባት ሁልጊዜ መሠረታዊ የቃላት ትርጓሜዎች ቅድሚያ ሊሰጣቸው ይገባል።"
            : isOromo
            ? "Yaad-rimee sirrii ijaaruuf hiikni bu'uuraa dursa kennamuu qaba."
            : "Ensuring secure basic syntax/definition is always the robust foundation."
        },
        feedbackText: isAmharic 
          ? "ግሩም ጥረት ነው! ለበለጠ ጥንካሬ በጋራ ጥያቄዎችን መስራታችንን እንቀጥል።" 
          : isOromo 
          ? "Yaaliin keessan gaariidha! Caalaatti jabaachuuf waliin gaaffii hojjechuu haa fufnu." 
          : "Great effort explaining your thoughts! Let's continue our journey by tackling interactive test challenges together."
      };
    }
    res.json(parsedResult);
  } catch (err: any) {
    console.error("Error in check-understanding:", err);
    res.status(500).json({ error: err.message || "Failed to process understanding check." });
  }
});

app.post("/api/chat-coach", async (req, res) => {
  const { uid, message, profile, history, attachment, activeTeacherSubject, isVoiceMode } = req.body;

  if (!message) {
    res.status(400).json({ error: "Missing parameter: message" });
    return;
  }

  try {
    const ai = getGeminiClient();
    
    let currentSubject = "All";
    let currentUnit = "Syllabus Overview";
    let currentSubUnit = "";
    let learningReadinessScore = 70;

    if (uid) {
      try {
        const userDocRef = doc(db, "users", uid);
        const userDoc = await getDoc(userDocRef);
        if (userDoc.exists()) {
          const userData = userDoc.data();
          const firestoreProfile = userData?.fiyit_user_profile_v2 || {};
          if (firestoreProfile.currentSubject) currentSubject = firestoreProfile.currentSubject;
          if (firestoreProfile.currentUnit) currentUnit = firestoreProfile.currentUnit;
          if (firestoreProfile.currentSubUnit) currentSubUnit = firestoreProfile.currentSubUnit;
          if (firestoreProfile.learningReadinessScore !== undefined) {
            learningReadinessScore = firestoreProfile.learningReadinessScore;
          }
          console.log(`[FIYIT DB Sync] Fetched student context via Firestore server-side. Subject: ${currentSubject}, Unit: ${currentUnit}, Readiness: ${learningReadinessScore}`);
        }
      } catch (dbErr) {
        console.error("Failed to read user data from Firestore in chat-coach endpoint:", dbErr);
      }
    }

    // Construct personalization summary based on 18-question study preferences if present
    const prefsText = profile?.studyPreferences 
      ? `Student Preferences: ${JSON.stringify(profile.studyPreferences)} (visual/practice preference, weaknesses, confident subjects, coaching style tone targets)`
      : "No advanced preferences filled yet.";

    const selectedTeacher = getTeacherForSubject(activeTeacherSubject);
    const emotionalState = profile?.emotionalState || "Focused";

    const isProactiveStart = message === "PROACTIVE_START";
    const detectedUserLang = detectLanguageOfText(message || "");
    const profileLang = profile?.language || "English";
    
    // Fix Regression: Fall back to profileLang if detected language is English but onboarding is Oromo/Amharic.
    const responseLanguage = isProactiveStart 
      ? profileLang 
      : (detectedUserLang === "English" && profileLang !== "English" ? profileLang : detectedUserLang);

    let languagePromptInstruction = "";
    if (responseLanguage === "Amharic") {
      languagePromptInstruction = `
CRITICAL LANGUAGE REQUIREMENT:
The user is interacting in Amharic (አማርኛ). You MUST reply entirely in natural, native-sounding, grammatically correct Amharic written in the Ge'ez script. Do not write in English, and do not say you cannot speak Amharic. You are an expert Amharic speaker. Keep explanations high-quality and student-friendly. However, keep the subject teacher name (${selectedTeacher ? selectedTeacher.name : "Fiy"}) exactly as hardcoded and do not translate or transliterate it.`;
    } else if (responseLanguage === "Oromo") {
      languagePromptInstruction = `
CRITICAL LANGUAGE REQUIREMENT:
The user is interacting in Afaan Oromo. You MUST reply entirely in natural, native-sounding, grammatically correct Afaan Oromo using standard Qubee spelling. Do not write in English, and do not say you cannot speak Afaan Oromo. You are an expert Afaan Oromo speaker. Keep explanations high-quality and student-friendly. However, keep the subject teacher name (${selectedTeacher ? selectedTeacher.name : "Fiy"}) exactly as hardcoded and do not translate or transliterate it.`;
    } else {
      languagePromptInstruction = `
CRITICAL LANGUAGE REQUIREMENT:
Write your entire response in clear, fluent, natural English suitable for students.
Note: You are a fully multilingual study companion on the FIYIT platform and you are FULLY capable of understanding and speaking English, Amharic (አማርኛ), and Afaan Oromo (Oromiffa). NEVER claim you are English-only, or that you are not trained in Amharic or Afaan Oromo, or cannot speak them.
If the student asks you to translate, write, or speak in Amharic or Afaan Oromo (or if their messages shift to those languages mid-conversation), you MUST immediately output your response entirely in their requested language (Amharic written in Ge'ez, or Afaan Oromo written in standard Qubee spelling) to match their preference seamlessly!`;
    }

    let personaPrompt = "";
    if (selectedTeacher) {
      personaPrompt = `You are ${selectedTeacher.name}, the dedicated ${activeTeacherSubject} High School Teacher on the FIYIT platform.
Your distinct teaching style: ${selectedTeacher.style}.
Your bio: ${selectedTeacher.bio}.
Adhere strictly to this subject persona and educational style. Explain concepts relevant to Grade ${profile?.grade || "9"} ${activeTeacherSubject} curriculum in Ethiopia.
CRITICAL PERSONA CONSTANT:
The teacher for ${activeTeacherSubject} is ALWAYS named ${selectedTeacher.name} - never use any other name, in any language. Keep this name exactly in Latin characters, do not translate or transliterate it (e.g. keeping it as "${selectedTeacher.name}" even in Amharic or Afaan Oromo).`;
    } else {
      personaPrompt = `You are "Fiy", the permanent primary AI Companion, mentor, and academic advisor on the FIYIT study platform.
Your responsibility: Welcome the student warmly, check on their emotional states, adjust daily schedules, track their overall Readiness Score, offer guidance, and introduce subject teachers when they want to study specific topics. Speak with high companionship, encouragement, and emotional intelligence. Always refer to yourself as Fiy.`;
    }

    let voiceModePromptInstruction = "";
    if (isVoiceMode) {
      voiceModePromptInstruction = `
CRITICAL SPEAKING REQUIREMENT (LIVE VOICE MODE - CALL WITH THE STUDENT):
- You are speaking live on a voice call with the student (not writing an essay or textbook explanation).
- Keep your answer extremely short, concise, and natural - exactly 1 to 2 short conversational sentences (at most 15-25 words).
- Speak naturally and ask high-engagement questions, the way a real voice partner or mentor would talk on a phone, to check understanding or prompt conversation.
- Do NOT use bullet points, bolding, asterisks (*), markdown headers (#), lists, or structured formatting of any kind. Use ONLY plain text that can be spoken directly.
- NEVER use of any bracket tags like [CHECK], [BOOK], [STREAK], etc. during Live Voice Mode. Absolutely do not output them.
- If this is a PROACTIVE_START (student just clicked the call button), welcome them warmly by name (${profile?.name || "Ismael"}), state your role as ${selectedTeacher ? selectedTeacher.name : "Fiy"}, mention their grade (${profile?.grade || "9"}), and ask a dynamic proactive question to start the call! For example, say something like: "Hey ${profile?.name || "Ismael"}! Ready to talk about ${activeTeacherSubject || "your study habits"}? Let's discuss - want to practice or ask me a question?"`;
    }

    const systemPrompt = `${personaPrompt}

${isVoiceMode ? voiceModePromptInstruction : `Keep your responses extremely concise, punchy, and friendly. Limit answers to at most 1-2 small paragraphs in total (or 3-4 short bullet points if it's a list). Avoid writing long paragraphs or massive texts so they are fast to read, understand, and convert to voice!`}

${languagePromptInstruction}

CORE GREETING PREVENTION RULES:
- The student is already logged in and welcomed. Subsequent responses must respond DIRECTLY, concisely, and immediately to the student's question or message.
- You are STRIDENLTY PROHIBITED from repeating introductory welcome formulas or standard greetings (like "Greetings [Name]!", "Good morning!", "Let's unlock national curriculum excellence", "Hi [Name], how can I help you today?", "Let's unlock educational excellence today.") in every single turn of active chat.
- Act as an ongoing conversation participant - jump straight to the educational answer or study advice without stating repetitive salutations of any kind.

CRITICAL TEACHER CONSISTENCY & INTEGRITY RULES:
The hardcoded teacher lookup table in FIYIT consists of the following specific subject educators:
- Mathematics: Teacher Mufariat
- Biology: Teacher Tesfaye
- Physics: Teacher Hanan
- Chemistry: Teacher Biruk
- English: Teacher Nuri
- Geography: Teacher Wazir
- History: Teacher Bekele
- ICT: Teacher Ismael

These are the ONLY teacher names that exist in FIYIT. Never invent, suggest, hypothesize, or reference any other teacher name (e.g. NEVER mention "Ms. Anya Sharma", "Mrs. Smith", "Teacher Aster", or any other made-up names). Use these names EXACTLY as listed if you ever need to reference a teacher in any context.
If you are ever asked who is the teacher for any subject (even English, Physics, Maths, etc.), or if a student asks to be introduced to a teacher, you MUST answer with the exact correct hardcoded name from this list. 
If you are ever uncertain which teacher to reference, you must NOT invent a name. Instead, you must either:
(a) use the correct hardcoded name from this lookup table, or
(b) if somehow truly ambiguous, refer generically ("your English teacher", "your [Subject] teacher") WITHOUT stating any specific name.

CRITICAL STUDENT PERSONALIZATION RULES:
- The logged-in student's actual name is "${profile?.name && profile.name !== "Serious Student" ? profile.name : ""}".
- ALWAYS refer to the student by their actual name. If they have set a custom name (different from "Serious Student"), you MUST use it. If no custom name is set (i.e. if it is empty, null, or "Serious Student"), you are STRIDENLTY PROHIBITED from ever calling them "Serious Student"! Instead, address them generically (e.g., "student", "young scholar", or directly address them without any name header) rather than writing "Serious Student". "Serious Student" is a backend placeholder and must NEVER be printed in your conversational responses.

Student details (retrieved dynamically from Firestore database paths):
- Name: ${profile?.name || "Serious Student"}
- Grade: ${profile?.grade || "9"}
- Stream: ${profile?.stream || "General"}
- Primary Language: ${responseLanguage} (Detected/Preferred: ${responseLanguage})
- Current Emotional Vibe/State: ${emotionalState} (IMPORTANT: personalize your greeting and encouragement based on this mood. If they are tired, anxious, or overwhelmed, keep reminders extremely brief, low-pressure, and supportive. Focus on simple fundamental review points rather than massive blocks of text)
- Current Studying Subject: ${currentSubject}
- Current Studying Unit: ${currentUnit}
- Current Studying Sub-Unit: ${currentSubUnit}
- Learning Readiness Score: ${learningReadinessScore}%
- ${prefsText}

INSTRUCTIONS FOR ADAPTIVE DIFFICULTY:
- If the student's Learning Readiness Score is low (< 55%), adjust your difficulty to be highly supportive, using simpler words, breaking down complex mathematical or scientific expressions into simple real-life analogies, and pacing your feedback gently.
- If their Learning Readiness Score is high (> 75%), challenge them with advanced questions, assume firm mastery of basic terms, and ask conceptual transfer questions.
- Maintain your persona context but focus examples or discussions on their current studying topic: "${currentSubject} - ${currentUnit} (${currentSubUnit})".

${isVoiceMode ? "" : `Prohibited Output & Visual Emphasis Rules (Custom Icon System):
1. ZERO Unicode/system emojis anywhere in your responses (Fiy and teachers must NEVER output graphical/system emojis like 😀, 🔥, 📚, ✅, etc. - doing so breaks our branding).
2. NEVER use emoji characters or any Unicode symbols for expression.
3. When visual emphasis is wanted, use ONE of these exact bracket tags (max 1-2 per message, most messages need none):
   [STREAK] [BOOK] [TARGET] [TROPHY] [IDEA] [CHECK] [STAR] [ROCKET] [CLOCK] [PENCIL] [HEART] [TRENDING] [THUMBSUP] [BRAIN] [CELEBRATE] [ALARM]`}

Formatting Requirements (LaTeX/Math-Notation Warning):
Do not use LaTeX syntax in your responses (no dollar signs $, no \\frac, \\xrightarrow, \\text{}, ^{}, _{}, or similar LaTeX/markdown math commands). Write all chemical formulas, equations, and mathematical expressions using plain text with Unicode subscript/superscript characters where appropriate.

Examples of CORRECT formatting:
- H₂O (not $H_2O$)
- 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂ (not LaTeX equation blocks)
- x² + 5x + 6 = 0 (not $x^2 + 5x + 6=0$)

Use simple arrows (→), Unicode subscripts (₀₁₂₃₄₅₆₇₈₉), and Unicode superscripts (⁰¹²³⁴⁵⁶⁷⁸⁹) for all scientific notation.`;

    const userParts: any[] = [{ text: isProactiveStart ? "Greeting start" : message }];
    
    // Attach base64 image or PDF if present
    if (attachment && attachment.data && attachment.mimeType) {
      let base64Body = attachment.data;
      if (base64Body.includes(";base64,")) {
        base64Body = base64Body.split(";base64,")[1];
      }
      userParts.push({
        inlineData: {
          mimeType: attachment.mimeType,
          data: base64Body
        }
      });
    }

    // Construct high-reliability strictly-alternating contents for Gemini API
    const finalContents: any[] = [];
    const rawHistory = history || [];

    for (const h of rawHistory) {
      if (!h.text || !h.text.trim()) continue;
      const role = h.role === "model" ? "model" : "user";
      
      const lastItem = finalContents[finalContents.length - 1];
      if (lastItem && lastItem.role === role) {
        lastItem.parts[0].text += "\n" + h.text;
      } else {
        finalContents.push({
          role: role,
          parts: [{ text: h.text }]
        });
      }
    }

    // Always start with user
    while (finalContents.length > 0 && finalContents[0].role === "model") {
      finalContents.shift();
    }

    // Add current user prompt
    const lastItem = finalContents[finalContents.length - 1];
    if (lastItem && lastItem.role === "user") {
      // If last item in history was user, append new parts to it
      lastItem.parts[0].text += "\n" + (message || "");
      if (userParts.length > 1) {
        lastItem.parts.push(...userParts.slice(1));
      }
    } else {
      finalContents.push({
        role: "user",
        parts: userParts
      });
    }

    let replyText = "";
    let base64Audio = "";

    if (isVoiceMode) {
      try {
        // Resolve Voice name (same logic as TTS)
        let voiceName = "Kore";
        const isMaleTeacher = selectedTeacher && (
          selectedTeacher.name.includes("Alemu") ||
          selectedTeacher.name.includes("Tesfaye") ||
          selectedTeacher.name.includes("Biruk") ||
          selectedTeacher.name.includes("Dawit") ||
          selectedTeacher.name.includes("Bekele") ||
          selectedTeacher.name.includes("Samuel")
        );
        const isFemaleTeacher = selectedTeacher && (
          selectedTeacher.name.includes("Hana") ||
          selectedTeacher.name.includes("Ruth")
        );
        let finalGender = isMaleTeacher ? "male" : isFemaleTeacher ? "female" : "female";

        if (responseLanguage === "Oromo") {
          voiceName = finalGender === "female" ? "Kore" : "Fenrir";
        } else if (responseLanguage === "Amharic") {
          voiceName = finalGender === "female" ? "Kore" : "Zephyr";
        } else {
          voiceName = finalGender === "female" ? "Kore" : "Zephyr";
        }

        console.log(`[FIYIT Voice Mode] Requesting native conversational audio and text with model 'gemini-2.5-flash' using voice: ${voiceName}`);
        
        const voiceResponse = await ai.models.generateContent({
          model: "gemini-2.5-flash",
          contents: finalContents,
          config: {
            systemInstruction: systemPrompt,
            responseModalities: ["TEXT", "AUDIO"],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: { voiceName: voiceName }
              }
            }
          }
        });

        const textPart = voiceResponse.candidates?.[0]?.content?.parts?.find(p => p.text);
        replyText = textPart?.text || voiceResponse.text || "";

        const audioPart = voiceResponse.candidates?.[0]?.content?.parts?.find(p => p.inlineData && p.inlineData.mimeType?.startsWith("audio/"));
        if (audioPart?.inlineData?.data) {
          const pcmBuffer = Buffer.from(audioPart.inlineData.data, "base64");
          const wavBuffer = prependWavHeader(pcmBuffer, 24000);
          base64Audio = wavBuffer.toString("base64");
          console.log(`[FIYIT Voice Mode] Successfully generated both text reply and native WAV audio in a single call`);
        }
      } catch (voiceErr) {
        console.warn("[FIYIT Voice Mode] Native audio generation failed, falling back to standard text-only:", voiceErr);
        // Reset to let standard generation handle it
        replyText = "";
        base64Audio = "";
      }
    }

    if (!replyText) {
      const response = await generateContentWithFallback(ai, {
        contents: finalContents,
        config: {
          systemInstruction: systemPrompt
        }
      });
      replyText = response.text || "";
    }

    res.json({ reply: replyText, audio: base64Audio || undefined });
  } catch (error: any) {
    console.error("Gemini chat coach error detail:", error);
    
    // Dynamically retrieve high-companionship offline tutor feedback
    const offlineReply = generateOfflineCoachReply(
      message || "",
      profile,
      activeTeacherSubject || ""
    );
    
    res.json({ reply: offlineReply });
  }
});

// Helper to prepend a WAV header to raw PCM data so standard HTML5 Audio can play it in any browser
function prependWavHeader(pcmBuffer: Buffer, sampleRate: number = 24000): Buffer {
  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8; // 48000
  const blockAlign = (numChannels * bitsPerSample) / 8; // 2
  const dataSize = pcmBuffer.length;
  const chunkSize = 36 + dataSize;

  const header = Buffer.alloc(44);

  // RIFF identifier
  header.write("RIFF", 0);
  // file length minus RIFF and WAVE headers
  header.writeUInt32LE(chunkSize, 4);
  // RIFF type
  header.write("WAVE", 8);
  // format chunk identifier
  header.write("fmt ", 12);
  // format chunk length
  header.writeUInt32LE(16, 16);
  // sample format (raw PCM is 1)
  header.writeUInt16LE(1, 20);
  // channel count
  header.writeUInt16LE(numChannels, 22);
  // sample rate
  header.writeUInt32LE(sampleRate, 24);
  // byte rate
  header.writeUInt32LE(byteRate, 28);
  // block align
  header.writeUInt16LE(blockAlign, 32);
  // bits per sample
  header.writeUInt16LE(bitsPerSample, 34);
  // data chunk identifier
  header.write("data", 36);
  // chunk length
  header.writeUInt32LE(dataSize, 40);

  return Buffer.concat([header, pcmBuffer]);
}

// Globally bounded in-memory cache for TTS to keep voice answers immediately responsive
const ttsCache = new Map<string, string>();
const MAX_TTS_CACHE_SIZE = 150;

// Text-to-Speech API proxy endpoint using gemini-3.1-flash-tts-preview
app.post("/api/tts", async (req, res) => {
  const { text, speakerName, language, gender } = req.body;

  if (!text) {
    res.status(400).json({ error: "Missing parameter: text" });
    return;
  }

  try {
    const ai = getGeminiClient();
    
    // Auto-detect language of the text to be spoken
    const detectedLang = detectLanguageOfText(text || "");
    const finalLang = (detectedLang === "English" && (language === "Amharic" || language === "Oromo")) 
      ? language 
      : detectedLang;

    // Default voice genders
    let finalGender = gender || "female";
    
    // If it's a known male teacher, ensure we use a male voice output
    const lowSpeaker = (speakerName || "").toLowerCase();
    const isMaleTeacher = lowSpeaker.includes("alemu") || lowSpeaker.includes("tesfaye") || lowSpeaker.includes("biruk") || lowSpeaker.includes("dawit") || lowSpeaker.includes("bekele") || lowSpeaker.includes("samuel");
    const isFemaleTeacher = lowSpeaker.includes("hana") || lowSpeaker.includes("ruth");
    
    if (isMaleTeacher) {
      finalGender = "male";
    } else if (isFemaleTeacher) {
      finalGender = "female";
    }

    let voiceName = "Kore"; // default female voice actor - Kore
    let systemInstruction = "Read the provided text in crystal clear English. Adopt a warm, pleasant female voice suitable for students. Speak slowly and clearly. Pronounce every word cleanly with no glitching. Do not read any bracket tags like [TROPHY], only read conversational words.";

    if (finalLang === "Oromo") {
      // Afaan Oromo is a male with deep voice
      voiceName = "Fenrir"; // deep male voice
      systemInstruction = "Read the provided text in crystal clear Afaan Oromoo. Adopt a deep, friendly, masculine, easy-to-understand deep vocal tone suitable for Ethiopian students. Speak slowly and pronounce every word cleanly with no glitching. Do not read any brackets, tags or formatting, just read the words aloud.";
      
      if (finalGender === "female") {
        voiceName = "Kore"; // simple friendly female fallback
        systemInstruction = "Read the provided text in crystal clear Afaan Oromoo. Adopt a friendly, warm female voice. Speak slowly and naturally. Do not read brackets, tags, or formatting, just read the words out loud.";
      }
    } else if (finalLang === "Amharic") {
      if (finalGender === "female") {
        // Amharic female voice is a woman with a simple, clear voice who is easy to understand
        voiceName = "Kore";
        systemInstruction = "Read the provided text in crystal clear Amharic. Adopt a simple, friendly, warm female voice. Speak slowly, naturally and with high clarity. Do not read any brackets, tags, or formatting, just read the words aloud.";
      } else {
        // Amharic male voice is a male with a thick, understandable, and clear voice resembling Gemini's official voice actor
        voiceName = "Zephyr"; // clear, warm, thick, understandable male voice actor
        systemInstruction = "Read the provided text in crystal clear Amharic. Adopt a thick, masculine, highly understandable and perfectly clear male voice, resembling Gemini's official voice actor. Speak slowly, naturally and with perfect clarity. Do not read any brackets, tags, or formatting, just read the words aloud.";
      }
    } else {
      // English
      if (finalGender === "male") {
        voiceName = "Zephyr";
        systemInstruction = "Read the provided text in crystal clear English. Adopt a thick, masculine, clear and understandable voice. Speak slowly, naturally, and with high clarity. Do not read any brackets, tags, or formatting, just read the words aloud.";
      } else {
        voiceName = "Kore";
        systemInstruction = "Read the provided text in crystal clear English. Adopt a simple, warm, clear female voice. Speak slowly, naturally, and with high clarity. Do not read any brackets, tags, or formatting, just read the words aloud.";
      }
    }

    // Sanitize text: strip out our custom bracket tags for TTS, markdown layout, bullet points stars to prevent verbal glitch
    let cleanTtsText = text
      .replace(/\[[A-Z0-9_\-]+\]/gi, "")
      .replace(/\*\*/g, "")
      .replace(/\*/g, "")
      .replace(/#/g, "")
      .replace(/`/g, "")
      .trim();

    // Check high-speed cache
    const cacheKey = `${voiceName}:${cleanTtsText}`;
    if (ttsCache.has(cacheKey)) {
      res.json({ audio: ttsCache.get(cacheKey) });
      return;
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [{ parts: [{ text: cleanTtsText }] }],
      config: {
        responseModalities: ["AUDIO"],
        systemInstruction: systemInstruction,
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceName }
          }
        }
      }
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      const pcmBuffer = Buffer.from(base64Audio, "base64");
      const wavBuffer = prependWavHeader(pcmBuffer, 24000);
      const base64Wav = wavBuffer.toString("base64");
      
      // Save to Bounded Cache to skip API calls next turn
      if (ttsCache.size >= MAX_TTS_CACHE_SIZE) {
        const oldestKey = ttsCache.keys().next().value;
        if (oldestKey !== undefined) {
          ttsCache.delete(oldestKey);
        }
      }
      ttsCache.set(cacheKey, base64Wav);

      res.json({ audio: base64Wav });
    } else {
      res.status(500).json({ error: "No audio generated from Google GenAI model" });
    }
  } catch (error: any) {
    console.error("Gemini TTS generator error:", error);
    const errMsg = String(error?.message || error || "").toLowerCase();
    if (errMsg.includes("quota") || errMsg.includes("limit") || errMsg.includes("429") || errMsg.includes("resource_exhausted")) {
      res.status(429).json({ error: "TTS free tier limit reached, activating premium offline voice fallback" });
    } else {
      res.status(500).json({ error: error.message || String(error) });
    }
  }
});


// --- VITE DEV / PROD SETUP ---
async function startServer() {
  const distPath = path.join(process.cwd(), "dist");
  const hasDist = fs.existsSync(path.join(distPath, "index.html"));

  if (process.env.NODE_ENV !== "production" || !hasDist) {
    console.log("Setting up Vite compilation middleware...");
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);

    // Dynamic fallback for dev mode to ensure any client-side route displays the main applet index
    app.get("*", async (req, res, next) => {
      if (req.url.startsWith("/api/")) {
        return next();
      }
      try {
        let template = fs.readFileSync(path.resolve(process.cwd(), "index.html"), "utf-8");
        template = await vite.transformIndexHtml(req.url, template);
        res.status(200).set({ "Content-Type": "text/html" }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    console.log("Serving static production assets...");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[FIYIT Engine] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
