/**
 * FIYIT Cloudflare Worker Proxy
 * ----------------------------
 * Copy and paste this file into your Cloudflare Worker.
 * Put your GEMINI_API_KEY as an Environment Variable secret in your Cloudflare dashboard.
 *
 * This Worker acts as a secure, fast API proxy. It prevents exposure of your secret
 * Gemini API Key inside client-side JS on GitHub Pages and runs completely on Cloudflare's edge!
 */

export default {
  async fetch(request, env, ctx) {
    // 1. Handle CORS Preflight request
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*", // Or specify exact GitHub Pages URL
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, {
        headers: corsHeaders,
      });
    }

    const url = new URL(request.url);

    // Only allow POST requests for safety
    if (request.method !== "POST") {
      return new Response(JSON.stringify({ error: "Only POST requests are permitted." }), {
        status: 405,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    try {
      const apiKey = env.GEMINI_API_KEY;
      if (!apiKey) {
        return new Response(JSON.stringify({ error: "Worker database secret GEMINI_API_KEY is missing." }), {
          status: 500,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        });
      }

      const body = await request.json();
      const { type, ...payload } = body; // type is "lesson" or "quiz"

      let prompt = "";

      if (type === "lesson") {
        const { subject, unit, subUnit, grade, stream } = payload;
        const streamText = stream ? `(${stream} Stream)` : "";
        prompt = `You are a professional, motivating Ethiopian High School educator and Study Coach.
Generate a structured, curriculum-appropriate lesson content for:
- Grade: ${grade}
- Subject: ${subject} ${streamText}
- Unit: ${unit}
- Sub-unit / Lesson Title: ${subUnit}

Your response must be RAW JSON match this exact structure:
{
  "explanation": "Detailed study notes...",
  "formula": "Crucial mathematical formula...",
  "workedExample": { "problem": "...", "solution": "..." },
  "keyPoints": ["...", "...", "..."]
}`;
      } else if (type === "quiz") {
        const { subject, unit, subUnit, grade, stream, lessonContent } = payload;
        const streamText = stream ? `(${stream} Stream)` : "";
        prompt = `You are a professional high school examiner for the Ethiopian Ministry of Education.
Generate an interactive multiple-choice practice quiz with exactly 5 questions based on this content: ${JSON.stringify(lessonContent || {})} for ${subUnit} (${subject} Grade ${grade} ${streamText}).

Your response must be RAW JSON matching this structure:
{
  "questions": [
    {
      "id": "q1",
      "question": "...",
      "options": ["A", "B", "C", "D"],
      "answerIndex": 0,
      "explanation": "..."
    }
  ]
}`;
      } else {
        return new Response(JSON.stringify({ error: "Invalid generate type. Must be 'lesson' or 'quiz'" }), {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        });
      }

      // Call Google Gemini API
      const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${apiKey}`;

      const geminiResponse = await fetch(geminiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "User-Agent": "aistudio-build",
        },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            responseMimeType: "application/json",
          },
        }),
      });

      const data = await geminiResponse.json();
      
      // Parse out the text response block from Gemini return structure
      const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text || "{}";
      
      return new Response(rawText, {
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      });

    } catch (e) {
      return new Response(JSON.stringify({ error: e.message || String(e) }), {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }
  },
};
