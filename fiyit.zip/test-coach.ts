import fetch from 'node-fetch';

async function test() {
  try {
    const payload = {
      message: "Hey can you tell me about cells?",
      profile: { name: "Ismael", grade: "9", language: "English" },
      history: [
        { role: "model", text: "Hi Ismael! I am Fiy, your permanent AI Study Companion..." }
      ]
    };
    
    console.log("Sending request to http://localhost:3000/api/chat-coach...");
    const response = await fetch("http://localhost:3000/api/chat-coach", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    
    console.log("Status:", response.status);
    const data = await response.text();
    console.log("Response Body:", data);
  } catch (err: any) {
    console.error("Test execution failed:", err.message);
  }
}

test();
