import fs from 'fs';

const makeSkillSubunits = (unitId) => [
  { id: `${unitId}-s1`, name: "Listening and Speaking" },
  { id: `${unitId}-s2`, name: "Reading Comprehension" },
  { id: `${unitId}-s3`, name: "Vocabulary and Grammar" },
  { id: `${unitId}-s4`, name: "Writing" },
];

const data = [
      {
        id: "g9-math",
        name: "Mathematics",
        units: [
          {
            id: "g9-math-u1",
            name: "Further on Sets",
            subUnits: [
              { id: "g9-math-u1-s1", name: "Ideas of Sets" },
              { id: "g9-math-u1-s2", name: "Operations on Sets" },
              { id: "g9-math-u1-s3", name: "Venn Diagrams" },
              { id: "g9-math-u1-s4", name: "Applications of Sets" },
            ],
          },
          {
            id: "g9-math-u2",
            name: "The Number System",
            subUnits: [
              { id: "g9-math-u2-s1", name: "Revision on Rational Numbers" },
              { id: "g9-math-u2-s2", name: "Irrational Numbers" },
              { id: "g9-math-u2-s3", name: "The Real Number System" },
              { id: "g9-math-u2-s4", name: "Significant Figures and Rounding" },
            ],
          },
          {
            id: "g9-math-u3",
            name: "Solving Equations",
            subUnits: [
              { id: "g9-math-u3-s1", name: "Equations Involving Exponents and Radicals" },
              { id: "g9-math-u3-s2", name: "Systems of Linear Equations" },
              { id: "g9-math-u3-s3", name: "Equations Involving Absolute Value" },
              { id: "g9-math-u3-s4", name: "Quadratic Equations" },
            ],
          },
          {
            id: "g9-math-u4",
            name: "Solving Inequalities",
            subUnits: [
              { id: "g9-math-u4-s1", name: "Linear Inequalities" },
              { id: "g9-math-u4-s2", name: "Systems of Linear Inequalities" },
              { id: "g9-math-u4-s3", name: "Inequalities Involving Absolute Value" },
              { id: "g9-math-u4-s4", name: "Quadratic Inequalities" },
            ],
          },
          {
            id: "g9-math-u5",
            name: "Introduction to Trigonometry",
            subUnits: [
              { id: "g9-math-u5-s1", name: "Basic Trigonometric Ratios" },
              { id: "g9-math-u5-s2", name: "Trigonometric Values of Special Angles" },
              { id: "g9-math-u5-s3", name: "Solving Right-Angled Triangles" },
              { id: "g9-math-u5-s4", name: "Applications of Trigonometry" },
            ],
          },
          {
            id: "g9-math-u6",
            name: "Regular Polygons",
            subUnits: [
              { id: "g9-math-u6-s1", name: "Properties of Regular Polygons" },
              { id: "g9-math-u6-s2", name: "Interior and Exterior Angles" },
              { id: "g9-math-u6-s3", name: "Perimeter and Area of Regular Polygons" },
            ],
          },
          {
            id: "g9-math-u7",
            name: "Congruency and Similarity",
            subUnits: [
              { id: "g9-math-u7-s1", name: "Congruency of Triangles" },
              { id: "g9-math-u7-s2", name: "Similarity of Triangles" },
              { id: "g9-math-u7-s3", name: "Theorems on Similar Figures" },
              { id: "g9-math-u7-s4", name: "Applications of Similarity" },
            ],
          },
          {
            id: "g9-math-u8",
            name: "Vectors in Two Dimensions",
            subUnits: [
              { id: "g9-math-u8-s1", name: "Scalar and Vector Quantities" },
              { id: "g9-math-u8-s2", name: "Representation of Vectors" },
              { id: "g9-math-u8-s3", name: "Operations on Vectors" },
              { id: "g9-math-u8-s4", name: "Position Vectors" },
            ],
          },
          {
            id: "g9-math-u9",
            name: "Statistics and Probability",
            subUnits: [
              { id: "g9-math-u9-s1", name: "Collection and Presentation of Data" },
              { id: "g9-math-u9-s2", name: "Measures of Central Tendency and Dispersion" },
              { id: "g9-math-u9-s3", name: "Basic Probability Concepts" },
              { id: "g9-math-u9-s4", name: "Probability of Events" },
            ],
          },
        ],
      },
      {
        id: "g9-phy",
        name: "Physics",
        units: [
          {
            id: "g9-phy-u1",
            name: "Introduction to Physics",
            subUnits: [
              { id: "g9-phy-u1-s1", name: "Definition and Nature of Physics" },
              { id: "g9-phy-u1-s2", name: "Branches of Physics" },
              { id: "g9-phy-u1-s3", name: "Relationship with Other Sciences" },
            ],
          },
          {
            id: "g9-phy-u2",
            name: "Physical Quantities and Measurement",
            subUnits: [
              { id: "g9-phy-u2-s1", name: "Fundamental and Derived Quantities" },
              { id: "g9-phy-u2-s2", name: "SI Units and Unit Conversion" },
              { id: "g9-phy-u2-s3", name: "Measurement and Uncertainty" },
            ],
          },
          {
            id: "g9-phy-u3",
            name: "Motion, Force, Work, Energy and Power",
            subUnits: [
              { id: "g9-phy-u3-s1", name: "Motion in a Straight Line" },
              { id: "g9-phy-u3-s2", name: "Newton's Laws of Motion" },
              { id: "g9-phy-u3-s3", name: "Work, Energy and Power" },
            ],
          },
          {
            id: "g9-phy-u4",
            name: "Simple Machines",
            subUnits: [
              { id: "g9-phy-u4-s1", name: "Purpose and Types of Simple Machines" },
              { id: "g9-phy-u4-s2", name: "Mechanical Advantage and Efficiency" },
              { id: "g9-phy-u4-s3", name: "Levers, Inclined Planes and Pulleys" },
            ],
          },
          {
            id: "g9-phy-u5",
            name: "Fluid Statics",
            subUnits: [
              { id: "g9-phy-u5-s1", name: "Air Pressure" },
              { id: "g9-phy-u5-s2", name: "Fluid Pressure" },
              { id: "g9-phy-u5-s3", name: "Applications of Fluid Statics" },
            ],
          },
          {
            id: "g9-phy-u6",
            name: "Heat and Temperature",
            subUnits: [
              { id: "g9-phy-u6-s1", name: "Temperature and Heat Energy" },
              { id: "g9-phy-u6-s2", name: "Thermal Expansion" },
              { id: "g9-phy-u6-s3", name: "Specific Heat Capacity and Change of State" },
            ],
          },
          {
            id: "g9-phy-u7",
            name: "Wave Motion and Sound",
            subUnits: [
              { id: "g9-phy-u7-s1", name: "Wave Propagation" },
              { id: "g9-phy-u7-s2", name: "Properties of Mechanical Waves" },
              { id: "g9-phy-u7-s3", name: "Sound Waves" },
            ],
          },
        ],
      },
      {
        id: "g9-che",
        name: "Chemistry",
        units: [
          {
            id: "g9-che-u1",
            name: "Chemistry and Its Importance",
            subUnits: [
              { id: "g9-che-u1-s1", name: "Definition and Scope of Chemistry" },
              { id: "g9-che-u1-s2", name: "Relationship Between Chemistry and Other Natural Sciences" },
              { id: "g9-che-u1-s3", name: "Role of Chemistry in Production and Society" },
              { id: "g9-che-u1-s4", name: "Common Chemical Industries in Ethiopia" },
            ],
          },
          {
            id: "g9-che-u2",
            name: "Measurements and Scientific Methods",
            subUnits: [
              { id: "g9-che-u2-s1", name: "Measurements and Units in Chemistry" },
              { id: "g9-che-u2-s2", name: "Chemistry as Experimental Science" },
            ],
          },
          {
            id: "g9-che-u3",
            name: "Structure of the Atom",
            subUnits: [
              { id: "g9-che-u3-s1", name: "Historical Development of Atomic Theories" },
              { id: "g9-che-u3-s2", name: "Fundamental Laws of Chemical Reactions" },
              { id: "g9-che-u3-s3", name: "Atomic Theory" },
              { id: "g9-che-u3-s4", name: "Discovery of Subatomic Particles and the Nucleus" },
              { id: "g9-che-u3-s5", name: "Composition of an Atom and Isotopes" },
            ],
          },
          {
            id: "g9-che-u4",
            name: "Periodic Classification of Elements",
            subUnits: [
              { id: "g9-che-u4-s1", name: "Historical Development of Periodic Classification" },
              { id: "g9-che-u4-s2", name: "Mendeleev's Classification" },
              { id: "g9-che-u4-s3", name: "The Modern Periodic Table" },
              { id: "g9-che-u4-s4", name: "Periodic Trends and Properties" },
            ],
          },
          {
            id: "g9-che-u5",
            name: "Chemical Bonding",
            subUnits: [
              { id: "g9-che-u5-s1", name: "Ionic Bonding" },
              { id: "g9-che-u5-s2", name: "Covalent Bonding" },
              { id: "g9-che-u5-s3", name: "Metallic Bonding" },
              { id: "g9-che-u5-s4", name: "Bond Polarity and Molecular Shape" },
            ],
          },
        ],
      },
      {
        id: "g9-bio",
        name: "Biology",
        units: [
          {
            id: "g9-bio-u1",
            name: "Introduction to Biology",
            subUnits: [
              { id: "g9-bio-u1-s1", name: "Definition, Scope and Branches of Biology" },
              { id: "g9-bio-u1-s2", name: "Importance of Biology" },
              { id: "g9-bio-u1-s3", name: "Scientific Methods in Biology" },
            ],
          },
          {
            id: "g9-bio-u2",
            name: "Characteristics and Classification of Organisms",
            subUnits: [
              { id: "g9-bio-u2-s1", name: "Characteristics of Living Things" },
              { id: "g9-bio-u2-s2", name: "Classification Systems" },
              { id: "g9-bio-u2-s3", name: "Kingdom Classification" },
              { id: "g9-bio-u2-s4", name: "Binomial Nomenclature" },
            ],
          },
          {
            id: "g9-bio-u3",
            name: "Cells",
            subUnits: [
              { id: "g9-bio-u3-s1", name: "Cell Theory" },
              { id: "g9-bio-u3-s2", name: "Prokaryotic and Eukaryotic Cells" },
              { id: "g9-bio-u3-s3", name: "Cell Organelles and Functions" },
              { id: "g9-bio-u3-s4", name: "Cell Division" },
            ],
          },
          {
            id: "g9-bio-u4",
            name: "Reproduction",
            subUnits: [
              { id: "g9-bio-u4-s1", name: "Asexual Reproduction" },
              { id: "g9-bio-u4-s2", name: "Sexual Reproduction" },
              { id: "g9-bio-u4-s3", name: "Reproduction in Plants" },
              { id: "g9-bio-u4-s4", name: "Reproduction in Animals" },
            ],
          },
          {
            id: "g9-bio-u5",
            name: "Human Health, Nutrition, and Disease",
            subUnits: [
              { id: "g9-bio-u5-s1", name: "Nutrition and Balanced Diet" },
              { id: "g9-bio-u5-s2", name: "Human Health and Hygiene" },
              { id: "g9-bio-u5-s3", name: "Communicable and Non-Communicable Diseases" },
              { id: "g9-bio-u5-s4", name: "HIV/AIDS and Other STIs" },
            ],
          },
          {
            id: "g9-bio-u6",
            name: "Ecology",
            subUnits: [
              { id: "g9-bio-u6-s1", name: "Ecosystem Concepts" },
              { id: "g9-bio-u6-s2", name: "Energy Flow and Food Chains" },
              { id: "g9-bio-u6-s3", name: "Biogeochemical Cycles" },
              { id: "g9-bio-u6-s4", name: "Human Impact on the Environment" },
            ],
          },
        ],
      },
      {
        id: "g9-eng",
        name: "English",
        units: [
          { id: "g9-eng-u1", name: "Living in Urban Areas", subUnits: makeSkillSubunits("g9-eng-u1") },
          { id: "g9-eng-u2", name: "Study Skills", subUnits: makeSkillSubunits("g9-eng-u2") },
          { id: "g9-eng-u3", name: "Traffic Accident", subUnits: makeSkillSubunits("g9-eng-u3") },
          { id: "g9-eng-u4", name: "National Parks", subUnits: makeSkillSubunits("g9-eng-u4") },
          { id: "g9-eng-u5", name: "Horticulture", subUnits: makeSkillSubunits("g9-eng-u5") },
          { id: "g9-eng-u6", name: "Poverty in Ethiopia", subUnits: makeSkillSubunits("g9-eng-u6") },
          { id: "g9-eng-u7", name: "Community Services", subUnits: makeSkillSubunits("g9-eng-u7") },
          { id: "g9-eng-u8", name: "Communicable Diseases", subUnits: makeSkillSubunits("g9-eng-u8") },
          { id: "g9-eng-u9", name: "Fairness and Equity", subUnits: makeSkillSubunits("g9-eng-u9") },
          { id: "g9-eng-u10", name: "The Internet", subUnits: makeSkillSubunits("g9-eng-u10") },
        ],
      },
      {
        id: "g9-his",
        name: "History",
        units: [
          {
            id: "g9-his-u1",
            name: "History, Historiography and Human Evolution",
            subUnits: [
              { id: "g9-his-u1-s1", name: "Meaning and Importance of History" },
              { id: "g9-his-u1-s2", name: "Sources and Methods of History" },
              { id: "g9-his-u1-s3", name: "Origins and Evolution of Humankind" },
            ],
          },
          {
            id: "g9-his-u2",
            name: "Ancient Civilizations of the World",
            subUnits: [
              { id: "g9-his-u2-s1", name: "Civilizations of the Near East" },
              { id: "g9-his-u2-s2", name: "Civilizations of Asia" },
              { id: "g9-his-u2-s3", name: "Civilizations of the Mediterranean" },
            ],
          },
          {
            id: "g9-his-u3",
            name: "Peoples and States of Ancient Ethiopia and the Horn",
            subUnits: [
              { id: "g9-his-u3-s1", name: "Early Peoples and Settlements" },
              { id: "g9-his-u3-s2", name: "Ancient States of the Region" },
              { id: "g9-his-u3-s3", name: "Cultural and Economic Foundations" },
            ],
          },
          {
            id: "g9-his-u4",
            name: "Peoples and States of Africa",
            subUnits: [
              { id: "g9-his-u4-s1", name: "Early African Societies" },
              { id: "g9-his-u4-s2", name: "Ancient and Medieval African States" },
              { id: "g9-his-u4-s3", name: "Trade and Exchange in Africa" },
            ],
          },
          {
            id: "g9-his-u5",
            name: "Africa and the Outside World",
            subUnits: [
              { id: "g9-his-u5-s1", name: "Early Contacts with the Outside World" },
              { id: "g9-his-u5-s2", name: "Trade Relations" },
              { id: "g9-his-u5-s3", name: "Cultural Exchanges" },
            ],
          },
          {
            id: "g9-his-u6",
            name: "The Middle Ages",
            subUnits: [
              { id: "g9-his-u6-s1", name: "Political Developments in the Middle Ages" },
              { id: "g9-his-u6-s2", name: "Society and Economy" },
              { id: "g9-his-u6-s3", name: "Religion and Culture" },
            ],
          },
          {
            id: "g9-his-u7",
            name: "States, Principalities and Population Movements in Ethiopia",
            subUnits: [
              { id: "g9-his-u7-s1", name: "Political Fragmentation" },
              { id: "g9-his-u7-s2", name: "Population Movements" },
              { id: "g9-his-u7-s3", name: "Regional States and Principalities" },
            ],
          },
          {
            id: "g9-his-u8",
            name: "The Early Modern World",
            subUnits: [
              { id: "g9-his-u8-s1", name: "Exploration and Globalization" },
              { id: "g9-his-u8-s2", name: "Renaissance and Reformation" },
              { id: "g9-his-u8-s3", name: "Rise of Early Modern States" },
            ],
          },
          {
            id: "g9-his-u9",
            name: "The Age of Revolutions",
            subUnits: [
              { id: "g9-his-u9-s1", name: "The Industrial Revolution" },
              { id: "g9-his-u9-s2", name: "Political Revolutions" },
              { id: "g9-his-u9-s3", name: "Impacts of the Age of Revolutions" },
            ],
          },
        ],
      },
      {
        id: "g9-geo",
        name: "Geography",
        units: [
          {
            id: "g9-geo-u1",
            name: "Introduction to Geography and Location of Ethiopia",
            subUnits: [
              { id: "g9-geo-u1-s1", name: "Meaning, Scope and Branches of Geography" },
              { id: "g9-geo-u1-s2", name: "Location, Size and Shape of Ethiopia" },
              { id: "g9-geo-u1-s3", name: "Effects of Location and Size on Ethiopia" },
            ],
          },
          {
            id: "g9-geo-u2",
            name: "Geological History and Landforms of Ethiopia",
            subUnits: [
              { id: "g9-geo-u2-s1", name: "Geological History of Ethiopia" },
              { id: "g9-geo-u2-s2", name: "Major Landform Regions" },
              { id: "g9-geo-u2-s3", name: "Factors Shaping Ethiopian Landforms" },
            ],
          },
          {
            id: "g9-geo-u3",
            name: "Drainage Systems of Ethiopia",
            subUnits: [
              { id: "g9-geo-u3-s1", name: "Major River Basins of Ethiopia" },
              { id: "g9-geo-u3-s2", name: "Lakes of Ethiopia" },
              { id: "g9-geo-u3-s3", name: "Importance of Drainage Systems" },
            ],
          },
          {
            id: "g9-geo-u4",
            name: "Climate of Ethiopia",
            subUnits: [
              { id: "g9-geo-u4-s1", name: "Factors Affecting Ethiopian Climate" },
              { id: "g9-geo-u4-s2", name: "Climate Classification of Ethiopia" },
              { id: "g9-geo-u4-s3", name: "Seasons and Rainfall Patterns" },
            ],
          },
          {
            id: "g9-geo-u5",
            name: "Natural Vegetation and Wildlife of Ethiopia",
            subUnits: [
              { id: "g9-geo-u5-s1", name: "Vegetation Zones of Ethiopia" },
              { id: "g9-geo-u5-s2", name: "Wildlife and Biodiversity" },
              { id: "g9-geo-u5-s3", name: "Conservation of Natural Resources" },
            ],
          },
          {
            id: "g9-geo-u6",
            name: "Soil and Mineral Resources of Ethiopia",
            subUnits: [
              { id: "g9-geo-u6-s1", name: "Major Soil Types of Ethiopia" },
              { id: "g9-geo-u6-s2", name: "Mineral Resources and Their Distribution" },
              { id: "g9-geo-u6-s3", name: "Resource Management Challenges" },
            ],
          },
          {
            id: "g9-geo-u7",
            name: "Population of Ethiopia",
            subUnits: [
              { id: "g9-geo-u7-s1", name: "Population Size, Growth and Distribution" },
              { id: "g9-geo-u7-s2", name: "Population Composition" },
              { id: "g9-geo-u7-s3", name: "Population Policy in Ethiopia" },
            ],
          },
          {
            id: "g9-geo-u8",
            name: "Economic Activities of Ethiopia",
            subUnits: [
              { id: "g9-geo-u8-s1", name: "Agriculture in Ethiopia" },
              { id: "g9-geo-u8-s2", name: "Industry and Manufacturing" },
              { id: "g9-geo-u8-s3", name: "Trade, Tourism and Services" },
            ],
          },
        ],
      },
      {
        id: "g9-cve",
        name: "Citizenship Education",
        units: [
          {
            id: "g9-cve-u1",
            name: "Ethical Values",
            subUnits: [
              { id: "g9-cve-u1-s1", name: "Meaning and Importance of Ethics" },
              { id: "g9-cve-u1-s2", name: "Major Ethical Values" },
              { id: "g9-cve-u1-s3", name: "Ethical Values in the Ethiopian Context" },
            ],
          },
          {
            id: "g9-cve-u2",
            name: "Culture of Using Digital Technology",
            subUnits: [
              { id: "g9-cve-u2-s1", name: "Digital Citizenship" },
              { id: "g9-cve-u2-s2", name: "Benefits and Risks of Technology" },
              { id: "g9-cve-u2-s3", name: "Responsible Online Behavior" },
            ],
          },
          {
            id: "g9-cve-u3",
            name: "Constitution and Constitutionalism",
            subUnits: [
              { id: "g9-cve-u3-s1", name: "Meaning of Constitution" },
              { id: "g9-cve-u3-s2", name: "Principles of Constitutionalism" },
              { id: "g9-cve-u3-s3", name: "The Ethiopian Constitution" },
            ],
          },
          {
            id: "g9-cve-u4",
            name: "Indigenous Knowledge",
            subUnits: [
              { id: "g9-cve-u4-s1", name: "Meaning and Sources of Indigenous Knowledge" },
              { id: "g9-cve-u4-s2", name: "Indigenous Knowledge Systems in Ethiopia" },
              { id: "g9-cve-u4-s3", name: "Preserving Indigenous Knowledge" },
            ],
          },
          {
            id: "g9-cve-u5",
            name: "Multiculturalism",
            subUnits: [
              { id: "g9-cve-u5-s1", name: "Meaning of Multiculturalism" },
              { id: "g9-cve-u5-s2", name: "Benefits of Cultural Diversity" },
              { id: "g9-cve-u5-s3", name: "Challenges of Multiculturalism" },
            ],
          },
          {
            id: "g9-cve-u6",
            name: "National Unity through Diversity",
            subUnits: [
              { id: "g9-cve-u6-s1", name: "Unity in Diversity" },
              { id: "g9-cve-u6-s2", name: "Factors that Promote National Unity" },
              { id: "g9-cve-u6-s3", name: "Threats to National Unity" },
            ],
          },
          {
            id: "g9-cve-u7",
            name: "Problem Solving Skills",
            subUnits: [
              { id: "g9-cve-u7-s1", name: "Steps in Problem Solving" },
              { id: "g9-cve-u7-s2", name: "Critical and Creative Thinking" },
              { id: "g9-cve-u7-s3", name: "Decision-Making Skills" },
            ],
          },
          {
            id: "g9-cve-u8",
            name: "Ethiopia's Foreign Relations in East Africa",
            subUnits: [
              { id: "g9-cve-u8-s1", name: "Ethiopia's Foreign Policy" },
              { id: "g9-cve-u8-s2", name: "Regional Cooperation in East Africa" },
              { id: "g9-cve-u8-s3", name: "Ethiopia's Role in Regional Organizations" },
            ],
          },
        ],
      },
      {
        id: "g9-eco",
        name: "Economics",
        units: [
          {
            id: "g9-eco-u1",
            name: "Introduction to Economics",
            subUnits: [
              { id: "g9-eco-u1-s1", name: "Definition and Branches of Economics" },
              { id: "g9-eco-u1-s2", name: "Methods of Economic Analysis" },
              { id: "g9-eco-u1-s3", name: "Basic Economic Concepts" },
            ],
          },
          {
            id: "g9-eco-u2",
            name: "Basic Economic Problems and Systems",
            subUnits: [
              { id: "g9-eco-u2-s1", name: "Scarcity, Choice and Opportunity Cost" },
              { id: "g9-eco-u2-s2", name: "Central Economic Problems" },
              { id: "g9-eco-u2-s3", name: "Types of Economic Systems" },
            ],
          },
          {
            id: "g9-eco-u3",
            name: "Economic Resources and Markets",
            subUnits: [
              { id: "g9-eco-u3-s1", name: "Classification of Economic Resources" },
              { id: "g9-eco-u3-s2", name: "Factor Payments" },
              { id: "g9-eco-u3-s3", name: "Circular Flow of Economic Activity" },
            ],
          },
          {
            id: "g9-eco-u4",
            name: "Demand, Supply and Market Equilibrium",
            subUnits: [
              { id: "g9-eco-u4-s1", name: "The Law of Demand and Supply" },
              { id: "g9-eco-u4-s2", name: "Factors Affecting Demand and Supply" },
              { id: "g9-eco-u4-s3", name: "Market Equilibrium" },
            ],
          },
          {
            id: "g9-eco-u5",
            name: "Theory of Production and Cost",
            subUnits: [
              { id: "g9-eco-u5-s1", name: "Production, Inputs and Outputs" },
              { id: "g9-eco-u5-s2", name: "Short-Run and Long-Run Production" },
              { id: "g9-eco-u5-s3", name: "Types of Production Costs" },
            ],
          },
          {
            id: "g9-eco-u6",
            name: "Money and Banking",
            subUnits: [
              { id: "g9-eco-u6-s1", name: "Evolution and Functions of Money" },
              { id: "g9-eco-u6-s2", name: "Banking System in Ethiopia" },
              { id: "g9-eco-u6-s3", name: "Role of the Central Bank" },
            ],
          },
          {
            id: "g9-eco-u7",
            name: "Macroeconomic Concepts and National Income",
            subUnits: [
              { id: "g9-eco-u7-s1", name: "National Economic Goals" },
              { id: "g9-eco-u7-s2", name: "Measuring GDP and National Income" },
              { id: "g9-eco-u7-s3", name: "Inflation and Unemployment" },
            ],
          },
          {
            id: "g9-eco-u8",
            name: "Entrepreneurship and Business Opportunities",
            subUnits: [
              { id: "g9-eco-u8-s1", name: "Meaning of Entrepreneurship" },
              { id: "g9-eco-u8-s2", name: "Identifying Business Opportunities" },
              { id: "g9-eco-u8-s3", name: "Business Planning Basics" },
            ],
          },
        ],
      },
      {
        id: "g9-amh",
        name: "Amharic",
        units: Array.from({ length: 9 }, (_, i) => ({
          id: `g9-amh-u${i + 1}`,
          name: `Unit ${i + 1} (TBD — verify against textbook)`,
          subUnits: [
            { id: `g9-amh-u${i + 1}-s1`, name: "Listening and Speaking" },
            { id: `g9-amh-u${i + 1}-s2`, name: "Reading Comprehension" },
            { id: `g9-amh-u${i + 1}-s3`, name: "Grammar and Vocabulary" },
            { id: `g9-amh-u${i + 1}-s4`, name: "Writing" },
          ],
        })),
      },
      {
        id: "g9-ict",
        name: "Information Technology",
        units: [
          {
            id: "g9-ict-u1",
            name: "Organization of Files",
            subUnits: [
              { id: "g9-ict-u1-s1", name: "File and Folder Management" },
              { id: "g9-ict-u1-s2", name: "File Naming Conventions" },
              { id: "g9-ict-u1-s3", name: "Backup and Storage" },
              { id: "g9-ict-u1-s4", name: "File Compression" },
            ],
          },
          {
            id: "g9-ict-u2",
            name: "Computer Network",
            subUnits: [
              { id: "g9-ict-u2-s1", name: "Network Basics and Types" },
              { id: "g9-ict-u2-s2", name: "Network Devices and Topologies" },
              { id: "g9-ict-u2-s3", name: "Internet and Connectivity" },
              { id: "g9-ict-u2-s4", name: "Network Security Basics" },
            ],
          },
          {
            id: "g9-ict-u3",
            name: "Application Software",
            subUnits: [
              { id: "g9-ict-u3-s1", name: "Word Processing" },
              { id: "g9-ict-u3-s2", name: "Spreadsheet Applications" },
              { id: "g9-ict-u3-s3", name: "Presentation Software" },
              { id: "g9-ict-u3-s4", name: "Database Basics" },
            ],
          },
          {
            id: "g9-ict-u4",
            name: "Image Processing and Multimedia",
            subUnits: [
              { id: "g9-ict-u4-s1", name: "Digital Image Basics" },
              { id: "g9-ict-u4-s2", name: "Image Editing Tools" },
              { id: "g9-ict-u4-s3", name: "Multimedia Components" },
              { id: "g9-ict-u4-s4", name: "Multimedia Applications" },
            ],
          },
          {
            id: "g9-ict-u5",
            name: "Information and Computer Security",
            subUnits: [
              { id: "g9-ict-u5-s1", name: "Computer Threats and Viruses" },
              { id: "g9-ict-u5-s2", name: "Data Protection Methods" },
              { id: "g9-ict-u5-s3", name: "Ethical Use of ICT" },
              { id: "g9-ict-u5-s4", name: "Cyber Safety Practices" },
            ],
          },
          {
            id: "g9-ict-u6",
            name: "Fundamentals of Programming",
            subUnits: [
              { id: "g9-ict-u6-s1", name: "Introduction to Programming Concepts" },
              { id: "g9-ict-u6-s2", name: "Algorithms and Flowcharts" },
              { id: "g9-ict-u6-s3", name: "Basic Programming Constructs" },
              { id: "g9-ict-u6-s4", name: "Simple Program Writing" },
            ],
          },
        ],
      },
      {
        id: "g9-hpe",
        name: "Health and Physical Education",
        units: [
          {
            id: "g9-hpe-u1",
            name: "Sport and Society",
            subUnits: [
              { id: "g9-hpe-u1-s1", name: "Definition and Importance of Sport" },
              { id: "g9-hpe-u1-s2", name: "Sport and National Development" },
              { id: "g9-hpe-u1-s3", name: "Ethics in Sport" },
            ],
          },
          {
            id: "g9-hpe-u2",
            name: "Health and Physical Fitness",
            subUnits: [
              { id: "g9-hpe-u2-s1", name: "Components of Fitness" },
              { id: "g9-hpe-u2-s2", name: "Health-Related Fitness Activities" },
              { id: "g9-hpe-u2-s3", name: "Principles of Training" },
            ],
          },
          {
            id: "g9-hpe-u3",
            name: "Athletics",
            subUnits: [
              { id: "g9-hpe-u3-s1", name: "Track Events" },
              { id: "g9-hpe-u3-s2", name: "Field Events" },
              { id: "g9-hpe-u3-s3", name: "Athletics Training Principles" },
            ],
          },
          {
            id: "g9-hpe-u4",
            name: "Football",
            subUnits: [
              { id: "g9-hpe-u4-s1", name: "History and Rules" },
              { id: "g9-hpe-u4-s2", name: "Basic Skills and Techniques" },
              { id: "g9-hpe-u4-s3", name: "Tactics and Safety" },
            ],
          },
          {
            id: "g9-hpe-u5",
            name: "Volleyball",
            subUnits: [
              { id: "g9-hpe-u5-s1", name: "History and Rules" },
              { id: "g9-hpe-u5-s2", name: "Basic Skills and Techniques" },
              { id: "g9-hpe-u5-s3", name: "Tactics and Safety" },
            ],
          },
          {
            id: "g9-hpe-u6",
            name: "Basketball",
            subUnits: [
              { id: "g9-hpe-u6-s1", name: "History and Rules" },
              { id: "g9-hpe-u6-s2", name: "Basic Skills and Techniques" },
              { id: "g9-hpe-u6-s3", name: "Tactics and Safety" },
            ],
          },
          {
            id: "g9-hpe-u7",
            name: "Handball",
            subUnits: [
              { id: "g9-hpe-u7-s1", name: "History and Rules" },
              { id: "g9-hpe-u7-s2", name: "Basic Skills and Techniques" },
              { id: "g9-hpe-u7-s3", name: "Tactics and Safety" },
            ],
          },
          {
            id: "g9-hpe-u8",
            name: "Self-Defense and Sport Ethics",
            subUnits: [
              { id: "g9-hpe-u8-s1", name: "Basic Self-Defense Techniques" },
              { id: "g9-hpe-u8-s2", name: "Sportsmanship and Fair Play" },
              { id: "g9-hpe-u8-s3", name: "Sport-Related Injuries and Safety" },
            ],
          },
        ],
      },
];

fs.writeFileSync("g9.json", JSON.stringify(data));
